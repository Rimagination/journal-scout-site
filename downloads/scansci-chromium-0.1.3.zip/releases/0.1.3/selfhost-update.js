(() => {
  const api = globalThis.chrome;
  const host = 'com.scansci.journal_scout_updater';
  const alarmName = 'journalScoutUpdate';
  let pending;
  let reloadScheduled = false;

  function check() {
    if (pending) return pending;
    pending = (async () => {
      try {
        if (!globalThis.ScanSciExtraSites?.snapshot) throw new Error('site backup unavailable');
        await globalThis.ScanSciExtraSites.snapshot();
      } catch { return { status: 'error', code: 'site_backup_failed' }; }
      return new Promise(resolve => {
        try {
          api.runtime.sendNativeMessage(host, { action: 'check', version: api.runtime.getManifest().version }, response => {
            if (api.runtime.lastError) return resolve({ status: 'error', code: 'host_unavailable' });
            if (['up_to_date', 'updated', 'reload_required', 'blocked_version', 'updates_paused'].includes(response?.status)) {
              return resolve({ status: response.status, version: response.version });
            }
            resolve({ status: 'error', code: typeof response?.code === 'string' ? response.code : 'update_failed' });
          });
        } catch {
          resolve({ status: 'error', code: 'host_unavailable' });
        }
      });
    })().finally(() => { pending = undefined; });
    return pending;
  }

  function reloadAfterUpdate(result) {
    if (!['updated', 'reload_required'].includes(result.status) || reloadScheduled) return;
    reloadScheduled = true;
    // Respond to the open popup before the browser tears down the extension.
    setTimeout(() => api.runtime.reload(), 250);
  }

  api.alarms.onAlarm.addListener(alarm => {
    if (alarm.name === alarmName) void check().then(reloadAfterUpdate);
  });
  // Alarms may disappear after a browser restart or extension update.
  api.runtime.getPlatformInfo(info => {
    if (api.runtime.lastError || info?.os !== 'win') return;
    api.alarms.get(alarmName, alarm => {
      if (api.runtime.lastError) return;
      if (!alarm) api.alarms.create(alarmName, { delayInMinutes: 1, periodInMinutes: 120 });
    });
  });

  api.runtime.onMessage.addListener((message, sender, respond) => {
    const popup = api.runtime.getManifest().action?.default_popup || 'popup.html';
    if (message?.type !== 'selfhostUpdateCheck' || sender.id !== api.runtime.id || sender.url !== api.runtime.getURL(popup)) return false;
    check().then(result => { respond(result); reloadAfterUpdate(result); });
    return true;
  });
})();
