// Loads the shared core and background for Chromium.
importScripts('core.js', 'selfhost-update.js', 'background.js');
