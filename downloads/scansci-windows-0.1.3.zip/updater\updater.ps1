$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression

function Get-ScanSciVersion([string]$Value) {
    if ($Value -cnotmatch '^(0|[1-9][0-9]{0,4})\.(0|[1-9][0-9]{0,4})\.(0|[1-9][0-9]{0,4})$') { throw 'invalid_version' }
    $parts = $Value.Split('.')
    foreach ($part in $parts) { if ([int]$part -gt 65535) { throw 'invalid_version' } }
    return [version]$Value
}

function Assert-NoReparse([string]$Path) {
    $itemPath = $Path
    while ($itemPath) {
        $item = Get-Item -LiteralPath $itemPath -Force -ErrorAction SilentlyContinue
        if ($item) {
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'invalid_installation' }
        }
        $parent = [IO.Path]::GetDirectoryName($itemPath)
        if ($parent -eq $itemPath) { break }
        $itemPath = $parent
    }
}

function Get-SafeInstallPath([string]$Path, [string]$HostPath, [switch]$AllowMissingManifest) {
    if ([string]::IsNullOrWhiteSpace($Path)) { throw 'invalid_installation' }
    $full = [IO.Path]::GetFullPath($Path).TrimEnd('\')
    if ($full -cnotmatch '^[A-Za-z]:\\.+') { throw 'invalid_installation' }
    if (-not [IO.Directory]::Exists($full)) { throw 'invalid_installation' }
    $hostFull = [IO.Path]::GetFullPath($HostPath).TrimEnd('\')
    if ($full.Equals($hostFull, [StringComparison]::OrdinalIgnoreCase) -or
        $hostFull.StartsWith($full + '\', [StringComparison]::OrdinalIgnoreCase) -or
        $full.StartsWith($hostFull + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'invalid_installation' }
    Assert-NoReparse $full
    Assert-NoReparse (Join-Path $full 'manifest.json')
    if (-not $AllowMissingManifest -and -not [IO.File]::Exists((Join-Path $full 'manifest.json'))) { throw 'invalid_installation' }
    return $full
}

function Get-ScanSciRemoteBytes([string]$Url, [int]$Limit) {
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $request = [Net.HttpWebRequest]::Create($Url)
        $request.AllowAutoRedirect = $false
        $request.Timeout = 15000
        $request.ReadWriteTimeout = 15000
        $request.MaximumResponseHeadersLength = 16
        $request.UserAgent = 'JournalScoutUpdater/1.0'
        $response = $request.GetResponse()
        try {
            if ([int]$response.StatusCode -ne 200 -or $response.ContentLength -gt $Limit) { throw 'network_error' }
            $source = $response.GetResponseStream()
            $memory = [IO.MemoryStream]::new()
            try {
                $buffer = New-Object byte[] 16384
                while (($count = $source.Read($buffer, 0, $buffer.Length)) -gt 0) {
                    if ($memory.Length + $count -gt $Limit) { throw 'network_error' }
                    $memory.Write($buffer, 0, $count)
                }
                return ,$memory.ToArray()
            } finally { $source.Dispose(); $memory.Dispose() }
        } finally { $response.Dispose() }
    } catch { throw 'network_error' }
}

function Read-ScanSciPublicKey([string]$KeyPath) {
    try {
        $xml = [xml][IO.File]::ReadAllText($KeyPath, [Text.Encoding]::UTF8)
        $root = $xml.RSAKeyValue
        if ($null -eq $root -or $root.ChildNodes.Count -ne 2 -or
            -not $root.Modulus -or -not $root.Exponent) { throw 'missing public key' }
        $modulus = [Convert]::FromBase64String([string]$root.Modulus)
        $exponent = [Convert]::FromBase64String([string]$root.Exponent)
        $rsa = [Security.Cryptography.RSA]::Create()
        $rsa.ImportParameters([Security.Cryptography.RSAParameters]@{ Modulus = $modulus; Exponent = $exponent })
        if ($rsa.KeySize -lt 2048) { $rsa.Dispose(); throw 'weak public key' }
        return $rsa
    } catch { throw 'trust_not_configured' }
}

function Read-ScanSciManifest([string]$Path) {
    try {
        $manifest = ConvertFrom-Json ([IO.File]::ReadAllText($Path, [Text.UTF8Encoding]::new($false, $true)))
        if ($manifest.manifest_version -ne 3 -or $manifest.name -isnot [string] -or
            [string]::IsNullOrWhiteSpace($manifest.name) -or $manifest.name.Length -gt 256) { throw 'bad manifest' }
        $null = Get-ScanSciVersion $manifest.version
        return $manifest
    } catch { throw 'invalid_installation' }
}

function Test-ScanSciOriginalName([string]$Name) {
    return $Name -ceq ('ScanSci ' + [char]0x6587 + [char]0x732E + [char]0x52A9 + [char]0x624B)
}

function Assert-SafeArchivePath([string]$Name) {
    if ([string]::IsNullOrEmpty($Name) -or $Name.Length -gt 240 -or $Name.Contains('\') -or
        $Name.StartsWith('/') -or $Name.Contains(':')) { throw 'invalid_archive' }
    $segments = $Name.TrimEnd('/').Split('/')
    foreach ($segment in $segments) {
        if ([string]::IsNullOrEmpty($segment) -or $segment -eq '.' -or $segment -eq '..' -or
            $segment.EndsWith('.') -or $segment.EndsWith(' ') -or $segment -match '[\x00-\x1f<>"|?*]' -or
            $segment -match '^(?i:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?$') { throw 'invalid_archive' }
    }
}

function Expand-ScanSciArchive([byte[]]$Bytes, [string]$Stage, [string]$Version) {
    try {
        $stream = [IO.MemoryStream]::new($Bytes, $false)
        $archive = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Read, $false)
        try {
            if ($archive.Entries.Count -eq 0 -or $archive.Entries.Count -gt 500) { throw 'invalid_archive' }
            $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
            $total = [long]0
            foreach ($entry in $archive.Entries) {
                Assert-SafeArchivePath $entry.FullName
                $entryPath = $entry.FullName.TrimEnd('/')
                $prefix = 'releases/' + $Version
                $directoryEntry = $entry.FullName.EndsWith('/')
                if (-not (($entryPath -ceq 'manifest.json' -and -not $directoryEntry) -or
                    (($entryPath -ceq 'releases' -or $entryPath -ceq $prefix) -and $directoryEntry) -or
                    $entryPath.StartsWith($prefix + '/', [StringComparison]::Ordinal))) { throw 'invalid_archive' }
                $rawAttributes = [BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$entry.ExternalAttributes), 0)
                if ((($rawAttributes -shr 16) -band 0xF000) -eq 0xA000) { throw 'invalid_archive' }
                $relative = $entry.FullName.TrimEnd('/')
                if (-not $seen.Add($relative)) { throw 'invalid_archive' }
                $total += $entry.Length
                if ($entry.Length -gt 104857600 -or $total -gt 104857600) { throw 'invalid_archive' }
                $destination = Join-Path $Stage ($relative.Replace('/', '\'))
                if ($entry.FullName.EndsWith('/')) {
                    [IO.Directory]::CreateDirectory($destination) | Out-Null
                    continue
                }
                [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destination)) | Out-Null
                $input = $entry.Open()
                $output = [IO.File]::Open($destination, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
                try { $input.CopyTo($output) } finally { $input.Dispose(); $output.Dispose() }
            }
            if (-not [IO.File]::Exists((Join-Path $Stage 'manifest.json'))) { throw 'invalid_archive' }
        } finally { $archive.Dispose(); $stream.Dispose() }
    } catch { throw 'invalid_archive' }
}

function Assert-ScanSciNativeManifestValue($Native, [string]$HostDir, [string]$Kind, $Mappings) {
    try {
        $launcher = Join-Path $HostDir ('host-' + $Kind + '.cmd')
        $expected = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
        foreach ($mapping in $Mappings.PSObject.Properties) {
            if ($mapping.Name -cnotmatch '^[a-p]{32}$' -or $mapping.Value -isnot [string]) { throw 'bad mapping' }
            $null = $expected.Add('chrome-extension://' + $mapping.Name + '/')
        }
        if ($Native.name -cne 'com.scansci.journal_scout_updater' -or $Native.type -cne 'stdio' -or
            -not ([string]$Native.path).Equals($launcher, [StringComparison]::OrdinalIgnoreCase) -or
            $Native.allowed_origins -isnot [array] -or $Native.allowed_origins.Count -ne $expected.Count) { throw 'bad manifest' }
        foreach ($origin in $Native.allowed_origins) { if ($origin -isnot [string] -or -not $expected.Remove($origin)) { throw 'bad origin' } }
        if ($expected.Count -ne 0) { throw 'missing origin' }
    } catch { throw 'An existing Native Messaging manifest is unrecognized and was not overwritten.' }
}

function Assert-ScanSciNativeManifest([string]$Path, [string]$HostDir, [string]$Kind, $Mappings) {
    Assert-NoReparse $Path
    if (-not [IO.File]::Exists($Path)) { return }
    try {
        $native = ConvertFrom-Json ([IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8))
        Assert-ScanSciNativeManifestValue $native $HostDir $Kind $Mappings
    } catch { throw 'An existing Native Messaging manifest is unrecognized and was not overwritten.' }
}

. (Join-Path $PSScriptRoot 'atomic-update.ps1')
