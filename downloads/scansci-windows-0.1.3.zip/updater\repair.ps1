﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
. (Join-Path $PSScriptRoot 'updater.ps1')
. (Join-Path $PSScriptRoot 'find-installations.ps1')

$title = 'Journal Scout 版本恢复'
$hostDir = Join-Path $env:LOCALAPPDATA 'ScanSci\JournalScoutUpdater'
$form = [Windows.Forms.Form]::new()
$form.Text = $title
$form.StartPosition = 'CenterScreen'
$form.ClientSize = [Drawing.Size]::new(800, 390)
$form.MinimumSize = [Drawing.Size]::new(700, 390)
$label = [Windows.Forms.Label]::new()
$label.Text = '选择要恢复的旧版本。恢复后请在浏览器扩展管理页面重新加载插件。'
$label.AutoSize = $true
$label.Location = [Drawing.Point]::new(14, 18)
$form.Controls.Add($label)
$list = [Windows.Forms.ListView]::new()
$list.Location = [Drawing.Point]::new(14, 50)
$list.Size = [Drawing.Size]::new(770, 250)
$list.Anchor = 'Top,Bottom,Left,Right'
$list.View = 'Details'
$list.FullRowSelect = $true
$list.MultiSelect = $false
$null = $list.Columns.Add('浏览器', 75)
$null = $list.Columns.Add('可恢复版本', 90)
$null = $list.Columns.Add('扩展 ID', 215)
$null = $list.Columns.Add('扩展安装目录', 370)
$form.Controls.Add($list)
$hint = [Windows.Forms.Label]::new()
$hint.Text = '只显示已绑定扩展且资源完整的备份。'
$hint.AutoSize = $true
$hint.Location = [Drawing.Point]::new(14, 315)
$hint.Anchor = 'Bottom,Left'
$form.Controls.Add($hint)
$button = [Windows.Forms.Button]::new()
$button.Text = '恢复所选版本'
$button.Location = [Drawing.Point]::new(674, 337)
$button.Size = [Drawing.Size]::new(110, 30)
$button.Anchor = 'Bottom,Right'
$form.Controls.Add($button)
$resumeButton = [Windows.Forms.Button]::new()
$resumeButton.Text = '恢复自动更新'
$resumeButton.Location = [Drawing.Point]::new(548, 337)
$resumeButton.Size = [Drawing.Size]::new(116, 30)
$resumeButton.Anchor = 'Bottom,Right'
$form.Controls.Add($resumeButton)

$candidates = @(Find-ScanSciRecoveryTargets $env:LOCALAPPDATA)
foreach ($candidate in $candidates) {
    $item = [Windows.Forms.ListViewItem]::new($candidate.Browser)
    $null = $item.SubItems.Add($candidate.Version)
    $null = $item.SubItems.Add($candidate.ExtensionId)
    $null = $item.SubItems.Add($candidate.ExtensionPath)
    $item.Tag = $candidate
    $null = $list.Items.Add($item)
}
if ($candidates.Count -eq 0) {
    $hint.Text = '没有找到资源完整的旧版本备份。请确认更新助手已为当前扩展安装。'
    $button.Enabled = $false
    $resumeButton.Enabled = $false
}
$button.Add_Click({
    if ($list.SelectedItems.Count -ne 1) {
        [Windows.Forms.MessageBox]::Show('请先选择一个旧版本。', $title) | Out-Null
        return
    }
    $candidate = $list.SelectedItems[0].Tag
    try {
        $null = Invoke-ScanSciRestore $candidate.ExtensionPath $hostDir $candidate.Version
        [Windows.Forms.MessageBox]::Show(('已恢复版本 ' + $candidate.Version + '。请打开浏览器扩展管理页面，点击 Journal Scout 的“重新加载”。'), $title) | Out-Null
    } catch {
        [Windows.Forms.MessageBox]::Show(('恢复未完成：' + $_.Exception.Message), $title) | Out-Null
    }
})
$resumeButton.Add_Click({
    if ($list.SelectedItems.Count -ne 1) {
        [Windows.Forms.MessageBox]::Show('请先选择一项扩展。', $title) | Out-Null
        return
    }
    $candidate = $list.SelectedItems[0].Tag
    try {
        $state = Get-ScanSciBlockedState $candidate.ExtensionPath $hostDir
        if (-not $state -or -not $state.paused) {
            [Windows.Forms.MessageBox]::Show('此扩展的自动更新没有因故障版本未知而暂停。', $title) | Out-Null
            return
        }
        $answer = [Windows.Forms.MessageBox]::Show('无法确定之前的故障版本。请确认服务端已有修复版本，否则可能再次安装故障版本。现在恢复自动更新吗？', $title, 'YesNo', 'Warning')
        if ($answer -eq [Windows.Forms.DialogResult]::Yes) {
            Resume-ScanSciUpdates $candidate.ExtensionPath $hostDir $state.revision
            [Windows.Forms.MessageBox]::Show('自动更新已恢复；已明确拒绝的旧版本仍会跳过。', $title) | Out-Null
        }
    } catch {
        $message = if ($_.Exception.Message -eq 'pause_changed') { '暂停状态刚刚发生变化，请重新确认后再操作。' } else { '操作未完成：' + $_.Exception.Message }
        [Windows.Forms.MessageBox]::Show($message, $title) | Out-Null
    }
})
$null = $form.ShowDialog()
