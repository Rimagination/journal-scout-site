param(
    [ValidateSet('chrome', 'edge')][string]$Browser,
    [string]$CallerOrigin
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'updater.ps1')

function Read-NativeBytes([System.IO.Stream]$Stream, [int]$Count) {
    $bytes = New-Object byte[] $Count
    $offset = 0
    while ($offset -lt $Count) {
        $read = $Stream.Read($bytes, $offset, $Count - $offset)
        if ($read -eq 0) { throw 'invalid_request' }
        $offset += $read
    }
    return ,$bytes
}

$response = $null
try {
    $inputStream = [Console]::OpenStandardInput()
    $header = Read-NativeBytes $inputStream 4
    if (-not [BitConverter]::IsLittleEndian) { [Array]::Reverse($header) }
    $length = [BitConverter]::ToUInt32($header, 0)
    if ($length -eq 0 -or $length -gt 65536) { throw 'invalid_request' }
    $requestBytes = Read-NativeBytes $inputStream ([int]$length)
    $request = ConvertFrom-Json ([Text.UTF8Encoding]::new($false, $true).GetString($requestBytes))
    if ($request.action -cne 'check' -or $request.version -isnot [string]) { throw 'invalid_request' }
    $response = Invoke-ScanSciUpdate -Browser $Browser -CallerOrigin $CallerOrigin -RequestedVersion $request.version `
        -ConfigPath (Join-Path $PSScriptRoot 'config.json') -TrustedKeyPath (Join-Path $PSScriptRoot 'trusted-key.xml')
} catch {
    $code = $_.Exception.Message
    $knownCodes = @('invalid_request', 'unknown_extension', 'invalid_installation', 'invalid_version',
        'trust_not_configured', 'network_error', 'invalid_metadata', 'invalid_signature', 'invalid_download',
        'invalid_archive', 'update_in_progress', 'update_failed', 'rollback_failed')
    if ($code -cnotin $knownCodes) { $code = 'update_failed' }
    $response = @{ status = 'error'; code = $code }
}

$output = [Text.UTF8Encoding]::new($false).GetBytes(($response | ConvertTo-Json -Compress -Depth 5))
$outputHeader = [BitConverter]::GetBytes([uint32]$output.Length)
if (-not [BitConverter]::IsLittleEndian) { [Array]::Reverse($outputHeader) }
$outputStream = [Console]::OpenStandardOutput()
$outputStream.Write($outputHeader, 0, 4)
$outputStream.Write($output, 0, $output.Length)
$outputStream.Flush()
