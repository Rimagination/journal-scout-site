function New-ScanSciInstallPlan([string]$HostDir, $Documents) {
    $pending = Join-Path $HostDir 'install-pending.json'
    Assert-NoReparse $pending
    if ([IO.File]::Exists($pending)) { throw 'An unfinished installer transaction already exists.' }
    $entries = @()
    foreach ($name in $Documents.Keys) {
        if ($name -cnotin @('config.json', 'native-messaging.chrome.json', 'native-messaging.edge.json')) { throw 'Invalid installer file.' }
        $path = Join-Path $HostDir $name
        Assert-NoReparse $path
        $old = if ([IO.File]::Exists($path)) { [Convert]::ToBase64String([IO.File]::ReadAllBytes($path)) } else { $null }
        $new = [Convert]::ToBase64String([Text.UTF8Encoding]::new($false).GetBytes([string]$Documents[$name]))
        $entries += @{ name = $name; old = $old; new = $new }
    }
    $plan = @{ schemaVersion = 1; product = 'com.scansci.journal_scout_updater'; hostDir = $HostDir; entries = $entries }
    $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($plan | ConvertTo-Json -Compress -Depth 8))
    $temp = Join-Path $HostDir ('.install-plan-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    try {
        $stream = [IO.File]::Open($temp, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
        [IO.File]::Move($temp, $pending)
    } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
}

function Complete-ScanSciInstallPlan([string]$HostDir, [scriptblock]$PhaseHook = $null) {
    $pending = Join-Path $HostDir 'install-pending.json'
    Assert-NoReparse $pending
    if (-not [IO.File]::Exists($pending)) { return }
    try {
        $pendingBytes = [IO.File]::ReadAllBytes($pending)
        if ($pendingBytes.Length -gt 1048576) { throw 'large plan' }
        $plan = ConvertFrom-Json ([Text.UTF8Encoding]::new($false, $true).GetString($pendingBytes))
        if ($plan.schemaVersion -ne 1 -or $plan.product -cne 'com.scansci.journal_scout_updater' -or
            -not ([string]$plan.hostDir).Equals($HostDir, [StringComparison]::OrdinalIgnoreCase) -or
            $plan.entries -isnot [array] -or $plan.entries.Count -lt 2 -or $plan.entries.Count -gt 3) { throw 'bad plan' }
        $entries = @{}
        foreach ($entry in $plan.entries) {
            if ($entry.name -cnotin @('config.json', 'native-messaging.chrome.json', 'native-messaging.edge.json') -or
                $entries.ContainsKey($entry.name) -or $entry.new -isnot [string] -or
                ($null -ne $entry.old -and $entry.old -isnot [string])) { throw 'bad entry' }
            $newBytes = [Convert]::FromBase64String($entry.new)
            if ($newBytes.Length -gt 262144) { throw 'large document' }
            if ($null -ne $entry.old) { $null = [Convert]::FromBase64String($entry.old) }
            $entries[$entry.name] = $entry
            $path = Join-Path $HostDir $entry.name
            Assert-NoReparse $path
            $current = if ([IO.File]::Exists($path)) { [Convert]::ToBase64String([IO.File]::ReadAllBytes($path)) } else { $null }
            if ($current -cne $entry.old -and $current -cne $entry.new) { throw 'unknown existing file' }
        }
        if (-not $entries.ContainsKey('config.json')) { throw 'missing config' }
        $newConfig = ConvertFrom-Json ([Text.UTF8Encoding]::new($false, $true).GetString([Convert]::FromBase64String($entries['config.json'].new)))
        if ($newConfig.schemaVersion -ne 1 -or -not $newConfig.browsers.chrome -or -not $newConfig.browsers.edge) { throw 'bad config' }
        foreach ($kind in @('chrome', 'edge')) {
            $name = 'native-messaging.' + $kind + '.json'
            $mappings = @($newConfig.browsers.$kind.PSObject.Properties)
            if ($mappings.Count -eq 0) { if ($entries.ContainsKey($name)) { throw 'unexpected manifest' }; continue }
            if (-not $entries.ContainsKey($name)) { throw 'missing manifest' }
            $native = ConvertFrom-Json ([Text.UTF8Encoding]::new($false, $true).GetString([Convert]::FromBase64String($entries[$name].new)))
            Assert-ScanSciNativeManifestValue $native $HostDir $kind $newConfig.browsers.$kind
        }
    } catch { throw 'An unfinished installer transaction is unrecognized; no files were overwritten.' }
    foreach ($entry in $plan.entries) {
        $path = Join-Path $HostDir $entry.name
        Assert-NoReparse $path
        $current = if ([IO.File]::Exists($path)) { [Convert]::ToBase64String([IO.File]::ReadAllBytes($path)) } else { $null }
        if ($current -ceq $entry.new) { continue }
        if ($current -cne $entry.old) { throw 'An unfinished installer transaction is unrecognized; no files were overwritten.' }
        $temp = Join-Path $HostDir ('.install-file-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        try {
            $bytes = [Convert]::FromBase64String($entry.new)
            $stream = [IO.File]::Open($temp, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
            try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
            Assert-NoReparse $path
            if ([IO.File]::Exists($path)) { [IO.File]::Replace($temp, $path, [System.Management.Automation.Language.NullString]::Value) }
            else { [IO.File]::Move($temp, $path) }
        } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
        if ($PhaseHook) { & $PhaseHook $entry.name }
    }
    if ([Convert]::ToBase64String([IO.File]::ReadAllBytes($pending)) -cne [Convert]::ToBase64String($pendingBytes)) { throw 'Installer transaction changed unexpectedly.' }
    [IO.File]::Delete($pending)
}
