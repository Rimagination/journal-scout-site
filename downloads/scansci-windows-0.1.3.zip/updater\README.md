# Journal Scout Windows 更新助手

这是 Chrome 和 Edge 解压安装版本的本地更新助手。扩展需要 `nativeMessaging` 权限；更新助手单独安装，原扩展目录、扩展 ID 和浏览器中的设置仍保留。

## 发布前准备

`trusted-key.xml` 必须替换为发布签名 RSA 公钥，格式为包含 `Modulus`、`Exponent` 的 `RSAKeyValue` XML，密钥长度至少 2048 位。只有公钥可以包含在安装包中；没有配置公钥时，安装器和更新会拒绝执行。

服务器的 `https://journal.scansci.com/updates/chromium.json` 返回：

```json
{"payload":"base64 编码的 UTF-8 JSON","signature":"该 JSON 原始字节的 RSA-SHA256 PKCS#1 v1.5 签名的 base64"}
```

签名内容包含 `version`、`url`、`sha256` 和 `size`。更新包来源固定为 `https://journal.scansci.com/downloads/scansci-chromium-<version>.zip`；版本为三段 0–65535 十进制数字（不使用前导零），压缩包上限 20 MiB、文件数上限 500、解压大小上限 100 MiB。ZIP 根目录必须包含 `manifest.json`，其余文件只能放在 `releases/<version>/` 下；清单中的文件路径也必须指向同一个版本目录。

## 安装

双击 `setup.cmd`，在窗口中选择已安装的 Chrome 或 Edge 扩展，再点击“安装更新助手”。如果两个浏览器都要使用，请分别选择并安装。窗口只读取浏览器配置来查找已解压安装的插件，实际安装时会在当前 Windows 用户下注册本地消息主机。

如果没有识别到扩展，可打开 `chrome://extensions` 或 `edge://extensions`，启用开发者模式，查看 Journal Scout 的扩展 ID 和已解压安装目录，然后在包含本文件的文件夹中打开 PowerShell，运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Browser chrome -ExtensionId <扩展ID> -ExtensionPath '<扩展目录>'
```

Edge 将 `-Browser chrome` 改为 `-Browser edge`。如果不知道目录，可在浏览器扩展页面的 Journal Scout 详情中查看；也可以打开安装插件时选择的文件夹。目录必须包含该扩展的 `manifest.json`。同一浏览器中同一 ID 如指向两个不同目录，安装器会拒绝覆盖已有映射；Chrome 和 Edge 可为同一 ID 分别绑定各自目录。

助手放在 `%LOCALAPPDATA%\ScanSci\JournalScoutUpdater`，浏览器各使用自己的 Native Messaging 配置。安装器不会替换不同的已注册同名主机或更改现有公钥。

## 手动卸载或修复助手

如安装器提示已有助手文件不同，先在 PowerShell 运行以下命令，仅移除仍指向本助手目录的 Chrome 和 Edge 注册项：

```powershell
$updaterDir = Join-Path $env:LOCALAPPDATA 'ScanSci\JournalScoutUpdater'
foreach ($browser in @('chrome', 'edge')) {
    $key = if ($browser -eq 'chrome') {
        'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.scansci.journal_scout_updater'
    } else {
        'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\com.scansci.journal_scout_updater'
    }
    $expected = Join-Path $updaterDir "native-messaging.$browser.json"
    if ((Test-Path -LiteralPath $key) -and
        ([string](Get-Item -LiteralPath $key).GetValue('')).Equals($expected, [StringComparison]::OrdinalIgnoreCase)) {
        Remove-Item -LiteralPath $key
    }
}
```

然后在文件资源管理器打开 `%LOCALAPPDATA%\ScanSci\JournalScoutUpdater`，检查并删除该目录中属于本助手的文件：`config.json`、`trusted-key.xml`、`host.ps1`、`host-chrome.cmd`、`host-edge.cmd`、`updater.ps1`、`atomic-update.ps1`、`find-installations.ps1`、`repair.ps1`、`repair.cmd`、`native-messaging.chrome.json` 和 `native-messaging.edge.json`。如存在 `blocked-updates`、`bindings` 文件夹或 `install-pending.json`，请先检查其内容并在确认属于本助手后删除。如有不认识的其他文件，请保留并移到别处；确认目录为空后才能重新安装助手。上述操作不删除扩展目录、浏览器设置或收藏。

## 恢复旧版本

更新时助手会将原版的 manifest 保存在扩展目录的 `releases\manifest-backups` 中。如果新版插件无法启动，在文件资源管理器打开 `%LOCALAPPDATA%\ScanSci\JournalScoutUpdater`，双击 `repair.cmd`，选择列表中资源完整的旧版本并点击“恢复所选版本”。随后在 `chrome://extensions` 或 `edge://extensions` 打开 Journal Scout，点击“重新加载”。此入口不依赖插件后台运行。

回退后，助手会跳过已拒绝的版本及更低版本，避免连续回退后重新安装坏版本；更高版本仍可正常更新。如果原 manifest 缺失或无法读取，助手会暂停自动更新。在确认服务端已有修复版本后，可在修复窗口选择该扩展并点击“恢复自动更新”，已明确拒绝的版本仍会被跳过。备份目录请保留，以便以后恢复。

助手记录安装时 manifest 的 key 状态，并使用本地摘要检查备份 manifest 和运行文件是否意外损坏；这些记录不能防范有权限修改本机文件的恶意程序。

## 消息接口

扩展通过 `com.scansci.journal_scout_updater` 发送 `{"action":"check","version":"0.1.3"}`。主机从浏览器参数验证调用来源，并根据浏览器和扩展 ID 查找绑定目录。回复的 `status` 为 `up_to_date`、`updated`、`reload_required`、`blocked_version`、`updates_paused` 或 `error`；错误代码包含 `trust_not_configured`、`network_error`、`invalid_signature`、`invalid_download` 和 `invalid_archive`。`updated` 和 `reload_required` 需要扩展重载自身；`blocked_version` 表示该版本已因手动回退被跳过，`updates_paused` 表示故障版本无法确定，需要用户决定何时恢复检查。

更新先写入完整的新版本目录，最后原子替换根目录的 `manifest.json`，保留旧版本文件；中途停止不会将旧版和新版代码混写。更新不访问浏览器的设置或收藏；扩展数据由浏览器管理。

目前旧版本目录会一直保留，没有自动清理或数量上限，频繁更新会增加磁盘占用。需要清理时，先退出所有使用该扩展目录的 Chrome 和 Edge 窗口，检查根目录 `manifest.json` 的 `version`；只手动删除确认由插件生成、版本号不同于当前版本且不含用户文件的 `releases/<旧版本>` 目录。后续可在能够确认各浏览器都已停止使用旧版时加入自动清理。
