﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
. (Join-Path $PSScriptRoot 'updater.ps1')
. (Join-Path $PSScriptRoot 'find-installations.ps1')

$title = 'Journal Scout 自动更新助手'
$form = [Windows.Forms.Form]::new()
$form.Text = $title
$form.StartPosition = 'CenterScreen'
$form.ClientSize = [Drawing.Size]::new(800, 390)
$form.MinimumSize = [Drawing.Size]::new(700, 390)
$label = [Windows.Forms.Label]::new()
$label.Text = '请选择已安装的 Journal Scout；安装后会继续使用现有扩展目录和 ID。'
$label.AutoSize = $true
$label.Location = [Drawing.Point]::new(14, 18)
$form.Controls.Add($label)
$list = [Windows.Forms.ListView]::new()
$list.Location = [Drawing.Point]::new(14, 50)
$list.Size = [Drawing.Size]::new(770, 250)
$list.Anchor = 'Top,Bottom,Left,Right'
$list.View = 'Details'
$list.FullRowSelect = $true
$list.MultiSelect = $false
$null = $list.Columns.Add('浏览器', 75)
$null = $list.Columns.Add('配置目录', 80)
$null = $list.Columns.Add('版本', 65)
$null = $list.Columns.Add('扩展 ID', 215)
$null = $list.Columns.Add('现有安装目录', 325)
$form.Controls.Add($list)
$hint = [Windows.Forms.Label]::new()
$hint.Text = '选择一项后点击安装；其他浏览器可重复此操作。'
$hint.AutoSize = $true
$hint.Location = [Drawing.Point]::new(14, 315)
$hint.Anchor = 'Bottom,Left'
$form.Controls.Add($hint)
$button = [Windows.Forms.Button]::new()
$button.Text = '安装更新助手'
$button.Location = [Drawing.Point]::new(674, 337)
$button.Size = [Drawing.Size]::new(110, 30)
$button.Anchor = 'Bottom,Right'
$form.Controls.Add($button)

$candidates = @(Find-ScanSciInstallations $env:LOCALAPPDATA)
foreach ($candidate in $candidates) {
    $item = [Windows.Forms.ListViewItem]::new($candidate.Browser)
    $null = $item.SubItems.Add($candidate.Profile)
    $null = $item.SubItems.Add($candidate.Version)
    $null = $item.SubItems.Add($candidate.ExtensionId)
    $null = $item.SubItems.Add($candidate.ExtensionPath)
    $item.Tag = $candidate
    $null = $list.Items.Add($item)
}
if ($candidates.Count -eq 0) {
    $hint.Text = '未找到已解压安装的扩展。请查看 README.md 中的手动安装命令。'
    $button.Enabled = $false
}
$button.Add_Click({
    if ($list.SelectedItems.Count -ne 1) {
        [Windows.Forms.MessageBox]::Show('请先选择一项扩展。', $title) | Out-Null
        return
    }
    $item = $list.SelectedItems[0].Tag
    try {
        & (Join-Path $PSScriptRoot 'install.ps1') -Browser $item.Browser -ExtensionId $item.ExtensionId -ExtensionPath $item.ExtensionPath
        [Windows.Forms.MessageBox]::Show('已为所选扩展安装更新助手。', $title) | Out-Null
    } catch {
        $message = switch ($_.Exception.Message) {
            'trust_not_configured' { '更新助手尚未配置发布公钥，请使用正式发布的安装包。' }
            'invalid_installation' { '扩展目录无效或不可访问，请检查安装目录。' }
            default { '安装失败：' + $_.Exception.Message }
        }
        [Windows.Forms.MessageBox]::Show($message, $title) | Out-Null
    }
})
$null = $form.ShowDialog()
