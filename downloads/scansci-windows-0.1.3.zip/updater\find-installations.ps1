function Find-ScanSciInstallations([string]$LocalAppData) {
    $roots = @{
        chrome = Join-Path $LocalAppData 'Google\Chrome\User Data'
        edge = Join-Path $LocalAppData 'Microsoft\Edge\User Data'
    }
    $hostDir = Join-Path $LocalAppData 'ScanSci\JournalScoutUpdater'
    $knownTargets = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $configFile = Join-Path $hostDir 'config.json'
    if ([IO.File]::Exists($configFile)) {
        try {
            $config = ConvertFrom-Json ([IO.File]::ReadAllText($configFile, [Text.Encoding]::UTF8))
            if ($config.schemaVersion -eq 1) {
                foreach ($kind in @('chrome', 'edge')) {
                    foreach ($mapping in $config.browsers.$kind.PSObject.Properties) {
                        if ($mapping.Value -is [string]) { $null = $knownTargets.Add($mapping.Value) }
                    }
                }
            }
        } catch { }
    }
    foreach ($browser in @('chrome', 'edge')) {
        $root = $roots[$browser]
        if (-not [IO.Directory]::Exists($root)) { continue }
        foreach ($profile in Get-ChildItem -LiteralPath $root -Directory) {
            if ($profile.Name -cnotmatch '^(Default|Profile [0-9]+)$') { continue }
            $preferences = Join-Path $profile.FullName 'Secure Preferences'
            if (-not [IO.File]::Exists($preferences)) { continue }
            try {
                $settings = (ConvertFrom-Json ([IO.File]::ReadAllText($preferences, [Text.Encoding]::UTF8))).extensions.settings
                if (-not $settings) { continue }
                foreach ($entry in $settings.PSObject.Properties) {
                    if ($entry.Name -cnotmatch '^[a-p]{32}$' -or $entry.Value.location -ne 4 -or
                        $entry.Value.path -isnot [string]) { continue }
                    $rawPath = $entry.Value.path
                    $paths = if ([IO.Path]::IsPathRooted($rawPath)) { @($rawPath) }
                        else { @((Join-Path $profile.FullName ('Extensions\' + $rawPath)), (Join-Path $profile.FullName $rawPath)) }
                    foreach ($path in $paths) {
                        try {
                            $target = Get-SafeInstallPath $path $hostDir
                            $manifest = Read-ScanSciManifest (Join-Path $target 'manifest.json')
                            if (-not (Test-ScanSciOriginalName $manifest.name) -and -not $knownTargets.Contains($target)) { continue }
                            [pscustomobject]@{ Browser = $browser; Profile = $profile.Name; ExtensionId = $entry.Name; ExtensionPath = $target; Version = $manifest.version }
                            break
                        } catch { continue }
                    }
                }
            } catch { continue }
        }
    }
}

function Find-ScanSciRecoveryTargets([string]$LocalAppData) {
    $hostDir = Join-Path $LocalAppData 'ScanSci\JournalScoutUpdater'
    $configFile = Join-Path $hostDir 'config.json'
    if (-not [IO.File]::Exists($configFile)) { return }
    try {
        Assert-NoReparse $configFile
        $config = ConvertFrom-Json ([IO.File]::ReadAllText($configFile, [Text.Encoding]::UTF8))
        if ($config.schemaVersion -ne 1) { return }
        foreach ($browser in @('chrome', 'edge')) {
            foreach ($mapping in $config.browsers.$browser.PSObject.Properties) {
                if ($mapping.Name -cnotmatch '^[a-p]{32}$' -or $mapping.Value -isnot [string]) { continue }
                try {
                    $target = Get-SafeInstallPath $mapping.Value $hostDir -AllowMissingManifest
                    $backups = Join-Path (Join-Path $target 'releases') 'manifest-backups'
                    Assert-NoReparse $backups
                    if (-not [IO.Directory]::Exists($backups)) { continue }
                    foreach ($file in Get-ChildItem -LiteralPath $backups -File -Filter '*.json') {
                        try {
                            Assert-NoReparse $file.FullName
                            $version = [IO.Path]::GetFileNameWithoutExtension($file.Name)
                            $null = Get-ScanSciVersion $version
                            $null = Assert-ScanSciBackup $target $hostDir $version
                            [pscustomobject]@{ Browser = $browser; ExtensionId = $mapping.Name; ExtensionPath = $target; Version = $version }
                        } catch { continue }
                    }
                } catch { continue }
            }
        }
    } catch { return }
}
