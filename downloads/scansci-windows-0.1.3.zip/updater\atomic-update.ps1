function Get-ScanSciPathHash([string]$Target) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Target.ToLowerInvariant()))).Replace('-', '') }
    finally { $sha.Dispose() }
}

function Get-ScanSciBytesHash([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Get-ScanSciFileHash([string]$Path) {
    Assert-NoReparse $Path
    $stream = [IO.File]::OpenRead($Path)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose(); $stream.Dispose() }
}

function Get-ScanSciManifestIdentity($Manifest) {
    $property = $Manifest.PSObject.Properties['key']
    if ($null -eq $property) { return @{ hasKey = $false; keyHash = '' } }
    if ($property.Value -isnot [string] -or [string]::IsNullOrWhiteSpace($property.Value)) { throw 'invalid_installation' }
    try { $null = [Convert]::FromBase64String($property.Value) } catch { throw 'invalid_installation' }
    return @{ hasKey = $true; keyHash = (Get-ScanSciBytesHash ([Text.Encoding]::UTF8.GetBytes($property.Value))) }
}

function Get-ScanSciBinding([string]$Target, [string]$HostDir) {
    $path = Join-Path (Join-Path $HostDir 'bindings') ((Get-ScanSciPathHash $Target) + '.json')
    Assert-NoReparse $path
    if (-not [IO.File]::Exists($path)) { return $null }
    try {
        $binding = ConvertFrom-Json ([IO.File]::ReadAllText($path, [Text.Encoding]::UTF8))
        if ($binding.schemaVersion -ne 1 -or -not ([string]$binding.target).Equals($Target, [StringComparison]::OrdinalIgnoreCase) -or
            $binding.hasKey -isnot [bool] -or $binding.keyHash -isnot [string] -or
            ($binding.hasKey -and $binding.keyHash -cnotmatch '^[0-9a-f]{64}$') -or
            (-not $binding.hasKey -and $binding.keyHash -cne '')) { throw 'bad binding' }
        return $binding
    } catch { throw 'invalid_installation' }
}

function Ensure-ScanSciBinding([string]$Target, [string]$HostDir, $Manifest) {
    $identity = Get-ScanSciManifestIdentity $Manifest
    $binding = Get-ScanSciBinding $Target $HostDir
    if ($binding) {
        if ($binding.hasKey -ne $identity.hasKey -or $binding.keyHash -cne $identity.keyHash) { throw 'invalid_installation' }
        return
    }
    $dir = Join-Path $HostDir 'bindings'
    Assert-NoReparse $dir
    [IO.Directory]::CreateDirectory($dir) | Out-Null
    $path = Join-Path $dir ((Get-ScanSciPathHash $Target) + '.json')
    Assert-NoReparse $path
    $temp = Join-Path $dir ('.binding-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    try {
        $value = @{ schemaVersion = 1; target = $Target; hasKey = $identity.hasKey; keyHash = $identity.keyHash } | ConvertTo-Json -Compress
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes($value)
        $stream = [IO.File]::Open($temp, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
        [IO.File]::Move($temp, $path)
    } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
}

function Get-ScanSciBlockedState([string]$Target, [string]$HostDir) {
    $file = Join-Path (Join-Path $HostDir 'blocked-updates') ((Get-ScanSciPathHash $Target) + '.json')
    Assert-NoReparse $file
    if (-not [IO.File]::Exists($file)) { return $null }
    try {
        $state = ConvertFrom-Json ([IO.File]::ReadAllText($file, [Text.Encoding]::UTF8))
        if (-not ([string]$state.target).Equals($Target, [StringComparison]::OrdinalIgnoreCase)) { throw 'bad state' }
        if ($state.schemaVersion -eq 1) {
            $null = Get-ScanSciVersion $state.version
            return @{ maxVersion = [string]$state.version; paused = $false; revision = '' }
        }
        if ($state.schemaVersion -ne 2 -or $state.paused -isnot [bool] -or $state.maxVersion -isnot [string]) { throw 'bad state' }
        if ($state.maxVersion) { $null = Get-ScanSciVersion $state.maxVersion }
        if ($state.revision -and $state.revision -cnotmatch '^[0-9a-f]{32}$') { throw 'bad state revision' }
        return @{ maxVersion = [string]$state.maxVersion; paused = $state.paused; revision = [string]$state.revision }
    } catch { throw 'invalid_installation' }
}

function Save-ScanSciBlockedState([string]$Target, [string]$HostDir, [string]$Version, [bool]$Pause, [switch]$ClearPause) {
    if ($Version) { $null = Get-ScanSciVersion $Version }
    $old = Get-ScanSciBlockedState $Target $HostDir
    $maxVersion = if ($old) { $old.maxVersion } else { '' }
    if ($Version -and (-not $maxVersion -or (Get-ScanSciVersion $Version) -gt (Get-ScanSciVersion $maxVersion))) { $maxVersion = $Version }
    $paused = $Pause -or ($old -and $old.paused)
    if ($ClearPause) { $paused = $false }
    $dir = Join-Path $HostDir 'blocked-updates'
    Assert-NoReparse $dir
    [IO.Directory]::CreateDirectory($dir) | Out-Null
    $file = Join-Path $dir ((Get-ScanSciPathHash $Target) + '.json')
    $temp = Join-Path $dir ('.blocked-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    try {
        $content = @{ schemaVersion = 2; target = $Target; maxVersion = [string]$maxVersion; paused = [bool]$paused; revision = [Guid]::NewGuid().ToString('N') } | ConvertTo-Json -Compress
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes($content)
        $stream = [IO.File]::Open($temp, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
        if ([IO.File]::Exists($file)) { [IO.File]::Replace($temp, $file, [System.Management.Automation.Language.NullString]::Value) }
        else { [IO.File]::Move($temp, $file) }
    } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
}

function Resume-ScanSciUpdates([string]$Target, [string]$HostDir, [string]$ExpectedRevision) {
    $targetPath = Get-SafeInstallPath $Target $HostDir -AllowMissingManifest
    $mutex = [Threading.Mutex]::new($false, 'Local\ScanSciJournalScout-' + (Get-ScanSciPathHash $targetPath))
    $locked = $false
    try {
        try { $locked = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $locked = $true }
        if (-not $locked) { throw 'update_in_progress' }
        $state = Get-ScanSciBlockedState $targetPath $HostDir
        if (-not $state -or -not $state.paused -or $state.revision -cne $ExpectedRevision) { throw 'pause_changed' }
        Save-ScanSciBlockedState $targetPath $HostDir '' $false -ClearPause
    } finally { if ($locked) { $mutex.ReleaseMutex() }; $mutex.Dispose() }
}

function Add-ScanSciResource($Value, [Collections.Generic.List[string]]$Paths) {
    if ($null -eq $Value) { return }
    if ($Value -is [string]) { $Paths.Add($Value); return }
    if ($Value -is [array]) { foreach ($item in $Value) { Add-ScanSciResource $item $Paths }; return }
    foreach ($property in $Value.PSObject.Properties) { Add-ScanSciResource $property.Value $Paths }
}

function Get-ScanSciManifestResources($Manifest) {
    $paths = [Collections.Generic.List[string]]::new()
    Add-ScanSciResource $Manifest.icons $paths
    Add-ScanSciResource $Manifest.action.default_icon $paths
    Add-ScanSciResource $Manifest.action.default_popup $paths
    Add-ScanSciResource $Manifest.background.service_worker $paths
    Add-ScanSciResource $Manifest.background.scripts $paths
    Add-ScanSciResource $Manifest.background.page $paths
    Add-ScanSciResource $Manifest.options_ui.page $paths
    Add-ScanSciResource $Manifest.options_page $paths
    Add-ScanSciResource $Manifest.devtools_page $paths
    Add-ScanSciResource $Manifest.side_panel.default_path $paths
    Add-ScanSciResource $Manifest.chrome_url_overrides $paths
    Add-ScanSciResource $Manifest.sandbox.pages $paths
    foreach ($script in $Manifest.content_scripts) {
        Add-ScanSciResource $script.js $paths
        Add-ScanSciResource $script.css $paths
    }
    foreach ($resource in $Manifest.web_accessible_resources) { Add-ScanSciResource $resource.resources $paths }
    foreach ($rule in $Manifest.declarative_net_request.rule_resources) { Add-ScanSciResource $rule.path $paths }
    foreach ($unsupported in @('default_locale', 'theme', 'chrome_settings_overrides', 'file_browser_handlers', 'input_components')) {
        if ($Manifest.PSObject.Properties[$unsupported]) { throw 'invalid_archive' }
    }
    if ($paths.Count -eq 0) { throw 'invalid_archive' }
    return ,$paths.ToArray()
}

function Assert-ScanSciManifestResources($Manifest, [string]$Root) {
    $paths = Get-ScanSciManifestResources $Manifest
    foreach ($path in $paths) {
        Assert-SafeArchivePath $path
        $file = Join-Path $Root $path.Replace('/', '\')
        Assert-NoReparse $file
        if (-not [IO.File]::Exists($file)) { throw 'invalid_archive' }
    }
}

function Assert-ScanSciReleaseManifest($Manifest, [string]$Version, [string]$Stage) {
    $prefix = 'releases/' + $Version + '/'
    if (-not $Manifest.background.service_worker) { throw 'invalid_archive' }
    Assert-ScanSciManifestResources $Manifest $Stage
    foreach ($path in (Get-ScanSciManifestResources $Manifest)) {
        if (-not $path.StartsWith($prefix, [StringComparison]::Ordinal)) { throw 'invalid_archive' }
    }
}

function Get-ScanSciBackupFiles($Manifest, [string]$Target) {
    $names = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($path in (Get-ScanSciManifestResources $Manifest)) { $null = $names.Add($path) }
    $versionRoot = Join-Path (Join-Path $Target 'releases') $Manifest.version
    if ([IO.Directory]::Exists($versionRoot)) {
        Assert-NoReparse $versionRoot
        $items = @(Get-ChildItem -LiteralPath $versionRoot -Recurse -Force)
        foreach ($item in $items) {
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'invalid_installation' }
            if (-not $item.PSIsContainer) { $null = $names.Add($item.FullName.Substring($Target.Length + 1).Replace('\', '/')) }
        }
    } else {
        foreach ($item in Get-ChildItem -LiteralPath $Target -File -Force) {
            if ($item.Extension -cin @('.js', '.css', '.html', '.png', '.svg', '.jpg', '.jpeg', '.gif', '.woff', '.woff2', '.ttf')) {
                if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'invalid_installation' }
                $null = $names.Add($item.Name)
            }
        }
    }
    if ($names.Count -eq 0 -or $names.Count -gt 500) { throw 'invalid_installation' }
    return ,@($names | Sort-Object)
}

function Assert-ScanSciBackup([string]$Target, [string]$HostDir, [string]$Version) {
    $backupDir = Join-Path (Join-Path $Target 'releases') 'manifest-backups'
    $backup = Join-Path $backupDir ($Version + '.json')
    $integrityFile = Join-Path $backupDir ($Version + '.integrity.json')
    Assert-NoReparse $backup
    Assert-NoReparse $integrityFile
    if (-not [IO.File]::Exists($backup) -or -not [IO.File]::Exists($integrityFile)) { throw 'invalid_installation' }
    $manifest = Read-ScanSciManifest $backup
    if ($manifest.version -cne $Version) { throw 'invalid_installation' }
    $binding = Get-ScanSciBinding $Target $HostDir
    $identity = Get-ScanSciManifestIdentity $manifest
    if (-not $binding -or $binding.hasKey -ne $identity.hasKey -or $binding.keyHash -cne $identity.keyHash) { throw 'invalid_installation' }
    Assert-ScanSciManifestResources $manifest $Target
    try {
        $integrity = ConvertFrom-Json ([IO.File]::ReadAllText($integrityFile, [Text.Encoding]::UTF8))
        if ($integrity.schemaVersion -ne 1 -or $integrity.version -cne $Version -or
            $integrity.manifestSha256 -cne (Get-ScanSciFileHash $backup) -or $integrity.files -isnot [array]) { throw 'bad integrity' }
        $expected = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        foreach ($path in (Get-ScanSciManifestResources $manifest)) { $null = $expected.Add($path) }
        $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        if ($integrity.files.Count -eq 0 -or $integrity.files.Count -gt 500) { throw 'bad file count' }
        foreach ($item in $integrity.files) {
            if ($item.path -isnot [string] -or -not $seen.Add($item.path)) { throw 'bad file' }
            $null = $expected.Remove($item.path)
            Assert-SafeArchivePath $item.path
            $file = Join-Path $Target $item.path.Replace('/', '\')
            if ($item.sha256 -cnotmatch '^[0-9a-f]{64}$' -or $item.sha256 -cne (Get-ScanSciFileHash $file)) { throw 'bad file hash' }
        }
        if ($expected.Count -ne 0) { throw 'missing files' }
    } catch { throw 'invalid_installation' }
    return $manifest
}

function Save-ScanSciPreviousManifest([string]$Target, [string]$HostDir, $Current) {
    Assert-ScanSciManifestResources $Current $Target
    $rootManifest = Join-Path $Target 'manifest.json'
    Assert-NoReparse $rootManifest
    $backupDir = Join-Path (Join-Path $Target 'releases') 'manifest-backups'
    Assert-NoReparse $backupDir
    [IO.Directory]::CreateDirectory($backupDir) | Out-Null
    $backup = Join-Path $backupDir ($Current.version + '.json')
    Assert-NoReparse $backup
    $contents = [IO.File]::ReadAllBytes($rootManifest)
    if ([IO.File]::Exists($backup)) {
        if ([Convert]::ToBase64String([IO.File]::ReadAllBytes($backup)) -cne [Convert]::ToBase64String($contents)) { throw 'invalid_installation' }
    } else {
        $temp = Join-Path $backupDir ('.manifest-backup-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        try {
            $stream = [IO.File]::Open($temp, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
            try { $stream.Write($contents, 0, $contents.Length); $stream.Flush($true) } finally { $stream.Dispose() }
            [IO.File]::Move($temp, $backup)
        } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
    }
    $integrityFile = Join-Path $backupDir ($Current.version + '.integrity.json')
    Assert-NoReparse $integrityFile
    if (-not [IO.File]::Exists($integrityFile)) {
        $files = @(foreach ($path in (Get-ScanSciBackupFiles $Current $Target)) {
            @{ path = $path; sha256 = (Get-ScanSciFileHash (Join-Path $Target $path.Replace('/', '\'))) }
        })
        $integrity = @{ schemaVersion = 1; version = $Current.version; manifestSha256 = (Get-ScanSciFileHash $backup); files = $files }
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($integrity | ConvertTo-Json -Compress -Depth 5))
        $temp = Join-Path $backupDir ('.integrity-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        try {
            $stream = [IO.File]::Open($temp, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
            try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
            [IO.File]::Move($temp, $integrityFile)
        } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
    }
    $null = Assert-ScanSciBackup $Target $HostDir $Current.version
}

function Invoke-ScanSciRestore([string]$Target, [string]$HostDir, [string]$Version) {
    $null = Get-ScanSciVersion $Version
    $targetPath = Get-SafeInstallPath $Target $HostDir -AllowMissingManifest
    $mutex = [Threading.Mutex]::new($false, 'Local\ScanSciJournalScout-' + (Get-ScanSciPathHash $targetPath))
    $locked = $false
    $temp = $null
    try {
        try { $locked = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $locked = $true }
        if (-not $locked) { throw 'update_in_progress' }
        $backup = Join-Path (Join-Path (Join-Path $targetPath 'releases') 'manifest-backups') ($Version + '.json')
        Assert-NoReparse $backup
        if (-not [IO.File]::Exists($backup)) { throw 'invalid_installation' }
        $manifest = Assert-ScanSciBackup $targetPath $HostDir $Version
        try { $current = Read-ScanSciManifest (Join-Path $targetPath 'manifest.json') } catch { $current = $null }
        if ($current -and (Get-ScanSciVersion $current.version) -gt (Get-ScanSciVersion $Version)) {
            Save-ScanSciBlockedState $targetPath $HostDir $current.version $false
        } elseif (-not $current -or (Get-ScanSciFileHash (Join-Path $targetPath 'manifest.json')) -cne (Get-ScanSciFileHash $backup)) {
            Save-ScanSciBlockedState $targetPath $HostDir '' $true
        }
        $temp = Join-Path $targetPath ('.scansci-restore-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        $contents = [IO.File]::ReadAllBytes($backup)
        $stream = [IO.File]::Open($temp, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try { $stream.Write($contents, 0, $contents.Length); $stream.Flush($true) } finally { $stream.Dispose() }
        $rootManifest = Join-Path $targetPath 'manifest.json'
        Assert-NoReparse $rootManifest
        if ([IO.File]::Exists($rootManifest)) { [IO.File]::Replace($temp, $rootManifest, [System.Management.Automation.Language.NullString]::Value) }
        else { [IO.File]::Move($temp, $rootManifest) }
        return @{ status = 'restored'; version = $Version }
    } finally {
        if ($temp -and [IO.File]::Exists($temp)) { [IO.File]::Delete($temp) }
        if ($locked) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}

function Test-ScanSciSameDirectory([string]$Expected, [string]$Actual) {
    Assert-NoReparse $Actual
    $expectedFiles = @(Get-ChildItem -LiteralPath $Expected -File -Recurse -Force)
    $actualItems = @(Get-ChildItem -LiteralPath $Actual -Recurse -Force)
    foreach ($item in $actualItems) { if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { return $false } }
    $actualFiles = @($actualItems | Where-Object { -not $_.PSIsContainer })
    if ($expectedFiles.Count -ne $actualFiles.Count) { return $false }
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        foreach ($file in $expectedFiles) {
            $relative = $file.FullName.Substring($Expected.Length + 1)
            $otherPath = Join-Path $Actual $relative
            if (-not [IO.File]::Exists($otherPath)) { return $false }
            $other = Get-Item -LiteralPath $otherPath -Force
            if ($file.Length -ne $other.Length) { return $false }
            $a = [IO.File]::OpenRead($file.FullName)
            $b = [IO.File]::OpenRead($otherPath)
            try { $aHash = [Convert]::ToBase64String($sha.ComputeHash($a)); $bHash = [Convert]::ToBase64String($sha.ComputeHash($b)) }
            finally { $a.Dispose(); $b.Dispose() }
            if ($aHash -cne $bHash) { return $false }
        }
        return $true
    } finally { $sha.Dispose() }
}

function Install-ScanSciRelease([string]$Stage, [string]$Target, [string]$HostDir, [string]$Version, $Current, [scriptblock]$PhaseHook) {
    $releaseRoot = Join-Path $Target 'releases'
    $stagedRelease = Join-Path (Join-Path $Stage 'releases') $Version
    $release = Join-Path $releaseRoot $Version
    if (-not [IO.Directory]::Exists($stagedRelease)) { throw 'invalid_archive' }
    Assert-NoReparse $releaseRoot
    Assert-NoReparse $release
    Save-ScanSciPreviousManifest $Target $HostDir $Current
    if ($PhaseHook) { & $PhaseHook 'before-release-move' }
    if ([IO.Directory]::Exists($release)) {
        if (-not (Test-ScanSciSameDirectory $stagedRelease $release)) { throw 'invalid_installation' }
    } else { [IO.Directory]::Move($stagedRelease, $release) }
    if ($PhaseHook) { & $PhaseHook 'after-release-move' }
    $manifestFile = Join-Path $Target 'manifest.json'
    Assert-NoReparse $manifestFile
    $tempManifest = Join-Path $Target ('.scansci-manifest-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    try {
        $contents = [IO.File]::ReadAllBytes((Join-Path $Stage 'manifest.json'))
        $stream = [IO.File]::Open($tempManifest, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try { $stream.Write($contents, 0, $contents.Length); $stream.Flush($true) } finally { $stream.Dispose() }
        if ($PhaseHook) { & $PhaseHook 'before-manifest-replace' }
        [IO.File]::Replace($tempManifest, $manifestFile, [System.Management.Automation.Language.NullString]::Value)
        if ($PhaseHook) { & $PhaseHook 'after-manifest-replace' }
    } finally { if ([IO.File]::Exists($tempManifest)) { [IO.File]::Delete($tempManifest) } }
}

function Invoke-ScanSciUpdate {
    param(
        [ValidateSet('chrome', 'edge')][string]$Browser,
        [string]$CallerOrigin, [string]$RequestedVersion,
        [string]$ConfigPath, [string]$TrustedKeyPath,
        [scriptblock]$Fetcher = ${function:Get-ScanSciRemoteBytes},
        [scriptblock]$PhaseHook = $null
    )
    if ($CallerOrigin -cnotmatch '^chrome-extension://([a-p]{32})/$') { throw 'unknown_extension' }
    $extensionId = $Matches[1]
    $requested = Get-ScanSciVersion $RequestedVersion
    try {
        $config = ConvertFrom-Json ([IO.File]::ReadAllText($ConfigPath, [Text.Encoding]::UTF8))
        if ($config.schemaVersion -ne 1) { throw 'bad config' }
        $property = $config.browsers.$Browser.PSObject.Properties[$extensionId]
        if ($null -eq $property -or $property.Value -isnot [string]) { throw 'unknown_extension' }
    } catch { throw 'unknown_extension' }
    $target = Get-SafeInstallPath $property.Value (Split-Path -Parent $TrustedKeyPath)
    $mutex = [Threading.Mutex]::new($false, 'Local\ScanSciJournalScout-' + (Get-ScanSciPathHash $target))
    $locked = $false
    $stage = $null
    try {
        try { $locked = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $locked = $true }
        if (-not $locked) { throw 'update_in_progress' }
        $current = Read-ScanSciManifest (Join-Path $target 'manifest.json')
        if ($current.version -cne $RequestedVersion) { return @{ status = 'reload_required'; version = $current.version } }
        $hostDir = Split-Path -Parent $TrustedKeyPath
        Ensure-ScanSciBinding $target $hostDir $current
        $rsa = Read-ScanSciPublicKey $TrustedKeyPath
        try {
            $metadataBytes = [byte[]](& $Fetcher 'https://journal.scansci.com/updates/chromium.json' 65536)
            try {
                $envelope = ConvertFrom-Json ([Text.UTF8Encoding]::new($false, $true).GetString($metadataBytes))
                $payloadBytes = [Convert]::FromBase64String([string]$envelope.payload)
                $signature = [Convert]::FromBase64String([string]$envelope.signature)
                if ($payloadBytes.Length -eq 0 -or $payloadBytes.Length -gt 16384 -or $signature.Length -eq 0 -or $signature.Length -gt 1024) { throw 'bad envelope' }
            } catch { throw 'invalid_metadata' }
            if (-not $rsa.VerifyData($payloadBytes, $signature, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1)) { throw 'invalid_signature' }
            try {
                $payload = ConvertFrom-Json ([Text.UTF8Encoding]::new($false, $true).GetString($payloadBytes))
                $offered = Get-ScanSciVersion $payload.version
                $expectedUrl = 'https://journal.scansci.com/downloads/scansci-chromium-' + $payload.version + '.zip'
                if ($payload.url -cne $expectedUrl -or $payload.sha256 -cnotmatch '^[0-9a-f]{64}$' -or
                    ($payload.size -isnot [int] -and $payload.size -isnot [long]) -or
                    $payload.size -lt 1 -or $payload.size -gt 20971520) { throw 'bad payload' }
            } catch { throw 'invalid_metadata' }
            $blocked = Get-ScanSciBlockedState $target $hostDir
            if ($blocked -and $blocked.paused) { return @{ status = 'updates_paused'; version = $RequestedVersion } }
            if ($offered -le $requested) { return @{ status = 'up_to_date'; version = $RequestedVersion } }
            if ($blocked -and $blocked.maxVersion -and $offered -le (Get-ScanSciVersion $blocked.maxVersion)) {
                return @{ status = 'blocked_version'; version = $payload.version }
            }
            $bytes = [byte[]](& $Fetcher $payload.url 20971520)
            if ($bytes.Length -ne $payload.size) { throw 'invalid_download' }
            $sha = [Security.Cryptography.SHA256]::Create()
            try { $actualHash = [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-', '').ToLowerInvariant() }
            finally { $sha.Dispose() }
            if ($actualHash -cne $payload.sha256) { throw 'invalid_download' }
            $releaseRoot = Join-Path $target 'releases'
            Assert-NoReparse $releaseRoot
            [IO.Directory]::CreateDirectory($releaseRoot) | Out-Null
            $stage = Join-Path $releaseRoot ('.stage-' + [Guid]::NewGuid().ToString('N'))
            [IO.Directory]::CreateDirectory($stage) | Out-Null
            Expand-ScanSciArchive $bytes $stage $payload.version
            try { $newManifest = Read-ScanSciManifest (Join-Path $stage 'manifest.json') } catch { throw 'invalid_archive' }
            if ($newManifest.version -cne $payload.version -or [string]$newManifest.key -cne [string]$current.key) { throw 'invalid_archive' }
            Assert-ScanSciReleaseManifest $newManifest $payload.version $stage
            try { Install-ScanSciRelease $stage $target $hostDir $payload.version $current $PhaseHook }
            catch {
                if ($_.Exception.Message -cin @('invalid_archive', 'invalid_installation')) { throw }
                throw 'update_failed'
            }
            return @{ status = 'updated'; version = $payload.version }
        } finally { $rsa.Dispose() }
    } finally {
        if ($stage -and [IO.Directory]::Exists($stage)) {
            try {
                $releaseFull = [IO.Path]::GetFullPath((Join-Path $target 'releases')).TrimEnd('\')
                $stageFull = [IO.Path]::GetFullPath($stage).TrimEnd('\')
                if (-not ([IO.Path]::GetDirectoryName($stageFull)).Equals($releaseFull, [StringComparison]::OrdinalIgnoreCase) -or
                    [IO.Path]::GetFileName($stageFull) -cnotmatch '^\.stage-[0-9a-f]{32}$') { throw 'invalid_installation' }
                Assert-NoReparse $stageFull
                foreach ($item in Get-ChildItem -LiteralPath $stageFull -Recurse -Force) {
                    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'invalid_installation' }
                }
                [IO.Directory]::Delete($stageFull, $true)
            } catch { }
        }
        if ($locked) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}
