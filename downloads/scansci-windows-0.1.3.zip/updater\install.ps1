param(
    [Parameter(Mandatory = $true)][ValidatePattern('^[a-p]{32}$')][string]$ExtensionId,
    [Parameter(Mandatory = $true)][string]$ExtensionPath,
    [Parameter(Mandatory = $true)][ValidateSet('chrome', 'edge')][string]$Browser
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'updater.ps1')
. (Join-Path $PSScriptRoot 'installer-transaction.ps1')
$hostDir = Join-Path $env:LOCALAPPDATA 'ScanSci\JournalScoutUpdater'
$destination = Get-SafeInstallPath $ExtensionPath $hostDir
$targetManifest = Read-ScanSciManifest (Join-Path $destination 'manifest.json')
$sourceKey = Read-ScanSciPublicKey (Join-Path $PSScriptRoot 'trusted-key.xml')
try { $sourcePublic = $sourceKey.ToXmlString($false) } finally { $sourceKey.Dispose() }

$mutex = [Threading.Mutex]::new($false, 'Local\ScanSciJournalScout-Installer')
$locked = $false
try {
    $locked = $mutex.WaitOne(0)
    if (-not $locked) { throw 'Another installation is in progress.' }
    $configFile = Join-Path $hostDir 'config.json'
    $pendingFile = Join-Path $hostDir 'install-pending.json'
    Assert-NoReparse $hostDir
    Assert-NoReparse $configFile
    Assert-NoReparse $pendingFile
    $existingKeyPath = Join-Path $hostDir 'trusted-key.xml'
    Assert-NoReparse $existingKeyPath
    if ([IO.File]::Exists($existingKeyPath)) {
        $existingKey = Read-ScanSciPublicKey $existingKeyPath
        try { $existingPublic = $existingKey.ToXmlString($false) } finally { $existingKey.Dispose() }
        if ($existingPublic -cne $sourcePublic) { throw 'The installed updater uses a different release signing key.' }
    }
    $registryPaths = @{
        chrome = 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.scansci.journal_scout_updater'
        edge = 'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\com.scansci.journal_scout_updater'
    }
    foreach ($kind in @('chrome', 'edge')) {
        if (Test-Path -LiteralPath $registryPaths[$kind]) {
            $registered = (Get-Item -LiteralPath $registryPaths[$kind]).GetValue('')
            $manifestPath = Join-Path $hostDir ('native-messaging.' + $kind + '.json')
            if ($registered -and -not ([string]$registered).Equals($manifestPath, [StringComparison]::OrdinalIgnoreCase)) {
                throw "A different updater is already registered for $kind."
            }
        }
    }
    if ([IO.Directory]::Exists($hostDir) -and -not [IO.File]::Exists($configFile) -and
        -not [IO.File]::Exists($pendingFile) -and @(Get-ChildItem -LiteralPath $hostDir -Force).Count -gt 0) { throw 'The updater folder already contains unrecognized files.' }
    Complete-ScanSciInstallPlan $hostDir
    if ([IO.File]::Exists($configFile)) {
        $config = ConvertFrom-Json ([IO.File]::ReadAllText($configFile, [Text.Encoding]::UTF8))
        if ($config.schemaVersion -ne 1 -or -not $config.browsers.chrome -or -not $config.browsers.edge) { throw 'Invalid existing updater configuration.' }
        $existing = $config.browsers.$Browser.PSObject.Properties[$ExtensionId]
        if ($existing -and -not [IO.Path]::GetFullPath([string]$existing.Value).Equals($destination, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'This browser and extension ID already point to a different folder.'
        }
    } else {
        $config = [pscustomobject]@{ schemaVersion = 1; browsers = [pscustomobject]@{ chrome = [pscustomobject]@{}; edge = [pscustomobject]@{} } }
    }
    $knownTarget = $false
    foreach ($kind in @('chrome', 'edge')) {
        foreach ($mapping in $config.browsers.$kind.PSObject.Properties) {
            if (([string]$mapping.Value).Equals($destination, [StringComparison]::OrdinalIgnoreCase)) { $knownTarget = $true }
        }
    }
    if (-not $knownTarget -and -not (Test-ScanSciOriginalName $targetManifest.name)) { throw 'invalid_installation' }
    foreach ($kind in @('chrome', 'edge')) {
        $manifestPath = Join-Path $hostDir ('native-messaging.' + $kind + '.json')
        Assert-ScanSciNativeManifest $manifestPath $hostDir $kind $config.browsers.$kind
    }
    $config.browsers.$Browser | Add-Member -NotePropertyName $ExtensionId -NotePropertyValue $destination -Force
    foreach ($kind in @('chrome', 'edge')) {
        $mappings = @($config.browsers.$kind.PSObject.Properties)
        foreach ($mapping in $mappings) {
            if ($mapping.Name -cnotmatch '^[a-p]{32}$' -or $mapping.Value -isnot [string]) { throw 'Invalid existing updater configuration.' }
        }
        if ($mappings.Count -eq 0) { continue }
        $manifestPath = Join-Path $hostDir ('native-messaging.' + $kind + '.json')
        Assert-NoReparse $manifestPath
        if (Test-Path -LiteralPath $registryPaths[$kind]) {
            $registered = (Get-Item -LiteralPath $registryPaths[$kind]).GetValue('')
            if ($registered -and -not ([string]$registered).Equals($manifestPath, [StringComparison]::OrdinalIgnoreCase)) {
                throw "A different updater is already registered for $kind."
            }
        }
    }
    foreach ($name in @('host.ps1', 'host-chrome.cmd', 'host-edge.cmd', 'updater.ps1', 'atomic-update.ps1', 'find-installations.ps1', 'repair.ps1', 'repair.cmd')) {
        $sourceFile = Join-Path $PSScriptRoot $name
        $destinationFile = Join-Path $hostDir $name
        Assert-NoReparse $destinationFile
        if ([IO.File]::Exists($destinationFile) -and
            [Convert]::ToBase64String([IO.File]::ReadAllBytes($sourceFile)) -cne [Convert]::ToBase64String([IO.File]::ReadAllBytes($destinationFile))) {
            throw 'An existing updater file is different; it was not overwritten.'
        }
    }
    $binding = Get-ScanSciBinding $destination $hostDir
    $identity = Get-ScanSciManifestIdentity $targetManifest
    if ($binding -and ($binding.hasKey -ne $identity.hasKey -or $binding.keyHash -cne $identity.keyHash)) { throw 'invalid_installation' }
    $documents = [ordered]@{ 'config.json' = ($config | ConvertTo-Json -Depth 6) }
    foreach ($kind in @('chrome', 'edge')) {
        $ids = @($config.browsers.$kind.PSObject.Properties | ForEach-Object { $_.Name })
        if ($ids.Count -eq 0) { continue }
        $nativeManifest = @{
            name = 'com.scansci.journal_scout_updater'
            description = 'Journal Scout updater'
            path = (Join-Path $hostDir ('host-' + $kind + '.cmd'))
            type = 'stdio'
            allowed_origins = @($ids | ForEach-Object { 'chrome-extension://' + $_ + '/' })
        }
        $documents['native-messaging.' + $kind + '.json'] = $nativeManifest | ConvertTo-Json -Depth 4
    }
    [IO.Directory]::CreateDirectory($hostDir) | Out-Null
    New-ScanSciInstallPlan $hostDir $documents
    Ensure-ScanSciBinding $destination $hostDir $targetManifest
    foreach ($name in @('host.ps1', 'host-chrome.cmd', 'host-edge.cmd', 'updater.ps1', 'atomic-update.ps1', 'find-installations.ps1', 'repair.ps1', 'repair.cmd')) {
        $destinationFile = Join-Path $hostDir $name
        if (-not [IO.File]::Exists($destinationFile)) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $destinationFile }
    }
    if (-not [IO.File]::Exists($existingKeyPath)) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'trusted-key.xml') -Destination $existingKeyPath }
    Complete-ScanSciInstallPlan $hostDir
    foreach ($kind in @('chrome', 'edge')) {
        $ids = @($config.browsers.$kind.PSObject.Properties | ForEach-Object { $_.Name })
        if ($ids.Count -eq 0) { continue }
        $manifestPath = Join-Path $hostDir ('native-messaging.' + $kind + '.json')
        New-Item -Path $registryPaths[$kind] -Force | Out-Null
        (Get-Item -LiteralPath $registryPaths[$kind]).SetValue('', $manifestPath)
    }
    Write-Host 'Journal Scout updater is installed for the selected browser and extension.'
} finally {
    if ($locked) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}
