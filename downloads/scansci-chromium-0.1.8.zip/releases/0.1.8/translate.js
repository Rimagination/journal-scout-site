(() => {
  if (globalThis.ScanSciTranslationLoaded) return;
  globalThis.ScanSciTranslationLoaded = true;
  const api = globalThis.chrome || globalThis.browser;
  const core = globalThis.ScanSciCore;
  let settings = core.translationSettings();
  let rawSettings = { ...core.translationDefaults };
  let ready = false, panel, panelGeneration = 0, titleGeneration = 0, titleTimer, running = false;
  let panelRequest, titleRequest, initialChanges = {};
  let seenTitles = new WeakMap(), titleQueue = [], titleCount = 0, titleFailed = false;

  function send(text, target, requestId) {
    return new Promise(resolve => {
      try { api.runtime.sendMessage({ type: 'translate', text, target, provider: settings.translationProvider, requestId }, response => {
        resolve(api.runtime.lastError ? null : response);
      }); } catch { resolve(null); }
    });
  }
  function cancel(requestId) {
    if (!requestId) return;
    try { api.runtime.sendMessage({ type: 'cancelTranslation', requestId }, () => { void api.runtime.lastError; }); } catch {}
  }
  function errorText(error) {
    if (error === 'translation_quota') return '翻译服务暂时限流，请稍后再试或在设置中切换服务。';
    if (error === 'invalid_translation_text') return '请选择不超过 1500 个字符的文字。';
    if (error === 'translation_busy') return '翻译请求较多，请稍后再试。';
    if (error === 'translation_fragmented') return '文本段落过多，请分段选择后重试。';
    return '翻译暂时不可用，请检查网络或在设置中切换服务。';
  }

  // Lucide languages and x icons, ISC license (https://lucide.dev).
  function icon(paths) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    for (const [name, value] of Object.entries({ viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', 'stroke-width': '2', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true' })) svg.setAttribute(name, value);
    for (const value of paths) { const path = document.createElementNS('http://www.w3.org/2000/svg', 'path'); path.setAttribute('d', value); svg.append(path); }
    return svg;
  }
  function closePanel() { panelGeneration += 1; cancel(panelRequest); panelRequest = null; panel?.remove(); panel = null; }
  function openPanel(rect) {
    closePanel();
    panel = document.createElement('div');
    panel.className = 'scansci-translation-panel';
    panel.setAttribute('role', 'region');
    panel.setAttribute('aria-label', 'Journal Scout 划词翻译');
    const heading = document.createElement('div'); heading.className = 'scansci-translation-heading';
    const label = document.createElement('span'); label.className = 'scansci-translation-label';
    label.append(icon(['m5 8 6 6', 'm4 14 6-6 2-3', 'M2 5h12', 'M7 2h1', 'm22 22-5-10-5 10', 'M14 18h6']), document.createTextNode('Journal Scout 翻译'));
    const close = document.createElement('button'); close.type = 'button'; close.setAttribute('aria-label', '关闭翻译');
    close.append(icon(['M18 6 6 18', 'm6 6 12 12'])); close.addEventListener('click', closePanel);
    heading.append(label, close);
    const output = document.createElement('div'); output.className = 'scansci-translation-output'; output.setAttribute('aria-live', 'polite');
    output.textContent = '正在翻译…';
    const footer = document.createElement('div'); footer.className = 'scansci-translation-footer'; footer.textContent = core.translationProviders[settings.translationProvider] + ' · 中英翻译';
    panel.append(heading, output, footer);
    document.documentElement.append(panel);
    const width = Math.min(380, Math.max(160, window.innerWidth - 24));
    panel.style.setProperty('left', `${Math.max(12, Math.min(rect.left, window.innerWidth - width - 12))}px`, 'important');
    panel.style.setProperty('top', `${Math.max(12, Math.min(rect.bottom + 8, window.innerHeight - 150))}px`, 'important');
    return output;
  }
  async function translateSelection() {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.rangeCount) return false;
    const range = selection.getRangeAt(0);
    const parent = range.commonAncestorContainer.parentElement;
    if (parent?.closest('.scansci-translation-panel')) return false;
    const text = selection.toString().trim();
    if (!text) return false;
    const output = openPanel(range.getBoundingClientRect());
    const generation = panelGeneration;
    if (Array.from(text).length > 1500) { output.textContent = errorText('invalid_translation_text'); return true; }
    const requestId = crypto.randomUUID(); panelRequest = requestId;
    const response = await send(text, settings.translationTarget, requestId);
    if (panelRequest === requestId) panelRequest = null;
    if (generation === panelGeneration && panel?.isConnected) output.textContent = response?.ok ? response.data.text : errorText(response?.error);
    return true;
  }
  document.addEventListener('keydown', event => {
    if (!ready || !settings.translationEnabled || !event.isTrusted || event.repeat || event.isComposing || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
    const target = event.target;
    if (target?.isContentEditable || target?.closest?.('input, textarea, select, [contenteditable="true"]')) return;
    const key = event.key.toUpperCase();
    if (key === settings.translationCloseKey && panel) { closePanel(); event.preventDefault(); return; }
    if (key === settings.translationKey && window.getSelection()?.toString().trim()) {
      event.preventDefault(); void translateSelection();
    }
  });

  function titleNodes() {
    const host = location.hostname;
    let selector = '';
    if (host.startsWith('scholar.google.')) selector = '.gs_r .gs_rt a';
    else if (host === 'pubmed.ncbi.nlm.nih.gov') selector = '.docsum-title, h1.heading-title';
    else if (host === 'kns.cnki.net') selector = 'td.name > a';
    else if (host === 'nature.com' || host.endsWith('.nature.com')) selector = 'h3.c-card__title a, h1.c-article-title';
    const nodes = selector ? [...document.querySelectorAll(selector)] : [];
    const metadata = document.querySelector('meta[name="citation_title" i]')?.content?.trim();
    const heading = core.articleHeading(document);
    if (metadata && heading && heading.textContent.trim().replace(/\s+/g, ' ') === metadata.replace(/\s+/g, ' ')) nodes.push(heading);
    return [...new Set(nodes)];
  }
  function attachTitle(target, entry) {
    if (!entry.node) {
      entry.node = document.createElement('span'); entry.node.className = 'scansci-title-translation';
      entry.node.textContent = entry.translation; entry.node.setAttribute('lang', 'zh-CN');
      entry.node.scansciTitleTarget = target;
    }
    target.insertAdjacentElement('afterend', entry.node);
  }
  function scanTitles() {
    if (!ready || !settings.translationEnabled || !settings.autoTranslateTitles) return;
    for (const node of document.querySelectorAll('.scansci-title-translation')) {
      const target = node.scansciTitleTarget;
      if (!target?.isConnected || seenTitles.get(target)?.node !== node || core.adjacentCompanion(target, 'scansci-title-translation') !== node) node.remove();
    }
    if (titleFailed) return;
    titleQueue = titleQueue.filter(item => {
      const current = item.target.isConnected && seenTitles.get(item.target) === item.entry && item.target.textContent.trim().replace(/\s+/g, ' ') === item.entry.text;
      if (!current && seenTitles.get(item.target) === item.entry) seenTitles.delete(item.target);
      return current;
    });
    for (const target of titleNodes()) {
      const text = target.textContent.trim().replace(/\s+/g, ' ');
      const previous = seenTitles.get(target);
      if (previous?.text === text) {
        if (previous.translation && !previous.node?.isConnected) attachTitle(target, previous);
        continue;
      }
      previous?.node?.remove();
      if (titleCount + titleQueue.length >= 20 || text.length < 5 || Array.from(text).length > 1500 || !/[a-z]/i.test(text) || /[\u3400-\u9fff]/.test(text)) continue;
      const entry = { text }; seenTitles.set(target, entry); titleQueue.push({ target, entry });
    }
    void runTitles();
  }
  async function runTitles() {
    if (running || !ready || !settings.translationEnabled || !settings.autoTranslateTitles || titleFailed) return;
    const item = titleQueue.shift();
    if (!item) return;
    if (!item.target.isConnected || seenTitles.get(item.target) !== item.entry || item.target.textContent.trim().replace(/\s+/g, ' ') !== item.entry.text) { void runTitles(); return; }
    if (titleCount >= 20) return;
    titleCount += 1;
    running = true;
    const generation = titleGeneration;
    const requestId = crypto.randomUUID(); titleRequest = requestId;
    const response = await send(item.entry.text, 'zh-CN', requestId);
    if (generation !== titleGeneration) return;
    if (titleRequest === requestId) titleRequest = null;
    running = false;
    if (item.target.isConnected && seenTitles.get(item.target) === item.entry && item.target.textContent.trim().replace(/\s+/g, ' ') === item.entry.text) {
      if (response?.ok) { item.entry.translation = response.data.text; attachTitle(item.target, item.entry); }
      else { item.entry.translation = errorText(response?.error); attachTitle(item.target, item.entry); titleFailed = true; titleQueue = []; }
    }
    if (!titleFailed) titleTimer = setTimeout(runTitles, 1000);
  }
  function clearTitles() {
    titleGeneration += 1; cancel(titleRequest); titleRequest = null; clearTimeout(titleTimer); running = false; titleQueue = []; titleCount = 0; titleFailed = false; seenTitles = new WeakMap();
    document.querySelectorAll('.scansci-title-translation').forEach(node => node.remove());
  }
  api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const updates = {};
    for (const key of Object.keys(core.translationDefaults)) if (changes[key]) updates[key] = changes[key].newValue ?? core.translationDefaults[key];
    if (!Object.keys(updates).length) return;
    if (!ready) { Object.assign(initialChanges, updates); return; }
    const wasActive = settings.translationEnabled && settings.autoTranslateTitles;
    const previousProvider = settings.translationProvider;
    rawSettings = { ...rawSettings, ...updates };
    settings = core.translationSettings(rawSettings);
    const active = settings.translationEnabled && settings.autoTranslateTitles;
    if (!settings.translationEnabled || previousProvider !== settings.translationProvider) closePanel();
    if ((wasActive && !active) || previousProvider !== settings.translationProvider) clearTitles();
    if (active && (!wasActive || previousProvider !== settings.translationProvider)) scanTitles();
  });
  api.storage.local.get(core.translationDefaults, values => { rawSettings = { ...values, ...initialChanges }; settings = core.translationSettings(rawSettings); initialChanges = {}; ready = true; scanTitles(); });
  let scanTimer;
  new MutationObserver(records => {
    if (!ready || !settings.translationEnabled || !settings.autoTranslateTitles) return;
    if (!records.some(record => {
      if (record.type !== 'attributes') return true;
      if (record.attributeName !== 'class') return record.target.tagName === 'META';
      const external = value => String(value || '').split(/\s+/).filter(name => name && !name.startsWith('scansci-')).sort().join(' ');
      return external(record.oldValue) !== external(record.target.getAttribute('class'));
    })) return;
    clearTimeout(scanTimer); scanTimer = setTimeout(scanTitles, 500);
  }).observe(document.documentElement, { childList: true, characterData: true, attributes: true, attributeOldValue: true, attributeFilter: ['content', 'name', 'class'], subtree: true });
})();
