(() => {
  if (globalThis.ScanSciTranslationLoaded) return;
  globalThis.ScanSciTranslationLoaded = true;
  const api = globalThis.chrome || globalThis.browser;
  const core = globalThis.ScanSciCore;
  let settings = core.translationSettings();
  let rawSettings = { ...core.translationDefaults };
  let ready = false, panel, panelGeneration = 0, titleGeneration = 0, titleTimer, running = false;
  let panelRequest, titleRequest, initialChanges = {}, touchTrigger, touchSnapshot, touchTimer;
  let seenTitles = new WeakMap(), titleQueue = [], titleCount = 0, titleFailed = false;

  function send(text, target, requestId) {
    return new Promise(resolve => {
      try { api.runtime.sendMessage({ type: 'translate', text, target, provider: settings.translationProvider, requestId }, response => {
        resolve(api.runtime.lastError ? null : response);
      }); } catch { resolve(null); }
    });
  }
  function cancel(requestId) {
    if (!requestId) return;
    try { api.runtime.sendMessage({ type: 'cancelTranslation', requestId }, () => { void api.runtime.lastError; }); } catch {}
  }
  function errorText(error) {
    if (error === 'translation_quota') return '翻译服务暂时限流，请稍后再试或在设置中切换服务。';
    if (error === 'invalid_translation_text') return '请选择不超过 1500 个字符的文字。';
    if (error === 'translation_busy') return '翻译请求较多，请稍后再试。';
    if (error === 'translation_fragmented') return '文本段落过多，请分段选择后重试。';
    return '翻译暂时不可用，请检查网络或在设置中切换服务。';
  }

  // Lucide languages and x icons, ISC license (https://lucide.dev).
  function icon(paths) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    for (const [name, value] of Object.entries({ viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', 'stroke-width': '2', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true' })) svg.setAttribute(name, value);
    for (const value of paths) { const path = document.createElementNS('http://www.w3.org/2000/svg', 'path'); path.setAttribute('d', value); svg.append(path); }
    return svg;
  }
  function closePanel() { panelGeneration += 1; cancel(panelRequest); panelRequest = null; panel?.remove(); panel = null; }
  function openPanel(rect) {
    closePanel();
    panel = document.createElement('div');
    panel.className = 'scansci-translation-panel';
    panel.setAttribute('role', 'region');
    panel.setAttribute('aria-label', 'Journal Scout 划词翻译');
    const heading = document.createElement('div'); heading.className = 'scansci-translation-heading';
    const label = document.createElement('span'); label.className = 'scansci-translation-label';
    label.append(icon(['m5 8 6 6', 'm4 14 6-6 2-3', 'M2 5h12', 'M7 2h1', 'm22 22-5-10-5 10', 'M14 18h6']), document.createTextNode('Journal Scout 翻译'));
    const close = document.createElement('button'); close.type = 'button'; close.setAttribute('aria-label', '关闭翻译');
    close.append(icon(['M18 6 6 18', 'm6 6 12 12'])); close.addEventListener('click', closePanel);
    heading.append(label, close);
    const output = document.createElement('div'); output.className = 'scansci-translation-output'; output.setAttribute('aria-live', 'polite');
    output.textContent = '正在翻译…';
    const footer = document.createElement('div'); footer.className = 'scansci-translation-footer'; footer.textContent = core.translationProviders[settings.translationProvider] + ' · 中英翻译';
    panel.append(heading, output, footer);
    document.documentElement.append(panel);
    const width = Math.min(380, Math.max(160, window.innerWidth - 24));
    panel.style.setProperty('left', `${Math.max(12, Math.min(rect.left, window.innerWidth - width - 12))}px`, 'important');
    panel.style.setProperty('top', `${Math.max(12, Math.min(rect.bottom + 8, window.innerHeight - 150))}px`, 'important');
    return output;
  }
  function currentSelection() {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.rangeCount) return null;
    const range = selection.getRangeAt(0);
    const parent = range.commonAncestorContainer.parentElement;
    if (parent?.closest('.scansci-translation-panel, .scansci-badge-info, input, textarea, select, [contenteditable="true"]')) return null;
    const text = selection.toString().trim();
    if (!text) return null;
    const rect = range.getBoundingClientRect();
    return { text, rect: { left: rect.left, bottom: rect.bottom } };
  }
  async function translateText({ text, rect }) {
    const output = openPanel(rect);
    const generation = panelGeneration;
    if (Array.from(text).length > 1500) { output.textContent = errorText('invalid_translation_text'); return true; }
    const requestId = crypto.randomUUID(); panelRequest = requestId;
    const response = await send(text, settings.translationTarget, requestId);
    if (panelRequest === requestId) panelRequest = null;
    if (generation === panelGeneration && panel?.isConnected) output.textContent = response?.ok ? response.data.text : errorText(response?.error);
    return true;
  }
  async function translateSelection() {
    const selected = currentSelection();
    return selected ? translateText(selected) : false;
  }
  function hideTouchTrigger() { clearTimeout(touchTimer); touchTrigger?.remove(); touchTrigger = null; touchSnapshot = null; }
  if (globalThis.matchMedia?.('(hover: none)').matches) {
    document.addEventListener('selectionchange', () => {
      if (!ready || !settings.translationEnabled) return;
      const selected = currentSelection();
      clearTimeout(touchTimer);
      if (!selected) { touchTimer = setTimeout(hideTouchTrigger, 350); return; }
      touchSnapshot = selected;
      if (!touchTrigger) {
        touchTrigger = document.createElement('button');
        touchTrigger.type = 'button'; touchTrigger.className = 'scansci-translation-trigger'; touchTrigger.textContent = '翻译选中文字';
        touchTrigger.addEventListener('click', event => {
          event.stopPropagation();
          const snapshot = touchSnapshot;
          hideTouchTrigger();
          if (snapshot && settings.translationEnabled) void translateText(snapshot);
        });
        document.documentElement.append(touchTrigger);
      }
      touchTrigger.style.setProperty('left', `${Math.max(12, Math.min(selected.rect.left, window.innerWidth - 130))}px`, 'important');
      touchTrigger.style.setProperty('top', `${Math.max(12, Math.min(selected.rect.bottom + 8, window.innerHeight - 48))}px`, 'important');
    });
    window.addEventListener('scroll', hideTouchTrigger, { passive: true, capture: true });
  }
  document.addEventListener('keydown', event => {
    if (!ready || !settings.translationEnabled || !event.isTrusted || event.repeat || event.isComposing || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
    const target = event.target;
    if (target?.isContentEditable || target?.closest?.('input, textarea, select, [contenteditable="true"]')) return;
    const key = event.key.toUpperCase();
    if (key === settings.translationCloseKey && panel) { closePanel(); event.preventDefault(); return; }
    if (key === settings.translationKey && window.getSelection()?.toString().trim()) {
      event.preventDefault(); void translateSelection();
    }
  });

  function titleNodes() {
    const host = location.hostname;
    let selector = '';
    if (host.startsWith('scholar.google.')) selector = '.gs_r .gs_rt a';
    else if (host === 'pubmed.ncbi.nlm.nih.gov') selector = '.docsum-title, h1.heading-title';
    else if (host === 'kns.cnki.net') selector = 'td.name > a';
    else if (host === 'nature.com' || host.endsWith('.nature.com')) selector = 'h3.c-card__title a, h1.c-article-title';
    const nodes = selector ? [...document.querySelectorAll(selector)] : [];
    const metadata = (document.querySelector('meta[name="citation_title" i]') || document.querySelector('meta[name="bepress_citation_title" i]'))?.content?.trim();
    const heading = core.articleHeading(document);
    if (metadata && heading && heading.textContent.trim().replace(/\s+/g, ' ') === metadata.replace(/\s+/g, ' ')) nodes.push(heading);
    return [...new Set(nodes)];
  }
  function colorChannels(value) {
    const match = String(value || '').match(/^rgba?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)(?:\s*,\s*(\d*\.?\d+))?\s*\)$/i);
    if (!match) return null;
    return [...match.slice(1, 4).map(Number), match[4] === undefined ? 1 : Number(match[4])];
  }
  function titleBackground(target) {
    const dark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
    let color = dark ? [18, 26, 32] : [255, 255, 255];
    const ancestors = [];
    for (let node = target; node?.nodeType === 1; node = node.parentElement) {
      ancestors.push(node);
      if (node === document.documentElement) break;
    }
    let hasImage = false;
    for (const node of ancestors.reverse()) {
      const style = getComputedStyle(node);
      if (style.backgroundImage && style.backgroundImage !== 'none') hasImage = true;
      // Publishers often add dark overlays with pseudo-elements instead of putting
      // the gradient on the title's ancestor. In that case, keep the publisher's
      // chosen foreground color rather than contrasting against the fallback fill.
      for (const pseudo of ['::before', '::after']) {
        const pseudoStyle = getComputedStyle(node, pseudo);
        if (pseudoStyle.backgroundImage && pseudoStyle.backgroundImage !== 'none') hasImage = true;
      }
      const layer = colorChannels(style.backgroundColor);
      if (!layer || layer[3] <= 0) continue;
      color = color.map((channel, index) => Math.round(layer[index] * layer[3] + channel * (1 - layer[3])));
    }
    return hasImage ? null : `rgb(${color.join(', ')})`;
  }
  function paintTitle(target, entry) {
    if (!target?.isConnected || !entry?.node?.isConnected) return;
    const source = getComputedStyle(target);
    const color = core.translationTitleReadableColor(settings.translationTitleColorMode, settings.translationTitleColor,
      source.color, titleBackground(target));
    const fontSize = core.translationTitleFontSize(settings.translationTitleSize, source.fontSize);
    entry.node.style.setProperty('color', color, 'important');
    entry.node.style.setProperty('font-size', fontSize, 'important');
    entry.node.style.setProperty('font-family', source.fontFamily || 'system-ui, sans-serif', 'important');
    entry.node.style.setProperty('font-weight', '500', 'important');
    entry.node.style.setProperty('line-height', '1.5', 'important');
    const shadow = core.translationContrastRatio(color, '#000000') >= core.translationContrastRatio(color, '#ffffff')
      ? '0 1px 2px rgb(0 0 0 / 35%)' : '0 1px 2px rgb(255 255 255 / 45%)';
    entry.node.style.setProperty('text-shadow', shadow, 'important');
  }
  function attachTitle(target, entry) {
    if (!entry.node) {
      entry.node = document.createElement('span'); entry.node.className = 'scansci-title-translation';
      entry.node.textContent = entry.translation; entry.node.setAttribute('lang', 'zh-CN');
      entry.node.scansciTitleTarget = target;
    }
    target.insertAdjacentElement('afterend', entry.node);
    paintTitle(target, entry);
  }
  function repaintTitles() {
    for (const node of document.querySelectorAll('.scansci-title-translation')) paintTitle(node.scansciTitleTarget, { node });
  }
  function scanTitles() {
    if (!ready || !settings.translationEnabled || !settings.autoTranslateTitles) return;
    for (const node of document.querySelectorAll('.scansci-title-translation')) {
      const target = node.scansciTitleTarget;
      if (!target?.isConnected || seenTitles.get(target)?.node !== node || core.adjacentCompanion(target, 'scansci-title-translation') !== node) node.remove();
    }
    if (titleFailed) return;
    titleQueue = titleQueue.filter(item => {
      const current = item.target.isConnected && seenTitles.get(item.target) === item.entry && item.target.textContent.trim().replace(/\s+/g, ' ') === item.entry.text;
      if (!current && seenTitles.get(item.target) === item.entry) seenTitles.delete(item.target);
      return current;
    });
    for (const target of titleNodes()) {
      const text = target.textContent.trim().replace(/\s+/g, ' ');
      const previous = seenTitles.get(target);
      if (previous?.text === text) {
        if (previous.translation) {
          if (!previous.node?.isConnected) attachTitle(target, previous);
          else paintTitle(target, previous);
        }
        continue;
      }
      previous?.node?.remove();
      if (titleCount + titleQueue.length >= 20 || text.length < 5 || Array.from(text).length > 1500 || !/[a-z]/i.test(text) || /[\u3400-\u9fff]/.test(text)) continue;
      const entry = { text }; seenTitles.set(target, entry); titleQueue.push({ target, entry });
    }
    void runTitles();
  }
  async function runTitles() {
    if (running || !ready || !settings.translationEnabled || !settings.autoTranslateTitles || titleFailed) return;
    const item = titleQueue.shift();
    if (!item) return;
    if (!item.target.isConnected || seenTitles.get(item.target) !== item.entry || item.target.textContent.trim().replace(/\s+/g, ' ') !== item.entry.text) { void runTitles(); return; }
    if (titleCount >= 20) return;
    titleCount += 1;
    running = true;
    const generation = titleGeneration;
    const requestId = crypto.randomUUID(); titleRequest = requestId;
    const response = await send(item.entry.text, 'zh-CN', requestId);
    if (generation !== titleGeneration) return;
    if (titleRequest === requestId) titleRequest = null;
    running = false;
    if (item.target.isConnected && seenTitles.get(item.target) === item.entry && item.target.textContent.trim().replace(/\s+/g, ' ') === item.entry.text) {
      if (response?.ok) { item.entry.translation = response.data.text; attachTitle(item.target, item.entry); }
      else { item.entry.translation = errorText(response?.error); attachTitle(item.target, item.entry); titleFailed = true; titleQueue = []; }
    }
    if (!titleFailed) titleTimer = setTimeout(runTitles, 1000);
  }
  function clearTitles() {
    titleGeneration += 1; cancel(titleRequest); titleRequest = null; clearTimeout(titleTimer); running = false; titleQueue = []; titleCount = 0; titleFailed = false; seenTitles = new WeakMap();
    document.querySelectorAll('.scansci-title-translation').forEach(node => node.remove());
  }
  api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const updates = {};
    for (const key of Object.keys(core.translationDefaults)) if (changes[key]) updates[key] = changes[key].newValue ?? core.translationDefaults[key];
    if (!Object.keys(updates).length) return;
    if (!ready) { Object.assign(initialChanges, updates); return; }
    const wasActive = settings.translationEnabled && settings.autoTranslateTitles;
    const previousProvider = settings.translationProvider;
    rawSettings = { ...rawSettings, ...updates };
    settings = core.translationSettings(rawSettings);
    const active = settings.translationEnabled && settings.autoTranslateTitles;
    if (!settings.translationEnabled || previousProvider !== settings.translationProvider) { closePanel(); hideTouchTrigger(); }
    if ((wasActive && !active) || previousProvider !== settings.translationProvider) clearTitles();
    if (active && (!wasActive || previousProvider !== settings.translationProvider)) scanTitles();
    else if (active && ['translationTitleSize', 'translationTitleColorMode', 'translationTitleColor'].some(key => Object.hasOwn(updates, key))) repaintTitles();
  });
  api.storage.local.get(core.translationDefaults, values => { rawSettings = { ...values, ...initialChanges }; settings = core.translationSettings(rawSettings); initialChanges = {}; ready = true; scanTitles(); });
  let scanTimer;
  window.addEventListener('resize', () => {
    if (!ready || !settings.translationEnabled || !settings.autoTranslateTitles) return;
    repaintTitles();
  }, { passive: true });
  new MutationObserver(records => {
    if (!ready || !settings.translationEnabled || !settings.autoTranslateTitles) return;
    if (!records.some(record => {
      if (record.type !== 'attributes') return true;
      if (record.target.classList?.contains('scansci-title-translation')) return false;
      if (record.attributeName === 'content' || record.attributeName === 'name') return record.target.tagName === 'META';
      if (record.attributeName === 'style') return [...document.querySelectorAll('.scansci-title-translation')].some(node => {
        const target = node.scansciTitleTarget;
        return target && (target === record.target || record.target.contains?.(target) || target.contains?.(record.target));
      });
      if (record.attributeName !== 'class') return false;
      const external = value => String(value || '').split(/\s+/).filter(name => name && !name.startsWith('scansci-')).sort().join(' ');
      return external(record.oldValue) !== external(record.target.getAttribute('class'));
    })) return;
    clearTimeout(scanTimer); scanTimer = setTimeout(scanTitles, 500);
  }).observe(document.documentElement, { childList: true, characterData: true, attributes: true, attributeOldValue: true, attributeFilter: ['content', 'name', 'class', 'style'], subtree: true });
})();
