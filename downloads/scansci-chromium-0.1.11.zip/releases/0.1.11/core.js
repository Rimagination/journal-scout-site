(() => {
  function extensionPath(file, runtime) {
    const worker = runtime?.getManifest?.()?.background?.service_worker;
    const slash = typeof worker === 'string' ? worker.lastIndexOf('/') : -1;
    return (slash < 0 ? '' : worker.slice(0, slash + 1)) + file;
  }
  const defaults = { enabled: true, impact: true, jcr: true, cas: true, top: true, hq: true,
    chinese: true, indexing: true, natureIndex: true, xinrui: true, warning: true, ccf: false, ei: true, ft50: true,
    ajg: true, utd24: true, fms: true, abdc: true, doiLookup: true, filter: true, badgeHistory: false };
  const translationProviders = { edge: '微软 Edge 翻译', transmart: '腾讯交互翻译' };
  const translationDefaults = { translationEnabled: true, autoTranslateTitles: false, translationProvider: null, translationTarget: 'auto', translationKey: 'T', translationCloseKey: 'Y', translationTitleSize: 'auto', translationTitleColorMode: 'auto', translationTitleColor: '#087963' };
  function translationSettings(value = {}) {
    const key = (name, fallback) => /^[A-Z]$/.test(String(value[name] || '').toUpperCase()) ? String(value[name]).toUpperCase() : fallback;
    const translationKey = key('translationKey', 'T');
    let translationCloseKey = key('translationCloseKey', 'Y');
    if (translationCloseKey === translationKey) translationCloseKey = translationKey === 'Y' ? 'T' : 'Y';
    return { translationEnabled: value.translationEnabled !== false, autoTranslateTitles: value.autoTranslateTitles === true && Object.hasOwn(translationProviders, value.translationProvider),
      translationProvider: Object.hasOwn(translationProviders, value.translationProvider) ? value.translationProvider : 'edge',
      translationTarget: ['auto', 'zh-CN', 'en'].includes(value.translationTarget) ? value.translationTarget : 'auto', translationKey, translationCloseKey,
      translationTitleSize: ['auto', '12', '14', '16', '18', '20', '22'].includes(String(value.translationTitleSize)) ? String(value.translationTitleSize) : 'auto',
      translationTitleColorMode: ['auto', 'custom'].includes(value.translationTitleColorMode) ? value.translationTitleColorMode : 'auto',
      translationTitleColor: /^#[0-9a-f]{6}$/i.test(value.translationTitleColor) ? value.translationTitleColor.toLowerCase() : '#087963' };
  }
  function translationTitleFontSize(mode, referenceSize) {
    if (mode !== 'auto') return `${['12', '14', '16', '18', '20', '22'].includes(String(mode)) ? Number(mode) : 14}px`;
    const reference = Number.parseFloat(referenceSize);
    return `${Math.max(12, Math.min(22, Math.round((Number.isFinite(reference) ? reference : 16) * 0.42)))}px`;
  }
  function translationContrastRatio(foreground, background) {
    const rgb = value => {
      const match = String(value || '').match(/^rgba?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)(?:\s*,\s*(\d*\.?\d+))?\s*\)$/i);
      if (match && (match[4] === undefined || Number(match[4]) >= 0.999)) return match.slice(1, 4).map(Number);
      const hex = String(value || '').match(/^#([0-9a-f]{6})$/i)?.[1];
      return hex ? [0, 2, 4].map(index => Number.parseInt(hex.slice(index, index + 2), 16)) : null;
    };
    const luminance = value => {
      const channels = rgb(value);
      if (!channels) return null;
      const [r, g, b] = channels.map(channel => {
        const value = channel / 255;
        return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
      });
      return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    };
    const fg = luminance(foreground), bg = luminance(background);
    return fg === null || bg === null ? 0 : (Math.max(fg, bg) + 0.05) / (Math.min(fg, bg) + 0.05);
  }
  function translationTitleReadableColor(mode, custom, foreground, background) {
    if (mode === 'custom' && /^#[0-9a-f]{6}$/i.test(custom || '')) return custom.toLowerCase();
    if (background && foreground && translationContrastRatio(foreground, background) >= 4.5) return foreground;
    if (!background) return foreground || '#087963';
    return translationContrastRatio('#f8fbff', background) >= translationContrastRatio('#102a35', background) ? '#f8fbff' : '#102a35';
  }
  const badgeCatalog = [
    { id: 'impact', group: 'impact', label: '影响因子', sample: 'IF 56.1', kind: 'impact', description: '展示影响因子；数据年份在悬停提示中。' },
    { id: 'indexing', group: 'indexing', label: 'WOS 收录', sample: 'SCIE', kind: 'indexing', description: '显示 SCIE、SSCI 等收录类型。' },
    { id: 'jcr', group: 'jcr', label: 'JCR 分区', sample: 'JCR Q1', kind: 'jcr', description: '按期刊所属学科显示 Q1–Q4。' },
    { id: 'xinrui', group: 'xinrui', label: '新锐分区', sample: '新锐 1区', kind: 'xinrui', description: '显示有记录的新锐期刊分区。' },
    { id: 'cas', group: 'cas', label: '中科院分区', sample: '中科院 1区', kind: 'cas', description: '显示有记录的中科院分区。' },
    { id: 'top', group: 'top', label: '中科院 Top', sample: '中科院 Top', kind: 'cas', description: '显示中科院 Top 期刊标记。' },
    { id: 'hq', group: 'hq', label: '科协分级', sample: '科协 T1', kind: 'hq', description: '显示中国科协期刊分级。' },
    { id: 'pku', group: 'chinese', label: '北大核心', sample: '北大核心', kind: 'chinese', description: '中文核心期刊目录。' },
    { id: 'cssci', group: 'chinese', label: 'CSSCI', sample: 'CSSCI 来源版', kind: 'chinese', description: '显示来源版或扩展版。' },
    { id: 'cscd', group: 'chinese', label: 'CSCD', sample: 'CSCD 核心库', kind: 'chinese', description: '显示核心库或扩展库。' },
    { id: 'scd', group: 'chinese', label: 'SCD', sample: 'SCD', kind: 'chinese', description: '科学引文数据库期刊目录。' },
    { id: 'natureIndex', group: 'natureIndex', label: 'Nature Index', sample: 'Nature Index', kind: 'natureIndex', description: '显示 Nature Index 期刊标记。' },
    { id: 'warning', group: 'warning', label: '中科院预警', sample: '中科院预警', kind: 'warning', description: '显示有记录的期刊预警。' },
    { id: 'xinruiWarning', group: 'warning', label: '新锐预警', sample: '新锐预警', kind: 'warning', description: '显示新锐预警标记。' },
    { id: 'ccf', group: 'ccf', label: 'CCF 推荐', sample: 'CCF A', kind: 'ccf', description: '中国计算机学会推荐目录；需要额外查询期刊详情。' },
    { id: 'ccft', group: 'ccf', label: 'CCFT 分级', sample: 'CCFT T1', kind: 'ccft', description: '中国计算机学会科技期刊分级；需要额外查询期刊详情。' },
    { id: 'ei', group: 'ei', label: 'EI 收录', sample: 'EI', kind: 'indexing', description: '显示有记录的工程索引收录。' },
    { id: 'ft50', group: 'ft50', label: 'FT50', sample: 'FT50', kind: 'hq', description: 'Financial Times 2026 期刊名单。' },
    { id: 'ajg', group: 'ajg', label: 'ABS / AJG', sample: 'ABS 4*', kind: 'hq', description: '英国商学院协会 Academic Journal Guide 等级。' },
    { id: 'utd24', group: 'utd24', label: 'UTD24', sample: 'UTD24', kind: 'hq', description: '德克萨斯大学达拉斯分校的 24 种期刊名单。' },
    { id: 'fms', group: 'fms', label: 'FMS', sample: 'FMS A', kind: 'hq', description: 'FMS 管理科学高质量期刊等级。' },
    { id: 'abdc', group: 'abdc', label: 'ABDC', sample: 'ABDC A*', kind: 'hq', description: '澳大利亚商学院院长委员会期刊等级。' },
  ];
  const badgePrefixes = { impact: 'IF', jcr: 'JCR', cas: '中科院', top: '中科院 Top', hq: '科协', pku: '北大核心',
    cssci: 'CSSCI', cscd: 'CSCD', scd: 'SCD', natureIndex: 'Nature Index', xinrui: '新锐', warning: '中科院预警',
    xinruiWarning: '新锐预警', ccf: 'CCF', ccft: 'CCFT', ei: 'EI', ft50: 'FT50',
    ajg: 'ABS', utd24: 'UTD24', fms: 'FMS', abdc: 'ABDC' };
  function badgeAlias(value) {
    const text = typeof value === 'string' ? value.trim() : '';
    return text && [...text].length <= 20 && !/[\u0000-\u001f\u007f-\u009f]/u.test(text) ? text : '';
  }
  function badgeText(key, text, aliases) {
    const prefix = badgePrefixes[key];
    const alias = aliases && typeof aliases === 'object' ? badgeAlias(aliases[key]) : '';
    return prefix && alias && text.startsWith(prefix) ? alias + text.slice(prefix.length) : text;
  }
  const layoutDefaults = { fontSize: 11, radius: 4, paddingX: 4, paddingY: 1, gap: 3, showLogo: true };
  function badgeLayout(value) {
    const saved = value && typeof value === 'object' ? value : {};
    const size = (key, min, max) => Number.isInteger(saved[key]) && saved[key] >= min && saved[key] <= max ? saved[key] : layoutDefaults[key];
    return { fontSize: size('fontSize', 9, 18), radius: size('radius', 0, 10), paddingX: size('paddingX', 0, 12),
      paddingY: size('paddingY', 0, 6), gap: size('gap', 0, 12), showLogo: typeof saved.showLogo === 'boolean' ? saved.showLogo : true };
  }
  function badgeOrder(value) {
    const known = new Set(badgeCatalog.map(item => item.id));
    const saved = Array.isArray(value) ? value.filter(id => known.has(id)) : [];
    return [...new Set([...saved, ...known])];
  }
  const badgePalettes = {
    a: {
      impact: ['#174d73', '#e8f2f8', '#d3e5ef'], jcr: ['#344581', '#edf0fa', '#dce2f2'],
      cas: ['#08624f', '#e5f4ee', '#cee9de'], xinrui: ['#08624f', '#e5f4ee', '#cee9de'],
      hq: ['#76500d', '#faf1dd', '#f0dfb9'], ccf: ['#414b88', '#eaeefa', '#d9e0f4'],
      ccft: ['#65487c', '#f1eaf7', '#e5d9ef'], natureIndex: ['#8b3f5e', '#faeaf0', '#f1d5e1'], chinese: ['#76500d', '#faf1dd', '#f0dfb9'],
      indexing: ['#34565c', '#edf3f2', '#dce8e6'], warning: ['#943b32', '#fceeea', '#f3d8d2'],
    },
    b: {
      impact: ['#ffffff', '#285f80'], jcr: ['#ffffff', '#48598d'],
      cas: ['#ffffff', '#23735f'], xinrui: ['#ffffff', '#23735f'],
      hq: ['#ffffff', '#91691f'], ccf: ['#ffffff', '#4c5b99'], ccft: ['#ffffff', '#765691'],
      natureIndex: ['#ffffff', '#9a526e'], chinese: ['#ffffff', '#91691f'],
      indexing: ['#ffffff', '#516b6d'], warning: ['#ffffff', '#a64f44'],
    },
    c: {
      impact: ['#ffffff', '#1d4ed8'], jcr: ['#ffffff', '#7c3aed'],
      cas: ['#ffffff', '#047857'], xinrui: ['#ffffff', '#0e7490'],
      hq: ['#ffffff', '#c2410c'], ccf: ['#422006', '#facc15'], ccft: ['#ffffff', '#a21caf'],
      natureIndex: ['#ffffff', '#be185d'], chinese: ['#365314', '#a3e635'],
      indexing: ['#ffffff', '#334155'], warning: ['#ffffff', '#b91c1c'],
    },
  };
  function badgePalette(style, custom) {
    const preset = badgePalettes[style] || badgePalettes.a;
    const hex = value => typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value);
    return Object.fromEntries(Object.entries(preset).map(([kind, [fg, bg, border]]) => {
      const saved = style === 'custom' && custom && typeof custom === 'object' ? custom[kind] : null;
      const text = hex(saved?.fg) ? saved.fg.toLowerCase() : fg;
      const background = hex(saved?.bg) ? saved.bg.toLowerCase() : bg;
      return [kind, { fg: text, bg: background, border: background === bg ? (border || bg) : background }];
    }));
  }
  function badgeLevelKey(kind, value) {
    const text = String(value || '').normalize('NFKC').trim();
    let match;
    if (kind === 'jcr') match = text.match(/^(?:JCR\s*)?Q([1-4])$/i);
    else if (kind === 'cas' || kind === 'xinrui') match = text.match(/^(?:(?:中科院|新锐)\s*)?([1-4一二三四])\s*区?$/);
    if (!match) return '';
    const level = { 一: '1', 二: '2', 三: '3', 四: '4' }[match[1]] || match[1];
    return `${kind}${level}`;
  }
  function badgeColor(palette, style, levelColors, kind, level) {
    const base = palette[kind];
    if (!base || style !== 'custom' || !['cas', 'jcr', 'xinrui'].includes(kind) || ![1, 2, 3, 4].some(n => level === `${kind}${n}`)) return base;
    const saved = levelColors && typeof levelColors === 'object' ? levelColors[level] : null;
    const hex = value => typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value);
    const fg = hex(saved?.fg) ? saved.fg.toLowerCase() : base.fg;
    const bg = hex(saved?.bg) ? saved.bg.toLowerCase() : base.bg;
    return { fg, bg, border: bg === base.bg ? base.border : bg };
  }
  const normalizeIssn = value => String(value || '').toUpperCase().replace(/[^0-9X]/g, '');
  const validIssn = value => /^\d{7}[\dX]$/.test(normalizeIssn(value));
  function normalizeDoi(value) {
    let doi = String(value || '').trim().replace(/^(?:https?:\/\/(?:dx\.)?doi\.org\/|doi:\s*)/i, '');
    try { doi = decodeURIComponent(doi); } catch { return ''; }
    return doi.length <= 200 && /^10\.\d{4,9}\/[-._;()/:A-Z0-9]+$/i.test(doi) ? doi : '';
  }
  const normalizeTitle = value => String(value || '').normalize('NFKC').toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, ' ').trim().replace(/\s+/g, ' ');

  // Ranking data can be provided locally; it is not included in public builds
  // until the source owners' redistribution conditions have been established.
  const businessGrades = { ajg: /^(?:4\*|[1-4])$/, utd24: /^yes$/, fms: /^(?:[A-D]|T[12])$/, abdc: /^(?:A\*|[ABC])$/ };
  let businessIndex = null;
  let businessCount = 0;
  const businessTitle = value => normalizeTitle(value).replace(/^the /, '');
  function setBusinessRankings(records) {
    if (records == null) { businessIndex = null; businessCount = 0; return 0; }
    if (!Array.isArray(records) || records.length > 10000) throw new Error('Invalid ranking data');
    const next = Object.fromEntries(Object.keys(businessGrades).map(key => [key, { titles: new Map(), issns: new Map() }]));
    const add = (map, key, record) => {
      if (!key) return;
      if (!map.has(key)) map.set(key, new Set());
      map.get(key).add(record);
    };
    for (const entry of records) {
      if (!Array.isArray(entry) || entry.length !== 5) throw new Error('Invalid ranking record');
      const [source, title, identifiers, grade, aliases] = entry;
      if (!Object.hasOwn(businessGrades, source) || typeof title !== 'string' || !title.trim() || title.length > 250 ||
          typeof grade !== 'string' || !businessGrades[source].test(grade) || !Array.isArray(identifiers) || identifiers.length > 10 ||
          identifiers.some(value => typeof value !== 'string' || !validIssn(value)) || !Array.isArray(aliases) || aliases.length > 10 ||
          aliases.some(value => typeof value !== 'string' || !value.trim() || value.length > 250)) throw new Error('Invalid ranking record');
      const names = new Set([title, ...aliases].map(businessTitle));
      const record = { grade, identifiers: [...new Set(identifiers.map(normalizeIssn))], names };
      for (const value of names) add(next[source].titles, value, record);
      for (const value of record.identifiers) add(next[source].issns, value, record);
    }
    businessIndex = next;
    businessCount = records.length;
    return businessCount;
  }
  const businessRankingCount = () => businessCount;
  function businessRankings(row) {
    if (!businessIndex || !row || row.consensusRows) return {};
    const identifiers = [...new Set([row.issn, row.eissn].filter(validIssn).map(normalizeIssn))];
    const ratings = {};
    for (const [source, index] of Object.entries(businessIndex)) {
      const matches = new Set(identifiers.flatMap(value => [...(index.issns.get(value) || [])]));
      if (matches.size > 1) continue;
      let record = matches.values().next().value;
      if (record && record.identifiers.length > 1 && identifiers.length > 1 && identifiers.some(value => !record.identifiers.includes(value))) continue;
      if (!record) {
        const titleMatches = index.titles.get(businessTitle(row.title));
        if (titleMatches?.size !== 1) continue;
        record = titleMatches.values().next().value;
        if (identifiers.length && record.identifiers.length) continue;
      }
      if (row.localRankingOnly && !record.names.has(businessTitle(row.title))) continue;
      ratings[source] = record.grade;
    }
    return ratings;
  }
  function localBusinessJournal(hint) {
    if (!businessIndex) return null;
    const title = String(hint?.title || '').trim();
    if (!title || title.length > 120 || /(?:\.\.\.|…)/.test(title) || !/\p{L}/u.test(title)) return null;
    const identifiers = [...new Set((Array.isArray(hint.issns) ? hint.issns : []).filter(validIssn).map(normalizeIssn))];
    if (identifiers.length > 2) return null;
    const candidates = [];
    for (const index of Object.values(businessIndex)) {
      const matches = index.titles.get(businessTitle(title));
      if (matches?.size > 1) return null;
      if (matches?.size === 1) candidates.push(matches.values().next().value);
    }
    const withIds = candidates.filter(record => record.identifiers.length);
    if (identifiers.length && identifiers.some(value => !withIds.some(record => record.identifiers.includes(value)))) return null;
    const relevant = identifiers.length ? withIds.filter(record => identifiers.some(value => record.identifiers.includes(value))) : withIds;
    if (relevant.some((record, i) => relevant.slice(i + 1).some(other =>
      !record.identifiers.some(value => other.identifiers.includes(value))))) return null;
    const row = { title, issn: identifiers[0] || '', eissn: identifiers[1] || '', localRankingOnly: true };
    return Object.keys(businessRankings(row)).length ? row : null;
  }

  // FT50, 2026: Sainsbury Library, Bodleian Libraries, University of Oxford,
  // https://libguides.bodleian.ox.ac.uk/ft-top50, CC BY 4.0
  // (https://creativecommons.org/licenses/by/4.0/).
  // The guide's "Journal of Accountancy and Economics" is corrected to
  // "Journal of Accounting and Economics"; two database title variants are added.
  const ft50 = new Set([
    'Academy of Management Annals', 'Academy of Management Journal', 'Academy of Management Review',
    'Accounting, Organizations, and Society', 'Accounting Review', 'Administrative Science Quarterly',
    'American Economic Review', 'American Sociological Review', 'Contemporary Accounting Research',
    'Econometrica', 'Entrepreneurship Theory and Practice', 'Harvard Business Review', 'Human Resource Management',
    'Information Systems Research', 'Journal of Accounting and Economics', 'Journal of Accounting & Economics',
    'Journal of Accounting Research', 'Journal of Applied Psychology', 'Journal of Business Venturing',
    'Journal of Consumer Psychology', 'Journal of Consumer Research', 'Journal of Finance',
    'Journal of Financial and Quantitative Analysis', 'Journal of Financial Economics',
    'Journal of International Business Studies', 'Journal of Management', 'Journal of Management Information Systems',
    'Journal of Management Studies', 'Journal of Marketing', 'Journal of Marketing Research', 'Journal of Operations Management',
    'Journal of Political Economy', 'Journal of the Academy of Marketing Science', 'Management Science',
    'Manufacturing and Service Operations Management', 'M&SOM-Manufacturing & Service Operations Management',
    'Marketing Science', 'MIS Quarterly', 'Operations Research', 'Organization Science',
    'Organizational Behavior and Human Decision Processes', 'Production and Operations Management',
    'Quarterly Journal of Economics', 'Research Policy', 'Review of Accounting Studies', 'Review of Economic Studies',
    'Review of Finance', 'Review of Financial Studies', 'MIT Sloan Management Review', 'Psychological Science',
    'Strategic Entrepreneurship Journal', 'Strategic Management Journal',
  ].map(normalizeTitle));

  function articleHeading(doc) {
    const title = doc.querySelector('meta[name="citation_title" i]')?.content ||
      doc.querySelector('meta[name="bepress_citation_title" i]')?.content || doc.querySelector('meta[name="dc.title" i]')?.content;
    if (title) {
      const expected = normalizeTitle(title);
      const match = [...doc.querySelectorAll('h1, h2')].find(node => normalizeTitle(node.textContent) === expected);
      if (match) return match;
    }
    return doc.querySelector('h1.c-article-title, h1.citation__title, main .article > h1') || doc.querySelector('h1');
  }

  function adjacentCompanion(target, className) {
    for (let node = target?.nextElementSibling; node; node = node.nextElementSibling) {
      if (node.classList?.contains(className)) return node;
      if (!node.classList?.contains('scansci-journal-badges') && !node.classList?.contains('scansci-title-translation')) break;
    }
    return null;
  }

  function matchJournal(items, hint) {
    const rows = Array.isArray(items) ? items : [];
    const identifiers = [...new Set((hint.issns || []).filter(validIssn).map(normalizeIssn))];
    if (identifiers.length) {
      const exact = rows.filter(row => identifiers.every(identifier => [row.issn, row.eissn].some(value =>
        validIssn(value) && identifier === normalizeIssn(value))));
      if (exact.length === 1) return exact[0];
      return null;
    }
    const title = normalizeTitle(hint.title);
    if (!title) return null;
    const exact = rows.filter(row => normalizeTitle(row.title) === title);
    if (exact.length === 1) return exact[0];
    if (!identifiers.length && exact.length > 1) {
      const validCn = value => /^(?:CN)?\d{6}\/[A-Z0-9]{1,4}$/.test(String(value || '').toUpperCase().replace(/[\s-]+/g, ''));
      const issnRows = exact.filter(row => [row.issn, row.eissn].some(validIssn));
      const cnRows = exact.filter(row => validCn(row.cn_number));
      const primary = issnRows.length === 1 && cnRows.every(row => row === issnRows[0] ||
        (validCn(issnRows[0].cn_number) && String(row.cn_number).toUpperCase().replace(/[\s-]+/g, '') ===
          String(issnRows[0].cn_number).toUpperCase().replace(/[\s-]+/g, '')))
        ? issnRows[0] : !issnRows.length && cnRows.length === 1 ? cnRows[0] : null;
      // Resolve only one identified journal with identical classifications; leave conflicting identities ambiguous.
      const fields = ['if_2023', 'if_year', 'jcr_quartile', 'cas_2025', 'is_top', 'hq_level', 'pku_core', 'cssci_type', 'cscd_type', 'warning_latest', 'xuankan_2026', 'xuankan_warning', 'ni_journal'];
      const signature = row => JSON.stringify([fields.map(key => row[key] ?? null), [...new Set(Array.isArray(row.tags) ? row.tags : [])].sort()]);
      const cnNumbers = new Set(exact.map(row => String(row.cn_number || '').toUpperCase().replace(/[\s-]+/g, '')).filter(Boolean));
      if (cnNumbers.size <= 1 && primary && exact.every(row => signature(row) === signature(primary))) return primary;
      if (cnNumbers.size <= 1 && primary) {
        const common = { title: exact[0].title, ambiguous: true, consensusRows: exact };
        if (badges(common).length) return common;
      }
    }
    return null;
  }

  function scholarJournal(text) {
    const parts = String(text || '').split(/\s+[-–—]\s+/);
    if (parts.length < 2) return '';
    const source = parts.slice(1).join(' - ');
    const year = source.search(/,?\s*\b(?:19|20)\d{2}\b/);
    return year < 0 ? '' : scholarProfileJournal(source.slice(0, year));
  }

  function scholarProfileJournal(text) {
    const source = String(text || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
    if (!source || /\.\.\.|…/.test(source)) return '';
    const title = source.replace(/\s+\d+(?:\s*\([^)]{1,40}\))?\s*(?=,|:|$).*/, '').replace(/[,\s]+$/, '');
    return title.length <= 120 && /\p{L}/u.test(title) ? title : '';
  }

  function doiFromUrl(value, base) {
    try {
      let url = new URL(value, base);
      if (url.protocol !== 'https:') return '';
      if (url.hostname.startsWith('scholar.google.') || url.hostname === 'www.google.com') {
        const destination = url.searchParams.get('url') || url.searchParams.get('q');
        if (destination) url = new URL(destination);
      }
      if (url.protocol !== 'https:') return '';
      const pathname = decodeURIComponent(url.pathname);
      const candidate = pathname.match(/\/(10\.\d{4,9}\/[-._;()/:A-Z0-9]+)$/i)?.[1];
      return candidate ? normalizeDoi(candidate) : '';
    } catch { return ''; }
  }

  function schemaJournal(data, identity) {
    const articleTitle = normalizeTitle(identity?.title);
    if (!articleTitle) return null;
    const pageDoi = normalizeDoi(identity?.doi).toLowerCase();
    const roots = (Array.isArray(data) ? data : [data]).slice(0, 100);
    const nodes = roots.flatMap(root => root && Array.isArray(root['@graph']) ? [root, ...root['@graph'].slice(0, 100)] : [root])
      .filter(node => node && typeof node === 'object' && !Array.isArray(node)).slice(0, 200);
    const ids = new Map(nodes.filter(node => typeof node['@id'] === 'string').map(node => [node['@id'], node]));
    const types = node => (Array.isArray(node?.['@type']) ? node['@type'] : [node?.['@type']])
      .filter(value => typeof value === 'string').map(value => value.split(/[\/#]/).pop());
    const hints = new Map();
    for (const article of nodes) {
      if (!types(article).some(type => type === 'ScholarlyArticle' || type === 'MedicalScholarlyArticle') ||
          normalizeTitle(article.headline || article.name) !== articleTitle) continue;
      const dois = [article.doi, article.identifier, article['@id'], article.url].flat()
        .map(value => normalizeDoi(typeof value === 'object' && value ? value.value : value).toLowerCase()).filter(Boolean);
      if (pageDoi && dois.length && !dois.includes(pageDoi)) continue;
      let parent = article.isPartOf;
      for (let depth = 0; parent && depth < 8; depth += 1) {
        if (typeof parent === 'string') parent = ids.get(parent);
        if (!parent || typeof parent !== 'object' || Array.isArray(parent)) break;
        if (typeof parent['@id'] === 'string' && ids.has(parent['@id'])) parent = { ...ids.get(parent['@id']), ...parent };
        const issns = [...new Set([parent.issn, parent.eissn].flat().filter(validIssn))].slice(0, 3);
        const title = typeof (parent.name || parent.headline) === 'string' ? (parent.name || parent.headline).trim().slice(0, 120) : '';
        if ((types(parent).some(type => type === 'Periodical' || type === 'Journal') || issns.length) && (title || issns.length)) {
          const key = JSON.stringify([normalizeTitle(title), issns.map(normalizeIssn).sort()]);
          hints.set(key, { title, issns });
          break;
        }
        parent = parent.isPartOf;
      }
    }
    return hints.size > 1 ? { ambiguous: true } : hints.values().next().value || null;
  }

  function metricHistory(records, field) {
    if (!Array.isArray(records)) return '';
    const values = records.slice(0, 100).flatMap(record => {
      const year = Number(record?.year), raw = record?.[field];
      if (!Number.isInteger(year) || year < 1900 || year > 2100 || !['string', 'number'].includes(typeof raw) || String(raw).trim() === '') return [];
      const value = field === 'if_value' ? Number(raw) : String(raw).trim();
      if (field === 'if_value' ? !Number.isFinite(value) || value < 0 : !/^[1-4]区$/.test(value)) return [];
      return [{ year, value }];
    }).sort((a, b) => b.year - a.year).slice(0, 6);
    return values.length ? `\n历年：${values.map(item => `${item.year} ${item.value}`).join('；')}` : '';
  }

  // Publication dates describe the cited edition, not the journal's article year.
  // Evidence and uncertain cases are documented in docs/ranking-release-dates.md.
  function publicationNote(badge, row) {
    const key = badge.key;
    if (key === 'ajg') return '发布时间：2024年10月（AJG 2024版）。';
    if (key === 'utd24') return '发布时间：官方未标注；名单核验于2026年11月。';
    if (key === 'fms') return '发布时间：2025年7月（FMS 2025版）。';
    if (key === 'abdc') return '2025版首次发布：2026年3月；第3次修订文件日期：2026年9月。';
    if (key === 'ft50') return '名单更新：2026年4月。';
    if (key === 'impact') {
      const year = String(row.if_year || '');
      if (year === '2025') return '发布时间：2026年6月（JCR 2026版，2025年度指标）。';
      if (year === '2024') return '发布时间：2025年6月（JCR 2025版，2024年度指标）。';
    }
    if (key === 'cas' || key === 'top') {
      const year = String(row.cas_year || (row.cas_2025 ? '2025' : ''));
      if (year === '2025') return '发布时间：2025年3月（中科院分区表2025版）。';
    }
    if (key === 'pku' && Array.isArray(row.tags) && row.tags.includes('北大核心-2023')) return '出版时间：2024年4月（《中文核心期刊要目总览》2023版）。';
    if (key === 'scd' && Array.isArray(row.tags) && row.tags.includes('SCD-2026')) return '2026版于2026年4月已开放检索；具体发布时间未记录。';
    if (key === 'xinrui' && row.xuankan_2026) return '发布时间：2026年3月（新锐分区2026版）。';
    if (key === 'warning' && /2025/.test(String(row.warning_latest_year || row.warning_latest || ''))) return '发布时间：2025年3月（国际期刊预警名单2025版）。';
    if (key === 'ccf' && /目录年份：2026/.test(badge.title)) return '发布时间：2026年3月（第七版；官方4月有勘误）。';
    if (key === 'ccft' && /目录年份：2025/.test(badge.title)) return '发布时间：2025年4月（2025版）。';
    if (key === 'indexing' || key === 'ei' || key === 'natureIndex' || key === 'xinruiWarning') return '数据发布时间：未记录；收录或预警状态可能动态变化。';
    return '数据发布时间：未记录。';
  }

  function badges(row, settings = defaults) {
    if (row.consensusRows) {
      const groups = row.consensusRows.map(item => badges(item, { ...settings, ft50: false, ajg: false, utd24: false, fms: false, abdc: false }));
      return groups[0].flatMap(badge => {
        const matches = groups.slice(1).map(group => group.find(item => item.key === badge.key && item.text === badge.text && item.kind === badge.kind));
        if (matches.some(item => !item)) return [];
        const description = badge.title.split('\n')[0];
        return [{ ...badge, title: matches.every(item => item.title === badge.title) ? badge.title
          : `${matches.every(item => item.title.split('\n')[0] === description) ? description : badge.text}\n同名记录共有信息；数据发布时间：未记录。` }];
      });
    }
    const list = [];
    const tags = [...new Set((Array.isArray(row.tags) ? row.tags : []).filter(tag => typeof tag === 'string').map(tag => tag.trim()).filter(Boolean))];
    const tag = pattern => tags.find(value => pattern.test(value)) || '';
    if (settings.impact && row.if_2023 !== null && row.if_2023 !== '' && row.if_2023 !== undefined &&
        Number.isFinite(Number(row.if_2023))) {
      list.push({ key: 'impact', text: `IF ${Number(row.if_2023)}`, kind: 'impact', title: `影响因子：某年对期刊前两年发表内容的引用次数，除以前两年发表的可计论文数量。${row.if_year ? `\n数据年份：${row.if_year}。` : ''}${settings.badgeHistory ? metricHistory(row.if_history, 'if_value') : ''}` });
    }
    const quartiles = [...new Set(String(row.jcr_quartile || tags.filter(value => /^Q[1-4]$/i.test(value)).join(' ')).toUpperCase().match(/Q[1-4]/g) || [])];
    if (settings.jcr) for (const value of quartiles) list.push({ key: 'jcr', text: `JCR ${value}`, kind: 'jcr', title: 'JCR 分区：根据期刊在所属学科中的排名划分为 Q1 至 Q4。同一期刊在不同学科可能有不同分区。' });
    const cas = row.cas_2025 || tag(/^[1-4]区$/);
    if (settings.cas && cas) list.push({ key: 'cas', text: `中科院 ${cas}`, kind: 'cas', title: `中科院分区：中科院期刊分区表对学术期刊的分区，通常分为 1区至4区。${row.cas_year ? `\n数据年份：${row.cas_year}。` : ''}${settings.badgeHistory ? metricHistory(row.cas_history, 'rank') : ''}` });
    if (settings.top && (row.is_top === true || tags.includes('中科院Top'))) list.push({ key: 'top', text: '中科院 Top', kind: 'cas', title: '中科院 Top：该期刊在中科院期刊分区表中被标记为 Top 期刊。' });
    const hq = row.hq_level || tag(/^HQ-[A-Z0-9]+(?:类)?$/i).replace(/^HQ-/i, '');
    const cssci = row.cssci_type || (tag(/^CSSCI(?:\(扩展\)|扩展)$/i) ? '扩展版' : tag(/^CSSCI$/i) ? '来源版' : '');
    const cscd = row.cscd_type || tag(/^CSCD-(?:核心库|扩展库)$/i).replace(/^CSCD-/i, '') ||
      (tag(/^CSCD(?:\(核心\)|核心)$/i) ? '核心库' : tag(/^CSCD(?:\(扩展\)|扩展)$/i) ? '扩展库' : '');
    if (settings.hq && hq) list.push({ key: 'hq', text: `科协 ${hq}`, kind: 'hq', title: '科协分级：中国科协高质量科技期刊分级目录中的期刊等级。' });
    if (settings.chinese && (row.pku_core === true || tags.includes('北大核心'))) list.push({ key: 'pku', text: '北大核心', kind: 'chinese', title: `北大中文核心期刊：《中文核心期刊要目总览》收录的核心期刊。${tags.includes('北大核心-2023') ? '\n2023 版（高校参考目录）。' : ''}` });
    if (settings.chinese && cssci) list.push({ key: 'cssci', text: `CSSCI ${cssci}`, kind: 'chinese', title: 'CSSCI：中文社会科学引文索引的来源期刊或扩展版期刊，标签显示对应来源类型。' });
    if (settings.chinese && cscd) list.push({ key: 'cscd', text: `CSCD ${cscd}`, kind: 'chinese', title: 'CSCD：中国科学引文数据库收录的期刊，标签显示核心库或扩展库。' });
    const scdTags = tags.filter(value => /^SCD(?:-\d{4})?$/i.test(value));
    const scdYear = scdTags.map(value => value.match(/\d{4}$/)?.[0] || '').sort().pop();
    if (settings.chinese && scdTags.length) list.push({ key: 'scd', text: 'SCD', kind: 'chinese', title: `SCD：科学引文数据库收录的期刊。${scdYear ? `\n${scdYear} 版。` : ''}` });
    if (settings.natureIndex && (row.ni_journal === true || tags.includes('NI期刊'))) list.push({ key: 'natureIndex', text: 'Nature Index', kind: 'natureIndex', title: 'Nature Index：该期刊属于 Nature Index 追踪的期刊范围。' });
    if (settings.indexing) {
      for (const value of [...new Set(tags.filter(value => /^(?:SCI|SCIE|SSCI|AHCI|ESCI)$/i.test(value)).map(value => value.toUpperCase()))]) {
        const names = { SCI: '科学引文索引', SCIE: '科学引文索引扩展版', SSCI: '社会科学引文索引', AHCI: '艺术与人文引文索引', ESCI: '新兴来源引文索引' };
        list.push({ key: 'indexing', text: value, kind: 'indexing', title: `${value}：${names[value]}，Web of Science 的期刊引文索引类型。` });
      }
    }
    const xinrui = row.xuankan_2026 || tag(/^新锐[1-4]区$/).replace(/^新锐/, '');
    if (settings.xinrui && xinrui) list.push({ key: 'xinrui', text: `新锐 ${xinrui}`, kind: 'xinrui', title: `新锐分区：新锐期刊分区表对期刊的分区，通常分为 1区至4区。${row.xuankan_2026 ? '\n数据年份：2026。' : ''}` });
    if (settings.warning && (row.warning_latest || tags.includes('期刊预警'))) list.push({ key: 'warning', text: '中科院预警', kind: 'warning', title: `中科院预警：该期刊被标记在中科院期刊预警相关名单中。${row.warning_latest ? `\n记录：${row.warning_latest}。` : ''}` });
    if (settings.warning && (row.xuankan_warning || tags.includes('新锐预警'))) list.push({ key: 'xinruiWarning', text: '新锐预警', kind: 'warning', title: '新锐预警：该期刊被标记在新锐期刊预警相关名单中。' });
    if (settings.ccf && Array.isArray(row.ccf_records)) {
      const years = row.ccf_records.map(record => Number(record.year)).filter(year => Number.isInteger(year) && year >= 1900 && year <= 2100);
      const latest = years.length ? Math.max(...years) : null;
      const records = row.ccf_records.filter(record => !latest || Number(record.year) === latest);
      for (const value of [...new Set(records.map(record => String(record.level || '').trim()).filter(Boolean))]) {
        list.push({ key: 'ccf', text: `CCF ${value}`, kind: 'ccf', title: `CCF：中国计算机学会推荐目录中的期刊等级。${latest ? `\n目录年份：${latest}。` : ''}` });
      }
    }
    if (settings.ccf && !list.some(item => item.text.startsWith('CCF '))) {
      const ccf = tag(/^CCF-[ABC](?:类)?$/i);
      if (ccf) list.push({ key: 'ccf', text: ccf.replace(/^CCF-/i, 'CCF '), kind: 'ccf', title: 'CCF：中国计算机学会推荐目录中的期刊等级；年份以期刊详情为准。' });
    }
    if (settings.ccf && Array.isArray(row.ccft_records)) {
      const years = row.ccft_records.map(record => Number(record.year)).filter(year => Number.isInteger(year) && year >= 1900 && year <= 2100);
      const latest = years.length ? Math.max(...years) : null;
      const records = row.ccft_records.filter(record => !latest || Number(record.year) === latest);
      for (const value of [...new Set(records.map(record => String(record.tier || '').trim().toUpperCase()).filter(value => /^T[1-4]$/.test(value)))]) {
        list.push({ key: 'ccft', text: `CCFT ${value}`, kind: 'ccft', title: `CCFT：中国计算机学会科技期刊分级中的期刊等级。${latest ? `\n目录年份：${latest}。` : ''}` });
      }
    }
    if (settings.ccf && !list.some(item => item.text.startsWith('CCFT '))) {
      const ccft = tag(/^CCFT-T[1-4]$/i);
      if (ccft) list.push({ key: 'ccft', text: ccft.replace(/^CCFT-/i, 'CCFT '), kind: 'ccft', title: 'CCFT：中国计算机学会科技期刊分级中的期刊等级。' });
    }
    if (settings.ei && (row.ei_indexed === true || tags.some(value => /^EI$/i.test(value)))) list.push({ key: 'ei', text: 'EI', kind: 'indexing', title: 'EI：该期刊被标记为工程索引（Engineering Index）收录。' });
    if (settings.ft50 && ft50.has(normalizeTitle(row.title))) list.push({ key: 'ft50', text: 'FT50', kind: 'hq', title: 'FT50：Financial Times 商学院研究排名所用的 50 种期刊名单。\n目录：2026 年版；来源：牛津大学 Bodleian Libraries（CC BY 4.0）。' });
    const business = businessRankings(row);
    if (settings.ajg && business.ajg) list.push({ key: 'ajg', text: `ABS ${business.ajg}`, kind: 'hq', title: 'ABS / AJG：英国商学院协会 Academic Journal Guide 的期刊等级。\n目录：2024 年版。' });
    if (settings.utd24 && business.utd24) list.push({ key: 'utd24', text: 'UTD24', kind: 'hq', title: 'UTD24：德克萨斯大学达拉斯分校商学院研究排名所追踪的 24 种期刊。' });
    if (settings.fms && business.fms) list.push({ key: 'fms', text: `FMS ${business.fms}`, kind: 'hq', title: 'FMS：管理科学高质量期刊推荐列表的期刊等级。\n目录：2025 年版。' });
    if (settings.abdc && business.abdc) list.push({ key: 'abdc', text: `ABDC ${business.abdc}`, kind: 'hq', title: 'ABDC：澳大利亚商学院院长委员会期刊质量列表的期刊等级。\n目录：2025 年版第 3 次修订。' });
    const visibility = settings.badgeVisibility && typeof settings.badgeVisibility === 'object' ? settings.badgeVisibility : {};
    const order = badgeOrder(settings.badgeOrder);
    return list.filter(item => visibility[item.key] !== false).sort((a, b) => order.indexOf(a.key) - order.indexOf(b.key))
      .map(item => ({ ...item, colorLevel: badgeLevelKey(item.key, item.text), title: `${item.title}\n${publicationNote(item, row)}`, text: badgeText(item.key, item.text, settings.badgeAliases) }));
  }

  globalThis.ScanSciCore = { extensionPath, defaults, translationProviders, translationDefaults, translationSettings, translationTitleFontSize, translationContrastRatio, translationTitleReadableColor, badgeCatalog, badgePrefixes, badgeAlias, badgeText, layoutDefaults, badgeLayout, badgeOrder, badgePalette, badgeLevelKey, badgeColor, normalizeIssn, validIssn, normalizeDoi, normalizeTitle, setBusinessRankings, businessRankingCount, businessRankings, localBusinessJournal, articleHeading, adjacentCompanion, matchJournal, scholarJournal, scholarProfileJournal, doiFromUrl, schemaJournal, badges };
})();
