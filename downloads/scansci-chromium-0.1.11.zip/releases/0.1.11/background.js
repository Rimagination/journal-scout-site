(() => {
  const api = globalThis.chrome || globalThis.browser;
  const core = globalThis.ScanSciCore;
  const cache = new Map();
  const pending = new Map();
  const detailCache = new Map();
  const pendingDetails = new Map();
  const articleCache = new Map();
  const pendingDoi = new Map();
  const pendingArticles = new Map();
  const translationCache = new Map();
  const pendingTranslations = new Map();
  const activeTranslations = new Map();
  const sessionCache = api.storage?.session;
  const sessionCacheKey = 'journalSearchCacheV1';
  let cacheTimer;
  const cacheReady = sessionCache ? new Promise(resolve => {
    try {
      sessionCache.get(sessionCacheKey, stored => {
        const data = !api.runtime.lastError && stored?.[sessionCacheKey];
        for (const [entries, target] of [[data?.search, cache], [data?.details, detailCache], [data?.articles, articleCache]]) {
          if (!Array.isArray(entries)) continue;
          for (const item of entries.slice(-100)) {
            if (Array.isArray(item) && item.length === 2 && item[1]?.expires > Date.now()) target.set(item[0], item[1]);
          }
        }
        resolve();
      });
    } catch { resolve(); }
  }) : Promise.resolve();
  let translationSerial = 0;
  let collectionQueue = Promise.resolve();
  let badgeColorQueue = Promise.resolve();
  let translationSettingsQueue = Promise.resolve();
  let extraSiteQueue = Promise.resolve();
  let running = 0;
  const queue = [];

  function persistJournalCache() {
    if (!sessionCache || cacheTimer) return;
    cacheTimer = setTimeout(() => {
      cacheTimer = undefined;
      // ponytail: session snapshots keep at most 100 recent entries and 200k characters per cache; use IndexedDB for larger working sets.
      const recent = entries => {
        let size = 0;
        return [...entries].slice(-100).reverse().filter(([, value]) => {
          const length = JSON.stringify(value).length;
          if (value.expires <= Date.now() || size + length > 200000) return false;
          size += length;
          return true;
        }).reverse();
      };
      try { sessionCache.set({ [sessionCacheKey]: { search: recent(cache), details: recent(detailCache), articles: recent(articleCache) } }, () => { void api.runtime.lastError; }); } catch { /* A full or unavailable session cache falls back to network. */ }
    }, 250);
  }

  // ponytail: three concurrent requests cap load on the existing public API; add a batch endpoint if usage grows.
  function schedule(task) {
    return new Promise((resolve, reject) => {
      queue.push({ task, resolve, reject });
      const drain = () => {
        while (running < 3 && queue.length) {
          const job = queue.shift();
          running += 1;
          Promise.resolve().then(job.task).then(job.resolve, job.reject).finally(() => { running -= 1; drain(); });
        }
      };
      drain();
    });
  }

  async function json(url) {
    const response = await fetch(url, { credentials: 'omit', referrerPolicy: 'no-referrer', signal: AbortSignal.timeout(12000) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  }

  async function search(query) {
    const key = String(query || '').trim().slice(0, 120);
    if (!key) return [];
    await cacheReady;
    const normalized = key.toLowerCase();
    const hit = cache.get(normalized);
    if (hit && hit.expires > Date.now()) {
      cache.delete(normalized); cache.set(normalized, hit); persistJournalCache();
      return hit.items;
    }
    if (pending.has(normalized)) return pending.get(normalized);
    const url = new URL('https://www.scansci.com/api/journals/search');
    url.search = new URLSearchParams({ q: key, limit: '20' });
    const request = schedule(async () => {
      const result = await json(url);
      if (!result.ok || !Array.isArray(result.items)) throw new Error('Journal Scout unavailable');
      if (cache.size >= 300) cache.delete(cache.keys().next().value);
      cache.set(normalized, { items: result.items, expires: Date.now() + (result.items.length ? 6 * 3600000 : 15 * 60000) });
      persistJournalCache();
      return result.items;
    }).finally(() => pending.delete(normalized));
    pending.set(normalized, request);
    return request;
  }

  async function lookup(message) {
    const title = String(message.title || '').trim().slice(0, 120);
    const issns = Array.isArray(message.issns) ? [...new Set(message.issns.filter(core.validIssn).map(core.normalizeIssn))].slice(0, 3) : [];
    const normalizeCn = value => String(value || '').toUpperCase().replace(/[\s-]+/g, '').replace(/^CN/, '');
    const cnNumber = typeof message.cnNumber === 'string' && /^\d{6}\/[A-Z0-9]{1,4}$/.test(normalizeCn(message.cnNumber)) ? normalizeCn(message.cnNumber) : '';
    const article = articleIdentity(message);
    const hints = [{ title, issns }];
    for (let index = 0; index < hints.length; index += 1) {
      const hint = hints[index];
      const identifiers = [...new Set(hint.issns.filter(core.validIssn).map(core.normalizeIssn))];
      if (identifiers.length) {
        const searches = await Promise.all(identifiers.map(search));
        const matches = searches.map((rows, position) => core.matchJournal(rows, { title: '', issns: [identifiers[position]] }));
        const ambiguous = searches.some((rows, position) => rows.filter(row => [row.issn, row.eissn].some(
          value => core.validIssn(value) && core.normalizeIssn(value) === identifiers[position])).length > 1);
        const found = matches.filter(Boolean);
        const ids = new Set(found.map(row => row.id));
        if (!ambiguous && ids.size === 1) {
          const match = found[0];
          const duplicateStoredIssn = core.validIssn(match.issn) && core.validIssn(match.eissn) &&
            core.normalizeIssn(match.issn) === core.normalizeIssn(match.eissn);
          const trustedDuplicate = message.allowDuplicateDatabaseIssn && duplicateStoredIssn && hint.title &&
            core.normalizeTitle(hint.title) === core.normalizeTitle(match.title);
          if (found.length === matches.length || !core.validIssn(match.issn) || !core.validIssn(match.eissn) || trustedDuplicate) {
            return message.details ? await withDetails(match) : match;
          }
        }
        if (message.allowMissingIssnTitle && !ambiguous && !found.length && hint.title) {
          const exact = (await search(hint.title)).filter(row => core.normalizeTitle(row.title) === core.normalizeTitle(hint.title));
          if (exact.length === 1 && ![exact[0].issn, exact[0].eissn].some(core.validIssn)) {
            return message.details ? await withDetails(exact[0]) : exact[0];
          }
        }
        if (cnNumber && !ambiguous && !found.length && hint.title) {
          const matches = (await search(hint.title)).filter(row => core.normalizeTitle(row.title) === core.normalizeTitle(hint.title) && normalizeCn(row.cn_number) === cnNumber);
          if (matches.length === 1 && ![matches[0].issn, matches[0].eissn].some(core.validIssn)) {
            return message.details ? await withDetails(matches[0]) : matches[0];
          }
        }
      } else if (hint.title) {
        // Some ResearchGate feed cards omit the ISSN and spell an ampersand
        // as "and". Check both forms and accept only one journal identity.
        let alternate = '';
        if (message.titleVariants === 'and-ampersand') {
          if (/\band\b/i.test(hint.title) && !hint.title.includes('&')) alternate = hint.title.replace(/\band\b/gi, '&');
          else if (hint.title.includes('&') && !/\band\b/i.test(hint.title)) alternate = hint.title.replace(/&/g, 'and');
        }
        if (alternate) {
          const names = new Set([hint.title, alternate].map(core.normalizeTitle));
          const searches = await Promise.all([search(hint.title), search(alternate)]);
          const matches = new Map();
          for (const row of searches.flat()) {
            if (names.has(core.normalizeTitle(row.title))) matches.set(row.id ?? JSON.stringify(row), row);
          }
          if (matches.size === 1) {
            const match = matches.values().next().value;
            return message.details ? await withDetails(match) : match;
          }
          if (matches.size > 1) return null;
        }
        const match = core.matchJournal(await search(hint.title), hint);
        if (match) return message.details ? await withDetails(match) : match;
      }
      if (index === 0 && !message.requireArticleTitle && core.normalizeDoi(message.doi)) {
        const resolved = await doiJournal(core.normalizeDoi(message.doi)).catch(error => { if (!article) throw error; return null; });
        if (resolved) hints.push(resolved);
      }
    }
    // ponytail: fetch at most eight complete candidates; larger or truncated searches need a server-side exact-alias endpoint.
    if (hints.length === 1 && !issns.length && title && /[a-z]/i.test(title) && !/(?:\.\.\.|…)/.test(title)) {
      const candidates = await search(title);
      if (candidates.length && candidates.length <= 8 && candidates.every(row => Number.isSafeInteger(row.id) && row.id > 0)) {
        const details = await Promise.all(candidates.map(detail));
        if (details.every(row => Array.isArray(row?.abbreviations))) {
          const matches = candidates.filter((row, index) => details[index].abbreviations.some(
            abbreviation => core.normalizeTitle(abbreviation) === core.normalizeTitle(title)));
          if (matches.length === 1) return message.details ? await withDetails(matches[0]) : matches[0];
        }
      }
    }
    if (hints.length === 1 && article) {
      const resolved = await articleJournal(article);
      // Reuse exact journal matching once; recovered metadata does not trigger another article search.
      if (resolved) return lookup({ title: resolved.title, issns: resolved.issns, details: message.details });
    }
    return null;
  }

  function cachedArticle(key) {
    const hit = articleCache.get(key);
    if (!hit || hit.expires <= Date.now()) return undefined;
    articleCache.delete(key); articleCache.set(key, hit); persistJournalCache();
    return hit;
  }

  function rememberArticle(key, hint) {
    if (articleCache.size >= 300 && !articleCache.has(key)) articleCache.delete(articleCache.keys().next().value);
    articleCache.set(key, { hint, expires: Date.now() + (hint ? 6 * 3600000 : 15 * 60000) });
    persistJournalCache();
    return hint;
  }

  function articleIdentity(message) {
    if (typeof message.articleTitle !== 'string' || message.articleTitle.length > 400) return null;
    const title = message.articleTitle.trim();
    const normalized = core.normalizeTitle(title);
    if (normalized.length < 24 || /(?:\.{3}|…)/.test(title)) return null;
    if ((normalized.match(/[a-z][a-z0-9]*/g) || []).length < 4 && (normalized.match(/[\u3400-\u9fff]/g) || []).length < 12) return null;
    const year = message.articleYear ?? '';
    if (typeof year !== 'string' || (year && !/^\d{4}$/.test(year))) return null;
    const doi = core.normalizeDoi(message.doi).toLowerCase();
    if (message.doi && !doi) return null;
    return { title, normalized, year, doi };
  }

  function crossrefJournal(work) {
    const title = Array.isArray(work?.['container-title']) && typeof work['container-title'][0] === 'string' ? work['container-title'][0].trim() : '';
    const issns = Array.isArray(work?.ISSN) ? [...new Set(work.ISSN.filter(core.validIssn).map(core.normalizeIssn))].slice(0, 3) : [];
    const hint = { title: title.length <= 120 ? title : '', issns };
    return hint.title || hint.issns.length ? hint : null;
  }

  async function articleJournal(article) {
    await cacheReady;
    const key = `title\n${article.normalized}\n${article.year}\n${article.doi}`;
    const hit = cachedArticle(key);
    if (hit) return hit.hint;
    if (pendingArticles.has(key)) return pendingArticles.get(key);
    if (pendingArticles.size >= 300) return null;
    // ponytail: inspect five Crossref candidates; uncertain identities stay unlabelled rather than using fuzzy matches.
    const url = new URL('https://api.crossref.org/works');
    url.search = new URLSearchParams({ 'query.title': article.title, rows: '5' });
    const request = schedule(async () => {
      const data = await json(url);
      if (!Array.isArray(data?.message?.items) || data.message.items.length > 5) throw new Error('Invalid Crossref article response');
      const matches = new Map();
      for (const work of data.message.items.slice(0, 5)) {
        if (work?.type !== 'journal-article' || !Array.isArray(work.title) || !work.title.some(title => typeof title === 'string' && title.length <= 400 && core.normalizeTitle(title) === article.normalized)) continue;
        const doi = core.normalizeDoi(work.DOI).toLowerCase();
        if (!doi || (article.doi && article.doi !== doi)) continue;
        if (article.year && !['published', 'issued', 'published-online', 'published-print'].some(field => String(work[field]?.['date-parts']?.[0]?.[0]) === article.year)) continue;
        const hint = crossrefJournal(work);
        if (matches.has(doi) && JSON.stringify(matches.get(doi)) !== JSON.stringify(hint)) return rememberArticle(key, null);
        matches.set(doi, hint);
      }
      return rememberArticle(key, matches.size === 1 ? matches.values().next().value : null);
    }).finally(() => pendingArticles.delete(key));
    pendingArticles.set(key, request);
    return request;
  }

  async function doiJournal(doi) {
    await cacheReady;
    const key = doi.toLowerCase();
    const cacheKey = `doi\n${key}`;
    const hit = cachedArticle(cacheKey);
    if (hit) return hit.hint;
    if (pendingDoi.has(key)) return pendingDoi.get(key);
    const request = (async () => {
      let hint;
      try {
        const data = await schedule(() => json(`https://api.crossref.org/works/${encodeURIComponent(doi)}`));
        const work = data?.message;
        if (core.normalizeDoi(work?.DOI).toLowerCase() !== key || work?.type !== 'journal-article') return null;
        hint = { title: String(work['container-title']?.[0] || '').slice(0, 120), issns: (work.ISSN || []).filter(core.validIssn).slice(0, 3) };
      } catch {
        const searchUrl = new URL('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi');
        searchUrl.search = new URLSearchParams({ db: 'pubmed', retmode: 'json', term: `${doi}[aid]`, retmax: '2' });
        const data = await schedule(() => json(searchUrl));
        const ids = data?.esearchresult?.idlist || [];
        if (ids.length !== 1 || !/^\d{1,12}$/.test(String(ids[0]))) return null;
        const summaryUrl = new URL('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi');
        summaryUrl.search = new URLSearchParams({ db: 'pubmed', retmode: 'json', id: ids[0] });
        const summary = await schedule(() => json(summaryUrl));
        const work = summary?.result?.[ids[0]];
        if (!work?.articleids?.some(item => item.idtype === 'doi' && core.normalizeDoi(item.value).toLowerCase() === key)) return null;
        hint = { title: String(work.fulljournalname || '').slice(0, 120), issns: [work.issn, work.essn].filter(core.validIssn) };
      }
      if (!hint.title && !hint.issns.length) return null;
      return rememberArticle(cacheKey, hint);
    })().finally(() => pendingDoi.delete(key));
    pendingDoi.set(key, request);
    return request;
  }

  async function detail(row) {
    if (!Number.isSafeInteger(row.id) || row.id <= 0) return null;
    await cacheReady;
    const hit = detailCache.get(row.id);
    if (hit && hit.expires > Date.now()) {
      detailCache.delete(row.id); detailCache.set(row.id, hit); persistJournalCache();
      return hit.journal;
    }
    if (pendingDetails.has(row.id)) return pendingDetails.get(row.id);
    const url = new URL('https://www.scansci.com/api/journals/detail');
    url.search = new URLSearchParams({ id: String(row.id) });
    const request = schedule(async () => {
      const result = await json(url);
      if (!result.ok || result.journal?.id !== row.id) throw new Error('Journal detail unavailable');
      if (detailCache.size >= 300) detailCache.delete(detailCache.keys().next().value);
      detailCache.set(row.id, { journal: result.journal, expires: Date.now() + 6 * 3600000 });
      persistJournalCache();
      return result.journal;
    }).catch(() => null).finally(() => pendingDetails.delete(row.id));
    pendingDetails.set(row.id, request);
    return request;
  }

  async function withDetails(row) {
    const extra = await detail(row);
    if (!extra) return row;
    const fields = ['ccf_records', 'ccft_records', 'ei_indexed', 'if_history', 'cas_history'];
    return { ...row, ...Object.fromEntries(fields.filter(key => extra[key] !== undefined).map(key => [key, extra[key]])) };
  }

  function translationToken(sender, id) { return `${sender.tab?.id ?? 'extension'}:${sender.frameId ?? 0}:${id}`; }

  function cancelTranslationToken(token) {
    const task = activeTranslations.get(token);
    if (!task) return;
    activeTranslations.delete(token);
    task.consumers.delete(token);
    if (!task.consumers.size) task.controller.abort();
  }

  function cancelTranslation(message, sender) {
    if (typeof message.requestId !== 'string' || !/^[0-9a-f-]{36}$/i.test(message.requestId)) return;
    cancelTranslationToken(translationToken(sender, message.requestId));
  }

  function cancelTabTranslations(tabId) {
    for (const token of activeTranslations.keys()) {
      if (token.startsWith(`${tabId}:`)) cancelTranslationToken(token);
    }
  }
  api.tabs?.onRemoved?.addListener(cancelTabTranslations);
  api.tabs?.onUpdated?.addListener((tabId, change) => { if (change.status === 'loading') cancelTabTranslations(tabId); });

  async function translate(message, sender) {
    const text = typeof message.text === 'string' ? message.text.trim() : '';
    const provider = message.provider ?? 'edge';
    if (!text || Array.from(text).length > 1500 || !['auto', 'zh-CN', 'en'].includes(message.target) || !Object.hasOwn(core.translationProviders, provider)) throw new Error('invalid_translation_text');
    const han = (text.match(/[\u3400-\u9fff]/g) || []).length;
    const latin = (text.match(/[a-z]/gi) || []).length;
    const target = message.target === 'auto' ? (han && han >= latin / 3 ? 'en' : 'zh-CN') : message.target;
    const key = `${provider}\n${target}\n${text}`;
    if (translationCache.has(key)) return translationCache.get(key);
    let task = pendingTranslations.get(key);
    if (task?.controller.signal.aborted) { pendingTranslations.delete(key); task = null; }
    if (!task && pendingTranslations.size >= 40) throw new Error('translation_busy');
    if (!task) {
      task = { controller: new AbortController(), consumers: new Set() };
      const signal = AbortSignal.any([task.controller.signal, AbortSignal.timeout(45000)]);
      const currentTask = task;
      task.promise = (async () => {
      const encoder = new TextEncoder();
      const groups = [];
      for (const paragraph of text.split(/\r?\n\s*\r?\n/)) {
        const parts = [];
        let chunk = '', bytes = 0;
        for (const character of paragraph.replace(/\s*\r?\n\s*/g, ' ')) {
          const size = encoder.encode(character).length;
          if (bytes + size > 480) {
            const space = chunk.lastIndexOf(' ');
            const end = space > chunk.length / 2 ? space + 1 : chunk.length;
            parts.push(chunk.slice(0, end));
            chunk = chunk.slice(end); bytes = encoder.encode(chunk).length;
          }
          chunk += character; bytes += size;
        }
        if (chunk.trim()) parts.push(chunk);
        if (parts.length) groups.push(parts);
      }
      if (groups.reduce((count, parts) => count + parts.length, 0) > 20) throw new Error('translation_fragmented');
      const paragraphs = [];
      for (const parts of groups) {
        const translated = [];
        for (const part of parts) {
          signal.throwIfAborted();
          const url = new URL(provider === 'edge' ? 'https://edge.microsoft.com/translate/translatetext' : 'https://transmart.qq.com/api/imt');
          let body;
          if (provider === 'edge') {
            url.search = new URLSearchParams({ to: target === 'en' ? 'en' : 'zh-CHS' });
            body = [part.trim()];
          } else {
            body = { header: { fn: 'auto_translation', client_key: `browser-${crypto.randomUUID()}-${Date.now()}`, session: '', user: '' },
              type: 'plain', model_category: 'normal', text_domain: 'general', source: { lang: 'auto', text_list: [part.trim()] }, target: { lang: target === 'en' ? 'en' : 'zh' } };
          }
          const data = await schedule(async () => {
            signal.throwIfAborted();
            const response = await fetch(url, { method: 'POST', credentials: 'omit', referrerPolicy: 'no-referrer', redirect: 'error',
              headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.any([signal, AbortSignal.timeout(12000)]) });
            if (response.status === 429) throw new Error('translation_quota');
            if (!response.ok) throw new Error('translation_unavailable');
            return response.json();
          });
          signal.throwIfAborted();
          if (provider === 'transmart' && /quota|limit/i.test(String(data?.header?.ret_code || ''))) throw new Error('translation_quota');
          const raw = provider === 'edge' ? data?.[0]?.translations?.[0]?.text : data?.header?.ret_code === 'succ' ? data?.auto_translation?.[0] : '';
          const result = typeof raw === 'string' ? raw.trim() : '';
          if (!result || result.length > 12000) throw new Error('translation_unavailable');
          translated.push(result);
        }
        paragraphs.push(translated.join(' ').replace(/([\u3400-\u9fff]) +(?=[\u3400-\u9fff])/g, '$1'));
      }
      const value = { text: paragraphs.join('\n\n'), target };
      if (translationCache.size >= 200) translationCache.delete(translationCache.keys().next().value);
      translationCache.set(key, value);
      return value;
      })().finally(() => { if (pendingTranslations.get(key) === currentTask) pendingTranslations.delete(key); });
      pendingTranslations.set(key, task);
    }
    const id = typeof message.requestId === 'string' && /^[0-9a-f-]{36}$/i.test(message.requestId) ? message.requestId : `internal-${++translationSerial}`;
    const token = translationToken(sender, id);
    task.consumers.add(token); activeTranslations.set(token, task);
    return task.promise.finally(() => {
      task.consumers.delete(token);
      if (activeTranslations.get(token) === task) activeTranslations.delete(token);
    });
  }

  async function pubmed(ids, database = 'pubmed') {
    if (!['pubmed', 'pmc'].includes(database)) throw new Error('Invalid NCBI database');
    const valid = [...new Set((Array.isArray(ids) ? ids : []).map(String).filter(id => /^\d{1,12}$/.test(id)))].slice(0, 80);
    if (!valid.length) return {};
    const url = new URL('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi');
    url.search = new URLSearchParams({ db: database, retmode: 'json', id: valid.join(',') });
    const data = await schedule(() => json(url));
    const result = {};
    for (const id of valid) {
      const row = data?.result?.[id];
      if (row && (!row.uid || String(row.uid) === id)) {
        const doi = (Array.isArray(row.articleids) ? row.articleids : []).find(item => item.idtype === 'doi');
        result[id] = { title: String(row.fulljournalname || '').slice(0, 120), issns: [row.issn, row.essn].filter(core.validIssn), doi: core.normalizeDoi(doi?.value) };
      }
    }
    return result;
  }

  async function citation(value) {
    const doi = core.normalizeDoi(value);
    if (!doi) throw new Error('Invalid DOI');
    const data = await schedule(() => json(`https://api.crossref.org/works/${encodeURIComponent(doi)}`));
    const work = data?.message;
    if (core.normalizeDoi(work?.DOI).toLowerCase() !== doi.toLowerCase()) throw new Error('DOI mismatch');
    const clean = (value, limit = 1000) => typeof value === 'string' ? value.replace(/\s+/g, ' ').trim().slice(0, limit) : '';
    const first = value => Array.isArray(value) ? clean(value.find(item => typeof item === 'string')) : '';
    const title = first(work.title);
    if (!title) throw new Error('Missing title');
    const authors = (Array.isArray(work.author) ? work.author : []).map(author => {
      const family = clean(author?.family, 200), given = clean(author?.given, 200);
      return family ? [family, given].filter(Boolean).join(', ') : clean(author?.name, 400);
    }).filter(Boolean);
    const date = work.published?.['date-parts']?.[0] || work.issued?.['date-parts']?.[0] || [];
    const year = Number.isInteger(date[0]) && date[0] >= 1000 && date[0] <= 2100 ? String(date[0]) : '';
    return { doi, title, authors, year, journal: first(work['container-title']),
      volume: clean(work.volume, 100), issue: clean(work.issue, 100), page: clean(work.page, 100),
      type: work.type === 'journal-article' ? 'journal' : 'other' };
  }

  function storage(method, value) {
    return new Promise((resolve, reject) => api.storage.local[method](value, result => {
      if (api.runtime.lastError) reject(new Error(api.runtime.lastError.message));
      else resolve(result);
    }));
  }

  const extraSitesKey = 'extraSiteOriginsV1';
  const allSitesKey = 'allHttpsSitesV1';
  const allSitesId = 'scansci_all_https';
  const allSitesPattern = 'https://*/*';
  function extraSite(pattern) {
    if (typeof pattern !== 'string') return null;
    const match = /^https:\/\/([^/*?#]+)\/\*$/.exec(pattern);
    if (!match) return null;
    try {
      const url = new URL(`https://${match[1]}/`);
      if (url.username || url.password || url.port || url.host !== match[1] || !url.hostname) return null;
      const id = `scansci_${[...new TextEncoder().encode(url.hostname)].map(value => value.toString(16).padStart(2, '0')).join('')}`;
      return { id, pattern };
    } catch { return null; }
  }

  function extraSiteFromScript(script) {
    if (!Array.isArray(script?.matches) || script.matches.length !== 1) return null;
    const site = extraSite(script.matches[0]);
    return site?.id === script.id ? site : null;
  }

  function extraSiteCall(object, method, value) {
    return new Promise((resolve, reject) => {
      try {
        object[method](value, result => {
          if (api.runtime.lastError) reject(new Error(api.runtime.lastError.message));
          else resolve(result);
        });
      } catch (error) { reject(error); }
    });
  }

  function withExtraSites(task) {
    const job = extraSiteQueue.then(task);
    extraSiteQueue = job.catch(() => {});
    return job;
  }

  async function savedExtraSites() {
    const values = await storage('get', { [extraSitesKey]: [] });
    return [...new Set((Array.isArray(values[extraSitesKey]) ? values[extraSitesKey] : []).filter(pattern => extraSite(pattern)))];
  }

  function snapshotExtraSites() {
    return withExtraSites(async () => {
      const scripts = await extraSiteCall(api.scripting, 'getRegisteredContentScripts', {});
      const existing = (scripts || []).map(extraSiteFromScript).filter(Boolean).map(site => site.pattern);
      const sites = [...new Set([...(await savedExtraSites()), ...existing])];
      await storage('set', { [extraSitesKey]: sites });
    });
  }

  function editExtraSite(message) {
    const site = extraSite(message.pattern);
    if (!site || !['add', 'remove'].includes(message.action)) return Promise.reject(new Error('Invalid site'));
    return withExtraSites(async () => {
      const sites = await savedExtraSites();
      if (message.action === 'add') {
        const allowed = await extraSiteCall(api.permissions, 'contains', { origins: [site.pattern] });
        const scripts = await extraSiteCall(api.scripting, 'getRegisteredContentScripts', { ids: [site.id] });
        if (!allowed || !(scripts || []).some(script => extraSiteFromScript(script)?.id === site.id)) throw new Error('Site is not authorized');
        if (!sites.includes(site.pattern)) sites.push(site.pattern);
      } else {
        const index = sites.indexOf(site.pattern);
        if (index >= 0) sites.splice(index, 1);
      }
      await storage('set', { [extraSitesKey]: sites });
      return 'saved';
    });
  }

  function editAllSites(action) {
    if (!['status', 'enable', 'disable'].includes(action)) return Promise.reject(new Error('Invalid action'));
    return withExtraSites(async () => {
      const saved = Boolean((await storage('get', { [allSitesKey]: false }))[allSitesKey]);
      const allowed = await extraSiteCall(api.permissions, 'contains', { origins: [allSitesPattern] });
      const scripts = await extraSiteCall(api.scripting, 'getRegisteredContentScripts', { ids: [allSitesId] });
      const registered = (scripts || []).some(script => script.id === allSitesId);
      if (action === 'status') return { enabled: saved && allowed && registered, allowed };
      if (action === 'enable') {
        if (!allowed) throw new Error('Sites are not authorized');
        if (!registered) {
          const js = ['core.js', 'results.js', 'content.js', 'translate.js'].map(file => core.extensionPath(file, api.runtime));
          const css = [core.extensionPath('content.css', api.runtime)];
          await extraSiteCall(api.scripting, 'registerContentScripts', [{ id: allSitesId, matches: [allSitesPattern], js, css, runAt: 'document_end', persistAcrossSessions: true }]);
        }
        try { await storage('set', { [allSitesKey]: true }); }
        catch (error) {
          if (!registered) await extraSiteCall(api.scripting, 'unregisterContentScripts', { ids: [allSitesId] }).catch(() => {});
          throw error;
        }
        return { enabled: true, allowed: true };
      }
      await storage('set', { [allSitesKey]: false });
      try { if (registered) await extraSiteCall(api.scripting, 'unregisterContentScripts', { ids: [allSitesId] }); }
      catch (error) { await storage('set', { [allSitesKey]: saved }); throw error; }
      return { enabled: false, allowed };
    });
  }

  async function restoreExtraSites() {
    await withExtraSites(async () => {
      const scripts = await extraSiteCall(api.scripting, 'getRegisteredContentScripts', {});
      const current = new Set((scripts || []).map(extraSiteFromScript).filter(Boolean).map(site => site.id));
      const existing = (scripts || []).map(extraSiteFromScript).filter(Boolean).map(site => site.pattern);
      const sites = [...new Set([...(await savedExtraSites()), ...existing])];
      const js = ['core.js', 'results.js', 'content.js', 'translate.js'].map(file => core.extensionPath(file, api.runtime));
      const css = [core.extensionPath('content.css', api.runtime)];
      for (const pattern of sites) {
        const site = extraSite(pattern);
        if (current.has(site.id) || !(await extraSiteCall(api.permissions, 'contains', { origins: [pattern] }))) continue;
        try {
          await extraSiteCall(api.scripting, 'registerContentScripts', [{ id: site.id, matches: [pattern], js, css, runAt: 'document_end', persistAcrossSessions: true }]);
        } catch (error) { console.warn('ScanSci site restore failed:', error?.message || 'unknown error'); }
      }
      const allSites = Boolean((await storage('get', { [allSitesKey]: false }))[allSitesKey]);
      const allAllowed = await extraSiteCall(api.permissions, 'contains', { origins: [allSitesPattern] });
      const allRegistered = (scripts || []).some(script => script.id === allSitesId);
      if (allSites && allAllowed && !allRegistered) {
        try { await extraSiteCall(api.scripting, 'registerContentScripts', [{ id: allSitesId, matches: [allSitesPattern], js, css, runAt: 'document_end', persistAcrossSessions: true }]); }
        catch (error) { console.warn('ScanSci site restore failed:', error?.message || 'unknown error'); }
      } else if ((!allSites || !allAllowed) && allRegistered) {
        await extraSiteCall(api.scripting, 'unregisterContentScripts', { ids: [allSitesId] });
      }
      if (allSites && !allAllowed) await storage('set', { [allSitesKey]: false });
      await storage('set', { [extraSitesKey]: sites });
    });
  }

  if (api.storage?.local && api.permissions?.contains && api.scripting?.getRegisteredContentScripts && api.scripting?.registerContentScripts) {
    globalThis.ScanSciExtraSites = { snapshot: snapshotExtraSites };
    void restoreExtraSites().catch(error => console.warn('ScanSci site restore failed:', error?.message || 'unknown error'));
  }

  function removePaper(message) {
    const job = collectionQueue.then(async () => {
      const values = await storage('get', { savedPapers: [] });
      const papers = Array.isArray(values.savedPapers) ? values.savedPapers : [];
      const doi = core.normalizeDoi(message.doi);
      if (!doi) throw new Error('Invalid DOI');
      await storage('set', { savedPapers: papers.filter(paper => core.normalizeDoi(paper?.doi).toLowerCase() !== doi.toLowerCase()) });
      return 'removed';
    });
    collectionQueue = job.catch(() => {});
    return job;
  }

  function editBadgeColors(message) {
    const job = badgeColorQueue.then(async () => {
      const values = await storage('get', { badgeColors: null, badgeLevelColors: null });
      const colorsFrom = palette => Object.fromEntries(Object.entries(palette).map(([kind, color]) => [kind, { fg: color.fg, bg: color.bg }]));
      if (message.action === 'setLevel' || message.action === 'clearLevel') {
        if (!/^(?:cas|jcr|xinrui)[1-4]$/.test(message.kind)) throw new Error('Invalid badge level');
        const saved = values.badgeLevelColors && typeof values.badgeLevelColors === 'object' && !Array.isArray(values.badgeLevelColors) ? values.badgeLevelColors : {};
        const levels = {};
        for (const [kind, color] of Object.entries(saved)) {
          if (!/^(?:cas|jcr|xinrui)[1-4]$/.test(kind) || !color || typeof color !== 'object') continue;
          const parts = Object.fromEntries(['fg', 'bg'].filter(part => typeof color[part] === 'string' && /^#[0-9a-f]{6}$/i.test(color[part])).map(part => [part, color[part].toLowerCase()]));
          if (Object.keys(parts).length) levels[kind] = parts;
        }
        if (message.action === 'clearLevel') delete levels[message.kind];
        else {
          if (!['fg', 'bg'].includes(message.part) || typeof message.value !== 'string' || !/^#[0-9a-f]{6}$/i.test(message.value)) throw new Error('Invalid badge color');
          levels[message.kind] = { ...levels[message.kind], [message.part]: message.value.toLowerCase() };
        }
        await storage('set', { badgeLevelColors: levels });
        return levels;
      }
      let colors;
      if (message.action === 'init') {
        if (values.badgeColors) return values.badgeColors;
        colors = colorsFrom(core.badgePalette(['b', 'c'].includes(message.base) ? message.base : 'a'));
      } else if (message.action === 'reset') colors = colorsFrom(core.badgePalette('a'));
      else if (message.action === 'set') {
        colors = colorsFrom(core.badgePalette('custom', values.badgeColors));
        if (!Object.hasOwn(colors, message.kind) || !['fg', 'bg'].includes(message.part) ||
            typeof message.value !== 'string' || !/^#[0-9a-f]{6}$/i.test(message.value)) throw new Error('Invalid badge color');
        colors[message.kind][message.part] = message.value.toLowerCase();
      } else throw new Error('Invalid badge color action');
      await storage('set', message.action === 'reset' ? { badgeColors: colors, badgeLevelColors: {} } : { badgeColors: colors });
      return colors;
    });
    badgeColorQueue = job.catch(() => {});
    return job;
  }

  function editTranslationSettings(message) {
    const job = translationSettingsQueue.then(async () => {
      const current = core.translationSettings(await storage('get', { translationProvider: null, autoTranslateTitles: false }));
      let values;
      if (message.action === 'provider' && Object.hasOwn(core.translationProviders, message.value)) {
        values = { translationProvider: message.value, autoTranslateTitles: current.autoTranslateTitles };
      } else if (message.action === 'auto' && typeof message.value === 'boolean') {
        values = { translationProvider: current.translationProvider, autoTranslateTitles: message.value };
      } else throw new Error('Invalid translation setting');
      await storage('set', values);
      return values;
    });
    translationSettingsQueue = job.catch(() => {});
    return job;
  }

  if (api.scripting?.getRegisteredContentScripts && api.scripting?.updateContentScripts) {
    api.scripting.getRegisteredContentScripts({}, scripts => {
      if (api.runtime.lastError) return;
      const js = ['core.js', 'results.js', 'content.js', 'translate.js'].map(file => core.extensionPath(file, api.runtime));
      const css = [core.extensionPath('content.css', api.runtime)];
      const sameFiles = (a, b) => Array.isArray(a) && a.length === b.length && a.every((file, index) => file === b[index]);
      const updates = (scripts || []).filter(script => script.id.startsWith('scansci_') && (!sameFiles(script.js, js) || !sameFiles(script.css, css)))
        .map(script => ({ id: script.id, js, css }));
      if (updates.length) api.scripting.updateContentScripts(updates, () => { if (api.runtime.lastError) console.warn('ScanSci site update failed:', api.runtime.lastError.message); });
    });
  }

  api.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== api.runtime.id || !message || !['lookup', 'pubmed', 'citation', 'paperRemove', 'badgeColors', 'translationSettings', 'translate', 'cancelTranslation', 'extraSite', 'allSites'].includes(message.type)) return false;
    if (message.type === 'extraSite' && sender.url !== api.runtime.getURL(api.runtime.getManifest().action.default_popup)) return false;
    if (message.type === 'allSites' && sender.url?.split('#')[0] !== api.runtime.getURL(api.runtime.getManifest().options_ui.page)) return false;
    const action = message.type === 'lookup' ? lookup(message) : message.type === 'pubmed' ? pubmed(message.ids, message.database)
      : message.type === 'citation' ? citation(message.doi) : message.type === 'paperRemove' ? removePaper(message)
      : message.type === 'translate' ? translate(message, sender) : message.type === 'cancelTranslation' ? Promise.resolve(cancelTranslation(message, sender))
      : message.type === 'translationSettings' ? editTranslationSettings(message) : message.type === 'extraSite' ? editExtraSite(message)
      : message.type === 'allSites' ? editAllSites(message.action) : editBadgeColors(message);
    action.then(data => respond({ ok: true, data }), error => {
      console.warn('ScanSci operation failed:', error?.message || 'unknown error');
      const errorCode = ['invalid_translation_text', 'translation_quota', 'translation_busy', 'translation_fragmented'].includes(error?.message) ? error.message : 'translation_unavailable';
      respond(message.type === 'translate' ? { ok: false, error: errorCode } : { ok: false });
    });
    return true;
  });
})();
