(() => {
  const api=globalThis.chrome||globalThis.browser;
  const status=document.getElementById('customCatalogStatus');
  const toast=document.getElementById('customCatalogToast');
  let toastTimer;
  function hideToast() {
    clearTimeout(toastTimer);
    toast.hidden=true;toast.textContent='';
  }
  function showSuccess(label) {
    hideToast();
    toast.hidden=false;toast.textContent=`“${label}”已加入标签列表`;
    toastTimer=setTimeout(hideToast,1800);
  }
  let xlsxPromise;
  function xlsxLibrary() {
    if(!xlsxPromise) xlsxPromise=new Promise((resolve,reject)=>{
      const script=document.createElement('script');script.src='xlsx-0.20.3.min.js';
      script.onload=()=>resolve(globalThis.XLSX);
      script.onerror=()=>{xlsxPromise=null;script.remove();reject(new Error('Excel 组件未能加载，请重试。'));};
      document.head.append(script);
    });
    return xlsxPromise;
  }
  const picker=document.getElementById('customCatalogFile');
  const importButton=document.getElementById('customCatalogImport');
  importButton.addEventListener('click',()=>picker.click());
  picker.addEventListener('change',async()=>{
    const file=picker.files?.[0];if(!file)return;
    hideToast();
    picker.disabled=importButton.disabled=true;
    status.textContent='正在本机检查 Excel 目录…';
    try {
      const pack=await globalThis.JournalScoutCatalogExcel.importFile(file,await xlsxLibrary());
      await new Promise((resolve,reject)=>api.storage.local.get({customCatalogs:[]},values=>{
        if(api.runtime.lastError) return reject(new Error(api.runtime.lastError.message));
        let next;try{next=globalThis.JournalScoutCatalogs.withPackage(values.customCatalogs,pack);}catch(e){reject(e);return;}
        if(JSON.stringify(next).length>4000000) return reject(new Error('目录合计过大，请在上方标签列表移除部分目录后重试。'));
        api.storage.local.set({customCatalogs:next},()=>api.runtime.lastError ? reject(new Error(api.runtime.lastError.message)) : resolve());
      }));
      status.textContent='';
      showSuccess(pack.label);
    }catch(e){status.textContent=e.message;}
    finally{picker.disabled=importButton.disabled=false;picker.value='';}
  });
  api.runtime.sendMessage({type:'catalogs.check'},()=>{void api.runtime.lastError;});
})();
