/* Keep native values/change events; present one accessible, consistent picker. */
(() => {
  const controls = new WeakMap();
  let opened, sequence = 0, typed = '', typedAt = 0;
  const make = (tag, className) => {
    const node = document.createElement(tag); node.className = className; return node;
  };
  const icon = path => {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    for (const [key, value] of Object.entries({ viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.8', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true' })) svg.setAttribute(key, value);
    const line = document.createElementNS(svg.namespaceURI, 'path'); line.setAttribute('d', path); svg.append(line); return svg;
  };
  function close() {
    if (!opened) return;
    opened.button.setAttribute('aria-expanded', 'false');
    opened.button.removeAttribute('aria-activedescendant');
    opened.menu.remove(); opened = null;
  }
  function active(index) {
    if (!opened) return;
    opened.index = index;
    opened.rows.forEach((row, i) => row.toggleAttribute('data-active', i === index));
    const row = opened.rows[index];
    if (row) { opened.button.setAttribute('aria-activedescendant', row.id); row.scrollIntoView({ block: 'nearest' }); }
  }
  function choose(index) {
    if (!opened || !opened.options[index] || opened.options[index].disabled) return;
    const { select, button, options } = opened;
    const value = options[index].value, changed = select.value !== value;
    close(); select.value = value; button.focus({ preventScroll: true });
    if (changed) {
      select.dispatchEvent(new Event('input', { bubbles: true }));
      select.dispatchEvent(new Event('change', { bubbles: true }));
    }
    syncOne(controls.get(select));
  }
  function open(control) {
    if (control.select.disabled) return;
    close();
    typed = ''; typedAt = 0;
    const { select, button } = control;
    const options = [...select.options].filter(option => !option.hidden);
    if (!options.length) return;
    const menu = make('div', 'scout-select-menu'); menu.id = control.menuId;
    menu.setAttribute('role', 'listbox'); menu.setAttribute('aria-label', button.getAttribute('aria-label'));
    const rows = options.map((option, index) => {
      const row = make('div', 'scout-select-option'); row.id = `${menu.id}-${index}`;
      row.setAttribute('role', 'option'); row.setAttribute('aria-selected', String(option.selected));
      row.setAttribute('aria-disabled', String(option.disabled));
      const text = make('span', 'scout-select-option-text'); text.textContent = option.text;
      row.append(text, icon('m20 6-11 11-5-5'));
      row.addEventListener('pointerdown', event => event.preventDefault());
      row.addEventListener('pointermove', () => { if (!option.disabled) active(index); });
      row.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); choose(index); });
      menu.append(row); return row;
    });
    document.body.append(menu);
    opened = { ...control, menu, options, rows, index: Math.max(0, options.findIndex(option => option.selected)) };
    button.setAttribute('aria-expanded', 'true');
    const anchor = button.getBoundingClientRect(), margin = 12;
    menu.style.minWidth = `${Math.min(anchor.width, innerWidth - margin * 2)}px`;
    const below = innerHeight - anchor.bottom - margin - 6, above = anchor.top - margin - 6;
    const upward = below < Math.min(280, menu.scrollHeight) && above > below;
    menu.style.maxHeight = `${Math.max(40, Math.min(280, upward ? above : below))}px`;
    const bounds = menu.getBoundingClientRect();
    menu.style.left = `${Math.max(margin, Math.min(anchor.left, innerWidth - bounds.width - margin))}px`;
    menu.style.top = `${upward ? Math.max(margin, anchor.top - bounds.height - 6) : anchor.bottom + 6}px`;
    active(opened.index);
  }
  function keydown(event, control) {
    const { key } = event;
    if (key === 'Tab' || key === 'Escape') { close(); if (key === 'Escape') event.preventDefault(); return; }
    const navigation = ['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(key);
    if (navigation || key === 'Enter' || key === ' ') {
      event.preventDefault();
      if (!opened || opened.select !== control.select) { open(control); if (!['Home', 'End'].includes(key)) return; }
      if (!opened) return;
      if (key === 'Enter' || key === ' ') { choose(opened.index); return; }
      const available = opened.options.map((option, index) => option.disabled ? -1 : index).filter(index => index >= 0);
      const position = available.indexOf(opened.index), direction = key === 'ArrowUp' ? -1 : 1;
      active(key === 'Home' ? available[0] : key === 'End' ? available.at(-1) : available[Math.max(0, Math.min(available.length - 1, position + direction))]);
    } else if (key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {
      event.preventDefault();
      if (!opened || opened.select !== control.select) open(control);
      if (!opened) return;
      typed = Date.now() - typedAt > 700 ? key : typed + key; typedAt = Date.now();
      const index = opened.options.findIndex(option => !option.disabled && option.text.toLocaleLowerCase().startsWith(typed.toLocaleLowerCase()));
      if (index >= 0) active(index);
    }
  }
  function syncOne(control) {
    if (!control) return;
    const { select, button, text } = control;
    text.textContent = select.selectedOptions[0]?.text || '';
    button.disabled = select.disabled;
    const name = select.getAttribute('aria-label') || select.labels?.[0]?.textContent.trim() || '选择选项';
    button.setAttribute('aria-label', name);
    if (opened?.select === select && (select.disabled || !select.isConnected)) close();
  }
  function sync(root = document) {
    root.querySelectorAll('select:not([multiple])').forEach(select => {
      if (!controls.has(select)) {
        const wrapper = make('span', 'scout-select'), button = make('button', 'scout-select-trigger');
        const text = make('span', 'scout-select-text'), menuId = `scout-select-${++sequence}`;
        text.id = `${menuId}-value`; button.setAttribute('aria-describedby', text.id);
        button.type = 'button'; button.setAttribute('role', 'combobox');
        button.setAttribute('aria-haspopup', 'listbox'); button.setAttribute('aria-expanded', 'false'); button.setAttribute('aria-controls', menuId);
        button.append(text, icon('m6 9 6 6 6-6'));
        select.before(wrapper); wrapper.append(select, button);
        select.classList.add('scout-select-native'); select.tabIndex = -1; select.setAttribute('aria-hidden', 'true');
        const control = { select, wrapper, button, text, menuId }; controls.set(select, control);
        button.addEventListener('click', event => { event.preventDefault(); if (opened?.select === select) close(); else open(control); });
        button.addEventListener('keydown', event => keydown(event, control));
        select.addEventListener('change', () => syncOne(control));
        select.addEventListener('click', event => { event.preventDefault(); button.focus(); if (opened?.select !== select) open(control); });
        select.addEventListener('focus', () => button.focus({ preventScroll: true }));
        new MutationObserver(() => syncOne(control)).observe(select, { attributes: true, childList: true, subtree: true });
      }
      syncOne(controls.get(select));
    });
  }
  document.addEventListener('pointerdown', event => {
    if (opened && !opened.wrapper.contains(event.target) && !opened.menu.contains(event.target)) close();
  });
  document.addEventListener('focusin', event => { if (opened && !opened.wrapper.contains(event.target)) close(); });
  document.addEventListener('scroll', event => { if (opened && !opened.menu.contains(event.target)) close(); }, true);
  window.addEventListener('resize', close); window.addEventListener('blur', close);
  globalThis.JournalScoutSelect = { sync };
  sync();
})();
