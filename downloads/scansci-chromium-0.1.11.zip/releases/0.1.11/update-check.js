(() => {
  const api = globalThis.chrome || globalThis.browser;
  const status = document.getElementById('updateStatus');
  const manifest = api.runtime.getManifest();
  const current = manifest.version;
  const gecko = manifest.browser_specific_settings?.gecko;
  const isSafari = Boolean(manifest.browser_specific_settings?.safari);
  const isStore = isSafari || ['mnoflinhlbochdphhmjogjfnokncpoec', 'jehpajedcihlfkcichdodghfigadcmbk'].includes(api.runtime.id) ||
    Boolean(gecko?.id && !gecko.update_url);
  const storeCacheMs = 6 * 60 * 60 * 1000;

  function versionParts(value) {
    if (typeof value !== 'string' || !/^\d+(?:\.\d+){0,3}$/.test(value)) return null;
    const parts = value.split('.').map(Number);
    return parts.every(part => Number.isSafeInteger(part) && part <= 65535) ? parts : null;
  }
  function compareVersions(a, b) {
    const left = versionParts(a), right = versionParts(b);
    if (!left || !right) return null;
    for (let i = 0; i < Math.max(left.length, right.length); i++) {
      if ((left[i] || 0) !== (right[i] || 0)) return (left[i] || 0) > (right[i] || 0) ? 1 : -1;
    }
    return 0;
  }
  async function manualVersion() {
    const response = await fetch('https://journal.scansci.com/extension-install.html', {
      credentials: 'omit', cache: 'no-store', referrerPolicy: 'no-referrer', signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) throw new Error('Version page unavailable');
    const html = await response.text();
    if (html.length > 500000) throw new Error('Invalid version page');
    const page = new DOMParser().parseFromString(html, 'text/html');
    const meta = page.querySelector('meta[name="journal-scout-manual-version"]')?.getAttribute('content');
    const oldPage = page.querySelector('.extension-release')?.textContent.match(/手动安装包\s*v(\d+(?:\.\d+){1,3})/i)?.[1];
    const version = meta || oldPage;
    if (!versionParts(version)) throw new Error('Invalid release version');
    return version;
  }
  async function storeVersion() {
    if (!isStore || typeof api.runtime.requestUpdateCheck !== 'function') return null;
    const cached = await new Promise(resolve => api.storage.local.get({ storeUpdateCheck: null }, values => resolve(values.storeUpdateCheck)));
    const age = Date.now() - cached?.checkedAt;
    if (cached?.id === api.runtime.id && cached?.current === current && age >= 0 && age < storeCacheMs &&
        ['no_update', 'update_available'].includes(cached.status)) return cached;
    return new Promise(resolve => {
      let finished = false;
      const timer = setTimeout(() => finish(null), 8000);
      function finish(result) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        if (!result || !['no_update', 'update_available'].includes(result.status)) { resolve(null); return; }
        const record = { id: api.runtime.id, current, status: result.status,
          version: versionParts(result.version) ? result.version : '', checkedAt: Date.now() };
        api.storage.local.set({ storeUpdateCheck: record });
        resolve(record);
      }
      try {
        if (globalThis.browser?.runtime?.requestUpdateCheck) {
          Promise.resolve(globalThis.browser.runtime.requestUpdateCheck()).then(finish, () => finish(null));
        } else {
          api.runtime.requestUpdateCheck((state, details) => {
            if (api.runtime.lastError) finish(null);
            else finish({ status: state, version: details?.version });
          });
        }
      } catch { finish(null); }
    });
  }
  let manual;
  let store = isStore ? undefined : null;
  function render() {
    status.dataset.state = '';
    if (isSafari) {
      status.textContent = manual === undefined ? '正在检查官网版本…' : manual
        ? `App Store 管理更新；官网手动版 v${manual}` : 'App Store 管理更新；官网版本暂不可用';
      return;
    }
    if (store?.status === 'update_available') {
      status.dataset.state = 'update';
      const laterManual = manual && compareVersions(manual, store.version || current) > 0 ? `；官网手动版 v${manual}` : '';
      status.textContent = `商店有更新${store.version ? ` v${store.version}` : ''}，浏览器会自动更新${laterManual}`;
      return;
    }
    if (manual === undefined) { status.textContent = '正在检查更新…'; return; }
    if (!manual) {
      status.textContent = store?.status === 'no_update' ? '商店暂未检测到更新；官网检查失败' : '暂时无法检查更新';
      return;
    }
    const comparison = compareVersions(current, manual);
    if (comparison === null) { status.textContent = '无法识别当前版本'; return; }
    const storeSuffix = store?.status === 'no_update' ? '商店暂未检测到更新' : store === undefined ? '正在检查商店' : '商店状态暂不可用';
    if (comparison < 0) {
      status.dataset.state = 'update';
      status.textContent = isStore ? `官网有新版 v${manual}；${storeSuffix}` : `发现新版本 v${manual}，请手动更新`;
    } else if (comparison === 0) {
      status.textContent = !isStore || store?.status === 'no_update' ? '已是最新版本' : `官网手动版已是最新；${storeSuffix}`;
    } else {
      status.textContent = isStore ? `官网手动版 v${manual}；${storeSuffix}` : `当前版本高于官网手动版 v${manual}`;
    }
  }
  void manualVersion().then(value => { manual = value; render(); }, () => { manual = null; render(); });
  if (isStore && !isSafari) void storeVersion().then(value => { store = value; render(); }, () => { store = null; render(); });
})();
