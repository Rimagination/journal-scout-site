(() => {
  if (globalThis.ScanSciResults) return;
  const entries = new Map();
  const originals = new Map();
  let panel;
  let sorting = false;
  let applyScheduled = false;

  function isWos() {
    const host = location.hostname;
    return ['webofscience.com', 'webofscience.clarivate.cn'].some(domain => host === domain || host.endsWith(`.${domain}`));
  }

  function isScholar() { return location.hostname.startsWith('scholar.google.'); }

  function mountPanel() {
    if (!panel) return;
    const host = location.hostname;
    if (isWos()) {
      const form = document.querySelector('app-refine-panel #snRefine, form#snRefine');
      if (form) {
        const anchor = form.querySelector('[data-ta="filter-section-FB"]') || form.querySelector('.search-box');
        if (anchor) {
          if (anchor.nextElementSibling !== panel) anchor.after(panel);
        } else if (panel.parentElement !== form) form.prepend(panel);
        return;
      }
    }
    if (isScholar()) {
      const sidebar = document.querySelector('#gs_bdy_sb_in');
      if (sidebar) {
        const firstSection = sidebar.querySelector(':scope > .gs_bdy_sb_sec:not(.scansci-filter-panel)');
        if (firstSection) {
          if (firstSection.nextElementSibling !== panel) firstSection.after(panel);
        } else if (panel.parentElement !== sidebar) sidebar.prepend(panel);
        return;
      }
    }
    const sites = [
      ['kns.cnki.net', '.sidebar-filter'],
      ['pmc.ncbi.nlm.nih.gov', '.pmc-sidenav__container'],
      ['pubmed.ncbi.nlm.nih.gov', '#search-page #static-filters'],
      ['scholar.google.', '#gs_bdy_sb'],
      ['xueshu.baidu.com', '#leftnav, .content-wrap > .filters-wrap'],
      ['sciencedirect.com', '#srp-facets'],
      ['link.springer.com', "[data-test='springer-search-default-page'] [data-test='content-types']"],
      ['nature.com', '[data-test="search-filter-box"]'],
      ['ieeexplore.ieee.org', '#xplMainContent .show-filter-box'],
      ['dl.acm.org', "[class*='search'] #filter"],
      ['aminer.cn', "[class*='search-paper-component-paperSearch'] [class*='search-paper-filter-searchPaperFilter']"],
      ['semanticscholar.org', '#main-content > .flex-item__right-column'],
    ];
    const selectors = sites.filter(([domain]) => domain.endsWith('.') ? host.startsWith(domain) : host === domain || host.endsWith(`.${domain}`));
    const sidebar = selectors.map(([, selector]) => document.querySelector(selector)).find(Boolean);
    if (sidebar) {
      if (!isScholar() && !isWos()) panel.classList?.add('scansci-filter-embedded');
      if (panel.parentElement !== sidebar) sidebar.prepend(panel);
      return;
    }
    panel.classList?.remove('scansci-filter-embedded');
    const card = [...entries.keys()].find(item => item.isConnected && item.parentElement);
    if (!card) return;
    const container = card.closest('table') || (card.parentElement === document.body ? card : card.parentElement);
    if (container !== panel && panel.nextElementSibling !== container) container.before(panel);
  }

  function track(card, signature) {
    if (!card) return;
    const previous = entries.get(card);
    if (previous?.signature === signature) return;
    entries.set(card, { signature, row: null, metrics: [articleMetric(card, 'year'), articleMetric(card, 'cited')] });
    if (panel && !applyScheduled) {
      applyScheduled = true;
      queueMicrotask(() => { applyScheduled = false; apply(); });
    }
    return true;
  }

  function record(card, signature, row, isCurrent) {
    const entry = entries.get(card);
    if (!entry || entry.signature !== signature || !row) return;
    entry.row = row;
    entry.isCurrent = isCurrent;
    if (!panel) createPanel();
    mountPanel();
    apply();
  }

  function createPanel() {
    if (!document.body) return;
    panel = document.createElement('details');
    panel.className = `scansci-filter-panel${isWos() ? ' scansci-filter-wos' : isScholar() ? ' scansci-filter-scholar gs_bdy_sb_sec' : ''}`;
    panel.open = true;
    panel.innerHTML = `<summary>Journal Scout</summary><div class="scansci-filter-body">
      <fieldset class="scansci-filter-impact"><legend>影响因子排序</legend><div class="scansci-filter-options">
        <label><input type="radio" form="scansci-filter-isolated" name="scansci-sort" value="original" checked><span>默认</span></label>
        <label><input type="radio" form="scansci-filter-isolated" name="scansci-sort" value="impact-asc"><span>升序</span></label>
        <label><input type="radio" form="scansci-filter-isolated" name="scansci-sort" value="impact-desc"><span>降序</span></label>
      </div></fieldset>
      <fieldset class="scansci-filter-year" hidden><legend>发表年份排序</legend><div class="scansci-filter-options">
        <label><input type="radio" form="scansci-filter-isolated" name="scansci-sort" value="year-asc"><span>升序</span></label>
        <label><input type="radio" form="scansci-filter-isolated" name="scansci-sort" value="year-desc"><span>降序</span></label>
      </div></fieldset>
      <fieldset class="scansci-filter-cited" hidden><legend>被引次数排序</legend><div class="scansci-filter-options">
        <label><input type="radio" form="scansci-filter-isolated" name="scansci-sort" value="cited-asc"><span>升序</span></label>
        <label><input type="radio" form="scansci-filter-isolated" name="scansci-sort" value="cited-desc"><span>降序</span></label>
      </div></fieldset>
      <fieldset class="scansci-filter-jcr"><legend>JCR 分区</legend><div class="scansci-filter-options">
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="jcr" value="q1"><span>Q1</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="jcr" value="q2"><span>Q2</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="jcr" value="q3"><span>Q3</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="jcr" value="q4"><span>Q4</span></label>
      </div></fieldset>
      <fieldset class="scansci-filter-xinrui"><legend>新锐分区</legend><div class="scansci-filter-options">
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="xinrui" value="xr1"><span>1区</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="xinrui" value="xr2"><span>2区</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="xinrui" value="xr3"><span>3区</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="xinrui" value="xr4"><span>4区</span></label>
      </div></fieldset>
      <fieldset class="scansci-filter-cas"><legend>中科院分区</legend><div class="scansci-filter-options">
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="cas" value="cas1"><span>1区</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="cas" value="cas2"><span>2区</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="cas" value="cas3"><span>3区</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="cas" value="cas4"><span>4区</span></label>
      </div></fieldset>
      <fieldset><legend>中文核心与收录</legend><div class="scansci-filter-options">
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="index" value="pku"><span>北大核心</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="index" value="cscd"><span>CSCD</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="index" value="scd"><span>SCD</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="index" value="cssci"><span>CSSCI</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="index" value="ei"><span>EI</span></label>
      </div></fieldset>
      <fieldset><legend>其他条件</legend><div class="scansci-filter-options">
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="special" value="top"><span>中科院 Top</span></label>
        <label><input type="checkbox" form="scansci-filter-isolated" data-group="special" value="warning"><span>期刊预警</span></label>
      </div></fieldset>
      <label class="scansci-filter-min">最低 IF <input class="scansci-filter-if" form="scansci-filter-isolated" type="number" min="0" step="0.1" placeholder="不限"></label>
      <label class="scansci-filter-min">最低 IF5 <input class="scansci-filter-if5" form="scansci-filter-isolated" type="number" min="0" step="0.1" placeholder="不限"></label>
      <div class="scansci-filter-footer"><output aria-live="polite"></output><button type="button" class="scansci-filter-reset">清除</button></div>
      <small>仅筛选本页结果；未识别或缺少所选指标的结果不显示。多学科期刊任一分区符合即可。</small></div>`;
    for (const type of ['click', 'input', 'keydown', 'keyup', 'keypress']) panel.addEventListener(type, event => event.stopPropagation());
    panel.addEventListener('change', event => {
      event.stopPropagation();
      const control = event.target;
      if (control.name === 'scansci-sort') {
        if (control.value !== 'original' && !sorting) originals.clear();
        else if (control.value === 'original' && sorting) { sortCards('original'); originals.clear(); }
        sorting = control.value === 'original' ? false : control.value;
      }
      apply();
    });
    panel.querySelector('.scansci-filter-reset').addEventListener('click', () => {
      if (sorting) sortCards('original');
      originals.clear();
      sorting = false;
      panel.querySelectorAll('[data-group]').forEach(input => { input.checked = false; });
      panel.querySelector('[name="scansci-sort"][value="original"]').checked = true;
      panel.querySelector('.scansci-filter-if').value = '';
      if (panel.querySelector('.scansci-filter-if5')) panel.querySelector('.scansci-filter-if5').value = '';
      apply();
    });
  }

  function passes(row, condition, minimum) {
    if (Array.isArray(row?.consensusRows)) {
      const labels = globalThis.ScanSciCore.badges(row, { ...globalThis.ScanSciCore.defaults, ccf: true }).map(badge => badge.text);
      const value = prefix => labels.find(label => label.startsWith(prefix))?.slice(prefix.length) || '';
      const impact = value('IF ').split(' · ')[0];
      row = {
        if_2023: impact && Number.isFinite(Number(impact)) ? Number(impact) : null,
        jcr_quartile: labels.filter(label => /^JCR Q[1-4]$/.test(label)).map(label => label.slice(4)).join(' '),
        cas_2025: labels.find(label => /^中科院 [1-4]\s*区/.test(label))?.slice('中科院 '.length) || '', xuankan_2026: value('新锐 '),
        is_top: labels.includes('中科院 Top'), pku_core: labels.includes('北大核心'),
        cscd_type: value('CSCD '), cssci_type: value('CSSCI '),
        warning_latest: labels.includes('中科院预警') ? '已标记' : '',
        xuankan_warning: labels.includes('新锐预警'), tags: labels,
      };
    }
    const tags = Array.isArray(row?.tags) ? row.tags : [];
    const confirmed = {
      top: row?.is_top === true || tags.includes('中科院Top'),
      warning: !!(row?.warning_latest || row?.xuankan_warning || tags.includes('期刊预警') || tags.includes('新锐预警')),
      pku: row?.pku_core === true || tags.includes('北大核心'),
      cscd: !!row?.cscd_type || tags.some(value => /^CSCD(?:-|\(|$)/i.test(String(value))),
      scd: tags.some(value => /^SCD(?:-\d{4})?$/i.test(String(value))),
      cssci: !!row?.cssci_type || tags.some(value => /^CSSCI(?:\(|扩展|$)/i.test(String(value))),
      ei: row?.ei_indexed === true || tags.some(value => /^EI$/i.test(String(value))),
    };
    if (Object.hasOwn(confirmed, condition)) return confirmed[condition] && passes(row, 'all', minimum);
    if (!row) return condition === 'all' && minimum === null;
    const quartile = row.jcr_quartile || tags.filter(value => /^Q[1-4]$/i.test(String(value))).join(' ');
    const cas = row.cas_2025 || tags.find(value => /^[1-4]区$/.test(String(value)));
    const xinrui = row.xuankan_2026 || String(tags.find(value => /^新锐[1-4]区$/.test(String(value))) || '').replace(/^新锐/, '');
    if (/^q[1-4]$/.test(condition) && !(String(quartile || '').toUpperCase().match(/\bQ[1-4]\b/g) || []).includes(condition.toUpperCase())) return false;
    if (/^cas[1-4]$/.test(condition) && !String(cas || '').replace(/\s+/g, '').startsWith(`${condition.slice(-1)}区`)) return false;
    if (/^xr[1-4]$/.test(condition) && !String(xinrui || '').replace(/\s+/g, '').startsWith(`${condition.slice(-1)}区`)) return false;
    const value = row.if_2023;
    if (minimum !== null && (value === null || value === '' || value === undefined || !Number.isFinite(Number(value)) || Number(value) < minimum)) return false;
    return true;
  }

  function passesIf5(row, minimum) {
    if (minimum === null) return true;
    if (!row) return false;
    if (row.consensusRows) {
      const label = globalThis.ScanSciCore.badges(row).find(badge => badge.key === 'if5')?.text;
      if (!label) return false;
      row = label === 'IF5 <0.1' ? { if5_display: '<0.1' } : { if5: Number(label.slice(4)) };
    }
    if (row.if5_display === '<0.1') return minimum === 0;
    if (row.if5 === null || row.if5 === undefined || row.if5 === '') return false;
    return Number.isFinite(Number(row.if5)) && Number(row.if5) >= minimum;
  }

  function articleMetric(card, metric) {
    const host = location.hostname;
    let text = '';
    if (metric === 'cited') {
      if (host === 'kns.cnki.net') text = card.querySelector('td.quote')?.textContent || '';
      else if (host.startsWith('scholar.google.')) text = card.querySelector('.gs_fl a[href*="cites="], .gsc_a_c .gsc_a_ac')?.textContent || '';
      const value = text.match(/\d[\d,]*/)?.[0];
      return value ? Number(value.replace(/,/g, '')) : null;
    }
    if (host === 'kns.cnki.net') text = card.querySelector('td.date')?.textContent || '';
    else if (host.startsWith('scholar.google.')) text = card.querySelector('.gsc_a_y')?.textContent || (card.querySelector('.gs_a')?.textContent || '').split(/\s+[-–—]\s+/)[1] || '';
    else if (host === 'pmc.ncbi.nlm.nih.gov') text = card.querySelector('.citation-part:not(.pmcid)')?.textContent || '';
    else if (host === 'pubmed.ncbi.nlm.nih.gov') text = card.querySelector('.docsum-journal-citation')?.textContent || '';
    const value = text.split(/\bdoi\s*:/i)[0].match(/\b(?:18|19|20)\d{2}\b/)?.[0];
    return value ? Number(value) : null;
  }

  function sortCards(mode) {
    const groups = new Map();
    for (const card of entries.keys()) {
      if (!card.isConnected || !card.parentElement) continue;
      const group = groups.get(card.parentElement) || [];
      group.push(card);
      groups.set(card.parentElement, group);
    }
    for (const [parent, cards] of groups) {
      if (cards.length < 2) continue;
      const current = [...parent.children].filter(card => entries.has(card));
      if (mode === 'original' && !originals.has(parent)) continue;
      const original = (originals.get(parent) || current.slice()).filter(card => card.parentElement === parent);
      for (let index = 0; index < current.length;) {
        if (original.includes(current[index])) { index += 1; continue; }
        const added = [];
        while (index < current.length && !original.includes(current[index])) added.push(current[index++]);
        if (index === added.length) original.unshift(...added);
        else if (index === current.length) original.push(...added);
        else original.splice(original.indexOf(current[index]), 0, ...added);
      }
      originals.set(parent, original);
      const ordered = current.slice().sort((a, b) => {
        if (mode !== 'original') {
          const impact = card => {
            const row = entries.get(card)?.row;
            const label = row?.consensusRows && globalThis.ScanSciCore.badges(row).find(badge => badge.key === 'impact')?.text;
            const value = row?.consensusRows ? label?.slice(3).split(' · ')[0] : row?.if_2023;
            return value === null || value === '' || value === undefined || !Number.isFinite(Number(value)) ? null : Number(value);
          };
          const metric = mode.split('-')[0];
          const value = card => metric === 'impact' ? impact(card) : articleMetric(card, metric);
          const av = value(a), bv = value(b);
          if (av === null && bv !== null) return 1;
          if (bv === null && av !== null) return -1;
          if (av !== null && bv !== null && av !== bv) return mode.endsWith('-asc') ? av - bv : bv - av;
        }
        return original.indexOf(a) - original.indexOf(b);
      });
      if (ordered.every((card, index) => card === current[index])) continue;
      const markers = current.map(card => { const marker = document.createComment('ScanSci'); parent.insertBefore(marker, card); return marker; });
      ordered.forEach((card, index) => parent.insertBefore(card, markers[index]));
      markers.forEach(marker => marker.remove());
    }
  }

  function apply() {
    if (!panel) return;
    const parents = new Set();
    const sortable = [...entries.keys()].some(card => {
      if (!card.isConnected || !card.parentElement) return false;
      if (parents.has(card.parentElement)) return true;
      parents.add(card.parentElement);
      return false;
    });
    panel.querySelector('.scansci-filter-impact').hidden = !sortable;
    if (!sortable && sorting) {
      sortCards('original');
      originals.clear();
      sorting = false;
      panel.querySelector('[name="scansci-sort"][value="original"]').checked = true;
    }
    for (const metric of ['year', 'cited']) {
      const available = sortable && [...entries.keys()].some(card => card.isConnected && articleMetric(card, metric) !== null);
      panel.querySelector(`.scansci-filter-${metric}`).hidden = !available;
      if (!available && sorting && sorting.startsWith(`${metric}-`)) {
        sortCards('original');
        originals.clear();
        sorting = false;
        panel.querySelector('[name="scansci-sort"][value="original"]').checked = true;
      }
    }
    const groups = new Map();
    panel.querySelectorAll('[data-group]:checked').forEach(input => {
      const values = groups.get(input.dataset.group) || [];
      values.push(input.value);
      groups.set(input.dataset.group, values);
    });
    const input = panel.querySelector('.scansci-filter-if').value;
    const minimum = input !== '' && Number.isFinite(Number(input)) && Number(input) >= 0 ? Number(input) : null;
    const if5Input = panel.querySelector('.scansci-filter-if5')?.value || '';
    const minimumIf5 = if5Input !== '' && Number.isFinite(Number(if5Input)) && Number(if5Input) >= 0 ? Number(if5Input) : null;
    let hidden = 0;
    for (const [card, entry] of entries) {
      if (!card.isConnected) { card.classList.remove('scansci-result-filtered'); entries.delete(card); continue; }
      if (entry.isCurrent && !entry.isCurrent()) {
        entry.signature = null;
        entry.row = null;
        entry.isCurrent = null;
      }
      const hide = !passesIf5(entry.row, minimumIf5) || !passes(entry.row, 'all', minimum) || [...groups.values()].some(values => !values.some(value => passes(entry.row, value, null)));
      card.classList.toggle('scansci-result-filtered', hide);
      if (hide) hidden += 1;
    }
    const output = panel.querySelector('output');
    if (output.textContent !== `已隐藏 ${hidden} 条`) output.textContent = `已隐藏 ${hidden} 条`;
    if (sorting) sortCards(sorting);
  }

  function clear() {
    if (panel && sorting) sortCards('original');
    for (const card of entries.keys()) card.classList.remove('scansci-result-filtered');
    entries.clear();
    originals.clear();
    sorting = false;
    panel?.remove();
    panel = null;
  }

  function refresh() {
    let changed = false;
    for (const [card, entry] of entries) {
      if (!card.isConnected) { card.classList.remove('scansci-result-filtered'); entries.delete(card); changed = true; }
      else {
        const metrics = [articleMetric(card, 'year'), articleMetric(card, 'cited')];
        if (metrics.some((value, index) => value !== entry.metrics[index])) { entry.metrics = metrics; changed = true; }
        if (entry.isCurrent && !entry.isCurrent()) {
          entry.signature = null;
          entry.row = null;
          entry.isCurrent = null;
          changed = true;
        }
      }
    }
    if (panel) {
      mountPanel();
      if (changed) apply();
      else if (sorting) sortCards(sorting);
    }
  }

  globalThis.ScanSciResults = { track, record, clear, refresh };
})();
