(() => {
  const api=globalThis.chrome||globalThis.browser, core=globalThis.JournalScoutCatalogs;
  const BASE='https://www.scansci.com/api/journal-catalogs';
  let checking;
  const store=(method,value)=>new Promise((resolve,reject)=>api.storage.local[method](value,result=>api.runtime.lastError ? reject(new Error(api.runtime.lastError.message)) : resolve(result)));
  async function get(path) {
    const controller=new AbortController(), timer=setTimeout(()=>controller.abort(),12000);
    try {const r=await fetch(BASE+path,{credentials:'omit',signal:controller.signal}); if(!r.ok) throw new Error('目录暂不可用'); return await r.json();} finally {clearTimeout(timer);}
  }
  async function check() {
    const current=await store('get',{customCatalogs:[],catalogNextCheck:0});
    if(!current.customCatalogs.some(p=>p.updateMode!=='manual') || current.catalogNextCheck>Date.now()) return;
    await store('set',{catalogNextCheck:Date.now()+3600000});
    const updates=new Map();
    for(const old of current.customCatalogs) {
      if(old.updateMode==='manual') continue;
      try {
        const data=await get('/'+old.id); const latest=data.catalog;
        if(latest.version===old.version) continue;
        const result=await get(`/${old.id}/versions/${latest.version}`); const pack=core.pack(result.pack);
        if(pack.id!==old.id || pack.version!==latest.version) throw new Error('目录标识不一致');
        updates.set(old.id,{previous:old.version,pack});
      } catch { /* Keep the last validated local package while offline. */ }
    }
    const latest=await store('get',{customCatalogs:[]});
    await store('set',{customCatalogs:latest.customCatalogs.map(pack=>pack.updateMode!=='manual' && updates.get(pack.id)?.previous===pack.version ? updates.get(pack.id).pack : pack),catalogNextCheck:Date.now()+(24+Math.random()*12)*3600000});
  }
  api.runtime.onMessage.addListener((message,sender,respond)=>{
    if(sender.id!==api.runtime.id) return false;
    if(message?.type==='catalogs.check') {
      if(!checking) checking=check().finally(()=>{checking=null;});
      checking.then(()=>respond({ok:true}),()=>respond({ok:false})); return true;
    }
    if(message?.type!=='catalogs.set' || sender.url?.split(/[?#]/)[0]!=='https://journal.scansci.com/catalogs.html') return false;
    (async()=>{
      core.createIndex(message.packs);
      if(JSON.stringify(message.packs).length>4000000) throw new Error('启用的目录合计过大，请减少目录数量。');
      await store('set',{customCatalogs:message.packs.map(core.pack),catalogNextCheck:0});
    })().then(()=>respond({ok:true}),error=>respond({ok:false,error:error.message||'保存失败，请重试。'}));
    return true;
  });
  checking=check().catch(()=>{}).finally(()=>{checking=null;});
})();
