(() => {
  const api = globalThis.chrome || globalThis.browser;
  const core = globalThis.ScanSciCore;
  const contentScripts = ['core.js', 'results.js', 'content.js', 'translate.js'].map(file => core.extensionPath(file, api.runtime));
  const contentStyles = [core.extensionPath('content.css', api.runtime)];
  const enabled = document.getElementById('enabled');
  const version = api.runtime.getManifest?.().version;
  if (version) document.getElementById('version').textContent = `\u7248\u672c ${version}`;
  api.storage.local.get({ enabled: core.defaults.enabled }, values => {
    enabled.checked = Boolean(values.enabled);
    enabled.disabled = false;
  });
  enabled.addEventListener('change', () => api.storage.local.set({ enabled: enabled.checked }));
  const styles = [...document.querySelectorAll('input[name="badgeStyle"]')];
  const styleStatus = document.getElementById('styleStatus');
  let badgeStyle = 'a', badgeColors = null, styleReady = false;
  const initialStyleChanges = {};
  const normalizeStyle = value => ['a', 'b', 'c', 'custom'].includes(value) ? value : 'a';
  function renderStyle() {
    for (const input of styles) input.checked = input.value === badgeStyle;
  }
  api.storage.local.get({ badgeStyle: 'a', badgeColors: null }, values => {
    const latest = { ...values, ...initialStyleChanges };
    badgeStyle = normalizeStyle(latest.badgeStyle);
    badgeColors = latest.badgeColors;
    styleReady = true;
    for (const input of styles) input.disabled = false;
    renderStyle();
  });
  for (const input of styles) input.addEventListener('change', () => {
    if (!input.checked) return;
    const next = normalizeStyle(input.value);
    styleStatus.textContent = '';
    if (next === 'custom' && !badgeColors) {
      const base = ['b', 'c'].includes(badgeStyle) ? badgeStyle : 'a';
      badgeColors = Object.fromEntries(Object.entries(core.badgePalette(base)).map(([kind, color]) => [kind, { fg: color.fg, bg: color.bg }]));
      api.runtime.sendMessage({ type: 'badgeColors', action: 'init', base }, response => {
        if (api.runtime.lastError || !response?.ok) styleStatus.textContent = '保存失败，请重试。';
      });
    }
    badgeStyle = next;
    api.storage.local.set({ badgeStyle }, () => { if (api.runtime.lastError) styleStatus.textContent = '保存失败，请重试。'; });
    renderStyle();
  });
  const library = document.getElementById('legacyLibrary');
  const showLegacyLibrary = papers => { library.hidden = !Array.isArray(papers) || !papers.length; };
  api.storage.local.get({ savedPapers: [] }, values => showLegacyLibrary(values.savedPapers));
  api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.enabled) enabled.checked = changes.enabled.newValue ?? core.defaults.enabled;
    if (changes.savedPapers) showLegacyLibrary(changes.savedPapers.newValue);
    if (changes.badgeStyle) {
      if (!styleReady) initialStyleChanges.badgeStyle = changes.badgeStyle.newValue;
      badgeStyle = normalizeStyle(changes.badgeStyle.newValue); renderStyle();
    }
    if (changes.badgeColors) {
      if (!styleReady) initialStyleChanges.badgeColors = changes.badgeColors.newValue;
      badgeColors = changes.badgeColors.newValue;
    }
  });

  const enable = document.getElementById('enableSite');
  const disable = document.getElementById('disableSite');
  const status = document.getElementById('siteStatus');
  let tab, pattern, id;
  const call = (object, method, value) => new Promise((resolve, reject) => object[method](value, result => {
    if (api.runtime.lastError) reject(new Error(api.runtime.lastError.message));
    else resolve(result);
  }));
  const saveExtraSite = async action => {
    const response = await call(api.runtime, 'sendMessage', { type: 'extraSite', action, pattern });
    if (!response?.ok) throw new Error('Unable to save site');
  };

  async function checkSite() {
    try {
      const registered = await call(api.scripting, 'getRegisteredContentScripts', { ids: [id, 'scansci_all_https'] });
      const allSites = registered.some(script => script.id === 'scansci_all_https') &&
        await call(api.permissions, 'contains', { origins: ['https://*/*'] });
      disable.hidden = allSites || !registered.some(script => script.id === id);
      enable.disabled = allSites;
      status.textContent = allSites ? '已在设置中开启全部 HTTPS 网站识别。' : registered.some(script => script.id === id) ? '已为当前网站开启额外适配。' : '仅在网站提供论文元数据时显示信息。';
    } catch { status.textContent = '无法读取网站授权状态。'; }
  }

  api.tabs.query({ active: true, currentWindow: true }, tabs => {
    tab = tabs?.[0];
    try {
      const url = new URL(tab?.url || '');
      if (url.protocol !== 'https:') throw new Error('unsupported');
      pattern = `https://${url.hostname}/*`;
      id = `scansci_${[...new TextEncoder().encode(url.hostname)].map(value => value.toString(16).padStart(2, '0')).join('')}`;
      void checkSite();
    } catch { status.textContent = '请先打开需要适配的 HTTPS 网站。'; }
  });

  enable.addEventListener('click', () => {
    if (!tab || !pattern || !id) return;
    api.permissions.request({ origins: [pattern] }, granted => {
      if (!granted || api.runtime.lastError) { status.textContent = '未获得此网站的访问授权。'; return; }
      void (async () => {
        try {
          const registered = await call(api.scripting, 'getRegisteredContentScripts', { ids: [id] });
          if (!registered.length) await call(api.scripting, 'registerContentScripts', [{
            id, matches: [pattern], js: contentScripts, css: contentStyles,
            runAt: 'document_end', persistAcrossSessions: true,
          }]);
          await saveExtraSite('add');
          disable.hidden = false;
          const current = await call(api.tabs, 'get', tab.id);
          if (new URL(current.url).hostname !== new URL(tab.url).hostname || new URL(current.url).protocol !== 'https:') {
            status.textContent = '已授权原网站，请返回该网站并刷新。'; return;
          }
          await call(api.scripting, 'insertCSS', { target: { tabId: tab.id }, files: contentStyles });
          await call(api.scripting, 'executeScript', { target: { tabId: tab.id }, files: contentScripts });
          status.textContent = '已开启。含标准论文元数据的页面会显示信息。';
        } catch { status.textContent = '已尝试授权；请刷新网站，或检查浏览器扩展权限。'; }
      })();
    });
  });

  disable.addEventListener('click', () => {
    if (!pattern || !id) return;
    void (async () => {
      try {
        await call(api.scripting, 'unregisterContentScripts', { ids: [id] });
        await call(api.permissions, 'remove', { origins: [pattern] });
        await saveExtraSite('remove');
        disable.hidden = true;
        status.textContent = '已停用额外适配；刷新网页后生效。内置网站仍会识别。';
      } catch { status.textContent = '停用失败，请在浏览器扩展权限设置中检查。'; }
    })();
  });
})();
