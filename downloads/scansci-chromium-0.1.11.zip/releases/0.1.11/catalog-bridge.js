(() => {
  const api=globalThis.chrome||globalThis.browser;
  const post=value=>window.postMessage(value,location.origin);
  const ready=()=>api.storage.local.get({customCatalogs:[]},values=>{
    if(!api.runtime.lastError) post({type:'journal-scout:catalogs:ready',packs:values.customCatalogs});
  });
  window.addEventListener('message',event=>{
    if(event.source!==window || event.origin!==location.origin) return;
    if(event.data?.type==='journal-scout:catalogs:hello') ready();
    if(event.data?.type==='journal-scout:catalogs:set') api.runtime.sendMessage({type:'catalogs.set',packs:event.data.packs},result=>{
      const error=api.runtime.lastError?.message || (!result?.ok ? result?.error||'插件保存失败，请重试。' : '');
      post({type:'journal-scout:catalogs:saved',error});
    });
  });
  api.storage.onChanged.addListener((changes,area)=>{if(area==='local' && changes.customCatalogs) ready();});
  ready();
})();
