(() => {
  const core = globalThis.ScanSciCore;
  const origin = 'https://reader.scansci.com';
  const businessKeys = new Set(['ft50', 'ajg', 'utd24', 'fms', 'abdc']);
  if (location.origin !== origin || !core) return;

  window.addEventListener('message', event => {
    const request = event.data;
    if (event.source !== window || event.origin !== origin || request?.source !== 'scansci-reader' ||
        request.type !== 'business-request' || typeof request.id !== 'string' || request.id.length > 80 ||
        !Array.isArray(request.items) || request.items.length > 40) return;
    const items = request.items.flatMap(item => {
      if (!Number.isSafeInteger(item?.index) || item.index < 0 || typeof item.title !== 'string' ||
          item.title.length > 250 || !Array.isArray(item.issns) || item.issns.length > 2 ||
          item.issns.some(issn => typeof issn !== 'string' || !core.validIssn(issn)) ||
          (!item.title && !item.issns.length)) return [];
      const row = { title: item.title, issn: item.issns[0] || '', eissn: item.issns[1] || '' };
      const badges = core.badges(row).filter(badge => businessKeys.has(badge.key))
        .map(({ key, text, title }) => ({ key, text, title }));
      return [{ index: item.index, badges }];
    });
    window.postMessage({ source: 'journal-scout-extension', type: 'business-response', id: request.id, items }, origin);
  });
  window.postMessage({ source: 'journal-scout-extension', type: 'ready', hasBusinessData: core.businessRankingCount() > 0 }, origin);
})();
