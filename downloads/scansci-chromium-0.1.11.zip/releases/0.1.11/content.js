(() => {
  if (globalThis.ScanSciContentLoaded) return;
  globalThis.ScanSciContentLoaded = true;
  const api = globalThis.chrome || globalThis.browser;
  const core = globalThis.ScanSciCore;
  const results = globalThis.ScanSciResults || { track() {}, record() {}, clear() {}, refresh() {} };
  let settings = { ...core.defaults };
  let badgeStyle = 'a';
  let badgeColors = null;
  let badgeLevelColors = null;
  let palette = core.badgePalette(badgeStyle, badgeColors);
  let layout = core.badgeLayout();
  let ready = false;
  let seen = new WeakMap();
  let mounted = new WeakMap();
  let retried = new WeakMap();
  const retryTargets = new Map();
  const schemas = new WeakMap();
  let generation = 0;
  let timer;
  let retryTimer;
  let badgeInfo;
  const wileyRoots = new Map();
  let wileyDiscoveryTimer;
  let wileyDiscoveryAttempts = 0;
  const touchBadges = globalThis.matchMedia?.('(hover: none)').matches === true;

  function badgeNodes(selector) {
    return [...document.querySelectorAll(selector), ...[...wileyRoots.keys()].flatMap(root => [...root.querySelectorAll(selector)])];
  }

  function showBadgeInfo(tag) {
    badgeInfo?.remove();
    badgeInfo = document.createElement('div');
    badgeInfo.className = 'scansci-badge-info';
    badgeInfo.setAttribute('role', 'dialog');
    badgeInfo.setAttribute('aria-label', `${tag.textContent} 说明`);
    const heading = document.createElement('div'); heading.className = 'scansci-badge-info__heading';
    const label = document.createElement('strong'); label.textContent = tag.textContent;
    const close = document.createElement('button'); close.type = 'button'; close.textContent = '×';
    close.setAttribute('aria-label', '关闭标签说明');
    close.addEventListener('click', () => { badgeInfo?.remove(); badgeInfo = null; });
    heading.append(label, close);
    const text = document.createElement('div'); text.className = 'scansci-badge-info__text'; text.textContent = tag.title;
    badgeInfo.append(heading, text);
    document.documentElement.append(badgeInfo);
  }

  function paintBadge(tag) {
    const colors = core.badgeColor(palette, badgeStyle, badgeLevelColors, tag.scansciBadgeKind, tag.scansciBadgeLevel);
    if (!colors) return;
    tag.style.setProperty('color', colors.fg, 'important');
    tag.style.setProperty('background-color', colors.bg, 'important');
    tag.style.setProperty('border-color', colors.border, 'important');
    tag.style.setProperty('font-size', `${layout.fontSize}px`, 'important');
    tag.style.setProperty('border-radius', `${layout.radius}px`, 'important');
    tag.style.setProperty('padding', `${layout.paddingY}px ${layout.paddingX}px`, 'important');
  }

  function paintContainer(container, logo) {
    container.style.setProperty('gap', `${layout.gap}px`, 'important');
    if (logo) logo.style.setProperty('display', layout.showLogo && container.scansciBadges?.length ? 'inline-flex' : 'none', 'important');
  }

  function send(message) {
    return new Promise(resolve => {
      try { api.runtime.sendMessage(message, response => {
        if (api.runtime.lastError) { console.warn('ScanSci communication failed:', api.runtime.lastError.message); resolve(null); }
        else resolve(response);
      }); }
      catch { resolve(null); }
    });
  }

  function renderBadges(container, row) {
    for (const tag of container.scansciBadges || []) tag.remove();
    container.scansciBadges = [];
    const values = core.badges(row, settings);
    const nativeVisible = [...container.children].some(isNativeMarker);
    container.hidden = !values.length && !nativeVisible;
    container.style.setProperty('display', container.hidden ? 'none' : 'flex', 'important');
    for (const badge of values) {
      const tag = document.createElement('span');
      tag.className = `scansci-journal-badge scansci-journal-badge--${badge.kind}`;
      tag.scansciBadgeKind = badge.kind;
      tag.scansciBadgeLevel = badge.colorLevel;
      tag.textContent = badge.text;
      tag.title = badge.title;
      tag.setAttribute('aria-label', `${badge.text}。${badge.title}`);
      if (touchBadges) {
        tag.setAttribute('role', 'button');
        tag.setAttribute('tabindex', '0');
        tag.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); showBadgeInfo(tag); });
        tag.addEventListener('keydown', event => {
          if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); event.stopPropagation(); showBadgeInfo(tag); }
        });
      }
      paintBadge(tag);
      container.scansciBadges.push(tag);
      container.append(tag);
    }
    paintContainer(container, container.scansciLogo);
  }

  function isNativeMarker(node) {
    return node.matches?.('b.marktip') && node.textContent.trim() === '网络首发';
  }

  function removeBadge(container) {
    if (!container) return;
    const native = container.scansciNative;
    if (native || (location.hostname === 'kns.cnki.net' && container.parentElement?.matches('td.name'))) {
      const marker = [...container.children].find(isNativeMarker);
      const next = container.nextSibling;
      const placeholder = native?.placeholder || (next?.nodeType === 8 && next.data === 'Journal Scout' ? next : null);
      if (marker && placeholder?.parentNode) placeholder.parentNode.replaceChild(marker, placeholder);
      else if (marker && container.parentNode) container.parentNode.insertBefore(marker, next);
      else placeholder?.remove();
      delete container.scansciNative;
    }
    container.remove();
  }

  function groupNativeMarker(container, target) {
    const cell = target.closest?.('td.name');
    if (location.hostname !== 'kns.cnki.net' || !cell || container.parentElement !== cell) return false;
    const current = [...container.children].find(isNativeMarker);
    if (current) {
      if (container.scansciNative?.marker === current) return false;
      if (container.scansciNative) container.scansciNative.marker = current;
      return true;
    }
    if (container.scansciNative) {
      container.scansciNative.placeholder.remove();
      delete container.scansciNative;
    }
    const marker = [...cell.children].find(isNativeMarker);
    if (!marker) return false;
    const placeholder = document.createComment('Journal Scout');
    marker.before(placeholder);
    container.scansciNative = { marker, placeholder };
    container.insertBefore(marker, container.scansciLogo.nextSibling);
    return true;
  }

  function show(target, row, current, signature, isCurrent, card) {
    if (!row || generation !== current || !settings.enabled || !target.isConnected || seen.get(target) !== signature || !isCurrent()) return;
    const previous = mounted.get(target);
    if (previous && previous === existingBadge(target)) return;
    removeBadge(previous);
    const old = existingBadge(target);
    if (old?.classList.contains('scansci-journal-badges')) removeBadge(old);
    if (settings.filter) results.record(card, signature, row, isCurrent);
    const hasJournalLink = Number.isSafeInteger(row.id) && row.id > 0;
    if (!row.ambiguous && !hasJournalLink && !row.localRankingOnly) return;
    const container = document.createElement('span');
    container.className = 'scansci-journal-badges';
    if ((location.hostname === 'pubpeer.com' || location.hostname.endsWith('.pubpeer.com')) && target.matches('h3')) {
      container.classList.add('scansci-pubpeer-card-badges');
    }
    container.scansciIsCurrent = () => target.isConnected && seen.get(target) === signature && isCurrent();
    container.scansciRow = row;
    container.setAttribute('aria-label', 'Journal Scout 期刊信息');
    const link = document.createElement(hasJournalLink && !row.ambiguous ? 'a' : 'span');
    if (hasJournalLink && !row.ambiguous) {
      link.href = `https://journal.scansci.com/journal.html?id=${row.id}`;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
    }
    link.className = 'scansci-journal-link';
    link.title = row.ambiguous ? `${row.title} · 存在同名记录，仅展示共同信息` : row.localRankingOnly ? `${row.title} · 本地期刊名单` : `${row.title} · 查看 Journal Scout 详情`;
    link.setAttribute('aria-label', link.title);
    const logo = document.createElement('img');
    logo.src = api.runtime.getURL(core.extensionPath('journal-scout-logo.png', api.runtime));
    logo.alt = '';
    link.append(logo);
    container.scansciLogo = link;
    container.append(link);
    if (target.tagName === 'TD' || target.tagName === 'DT') target.append(container);
    else (core.adjacentCompanion(target, 'scansci-title-translation') || target).insertAdjacentElement('afterend', container);
    groupNativeMarker(container, target);
    renderBadges(container, row);
    mounted.set(target, container);
  }

  function existingBadge(target) {
    return target.tagName === 'TD' || target.tagName === 'DT' ? target.querySelector(':scope > .scansci-journal-badges') : core.adjacentCompanion(target, 'scansci-journal-badges');
  }

  function mark(target, signature) {
    if (!target) return false;
    const previous = mounted.get(target);
    if (seen.get(target) === signature && (!previous || previous === existingBadge(target))) {
      if (previous && groupNativeMarker(previous, target)) renderBadges(previous, previous.scansciRow);
      return false;
    }
    removeBadge(previous);
    mounted.delete(target);
    const old = existingBadge(target);
    if (old?.classList.contains('scansci-journal-badges')) removeBadge(old);
    if (retried.get(target) !== signature) retried.delete(target);
    seen.set(target, signature);
    return true;
  }

  function clear(target) {
    if (!target) return;
    removeBadge(mounted.get(target));
    mounted.delete(target);
    const old = existingBadge(target);
    if (old?.classList.contains('scansci-journal-badges')) removeBadge(old);
    seen.delete(target);
    retried.delete(target);
  }

  function retry(target, signature, current) {
    if (current !== generation || seen.get(target) !== signature || retried.get(target) === signature) return;
    retried.set(target, signature);
    retryTargets.set(target, signature);
    if (!retryTimer) retryTimer = setTimeout(() => {
      retryTimer = undefined;
      for (const [node, value] of retryTargets) if (seen.get(node) === value) seen.delete(node);
      retryTargets.clear();
      scan();
    }, 4000);
  }

  async function annotate(target, hint, readHint, card) {
    const signature = JSON.stringify(hint);
    const renewed = results.track(card, signature);
    if (renewed && seen.get(target) === signature) seen.delete(target);
    if (!mark(target, signature)) return;
    const current = generation;
    const response = await send({ type: 'lookup', ...hint, details: settings.ccf || settings.badgeHistory });
    const isCurrent = () => JSON.stringify(readHint()) === signature;
    if (response?.ok) show(target, response.data || core.localBusinessJournal(hint), current, signature, isCurrent, card);
    else retry(target, signature, current);
  }

  function meta(name) {
    return [...document.querySelectorAll(`meta[name="${name}" i]`)].map(node => node.content.trim()).filter(Boolean);
  }

  function schemaHint(identity) {
    const hints = new Map();
    for (const node of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0, 8)) {
      const text = node.textContent || '';
      if (text.length > 100000) continue;
      let cached = schemas.get(node);
      if (!cached || cached.text !== text) {
        let data = null;
        try { data = JSON.parse(text); } catch { /* Invalid metadata is ignored. */ }
        cached = { text, data };
        schemas.set(node, cached);
      }
      const hint = cached.data && core.schemaJournal(cached.data, identity);
      if (hint?.ambiguous) return null;
      if (hint) hints.set(JSON.stringify([core.normalizeTitle(hint.title), hint.issns.map(core.normalizeIssn).sort()]), hint);
    }
    return hints.size === 1 ? hints.values().next().value : null;
  }

  function metadataHint() {
    const title = meta('citation_journal_title')[0] || meta('bepress_citation_journal_title')[0] || meta('prism.publicationname')[0] || meta('dc.source')[0] || '';
    let issns = [...new Set([...meta('citation_issn'), ...meta('citation_eissn'), ...meta('citation_journal_issn'), ...meta('bepress_citation_issn'), ...meta('prism.issn'), ...meta('prism.eissn')].filter(core.validIssn))];
    const pageDoi = [meta('citation_doi')[0], meta('bepress_citation_doi')[0], meta('prism.doi')[0], ...meta('dc.identifier')].map(core.normalizeDoi).find(Boolean) || '';
    // JCI Insight article pages currently publish the parent journal's ISSN in citation_issn.
    if (location.hostname === 'insight.jci.org') {
      const id = location.pathname.match(/^\/articles\/view\/(\d+)\/?$/i)?.[1];
      if (id && core.normalizeTitle(title) === 'jci insight' && pageDoi.toLowerCase() === `10.1172/jci.insight.${id}`) issns = ['2379-3708'];
      else if (issns.some(value => core.normalizeIssn(value) === '00219738')) return null;
    }
    const doi = settings.doiLookup ? pageDoi : '';
    const repositoryTitle = meta('bepress_citation_title')[0];
    const paperTitle = meta('citation_title')[0] || repositoryTitle || meta('dc.title')[0];
    if (paperTitle && (title || issns.length)) return { title, issns, ...(doi ? { doi } : {}) };
    const schema = schemaHint({ title: paperTitle || core.articleHeading(document)?.textContent, doi: pageDoi });
    if (schema) return { ...schema, ...(doi ? { doi } : {}) };
    if (paperTitle && doi) return { title: '', issns: [], doi };
    if (settings.doiLookup && repositoryTitle && repositoryTitle.length <= 400 &&
        core.normalizeTitle(paperTitle) === core.normalizeTitle(repositoryTitle) &&
        core.normalizeTitle(core.articleHeading(document)?.textContent) === core.normalizeTitle(repositoryTitle)) {
      const articleYear = meta('bepress_citation_date')[0]?.match(/^(?:19|20)\d{2}/)?.[0];
      return { title: '', issns: [], articleTitle: repositoryTitle, ...(articleYear ? { articleYear } : {}) };
    }
    return null;
  }

  function cardDoi(card) {
    if (!settings.doiLookup || !card) return '';
    const anchors = [card.querySelector('a[href^="https://doi.org/"], a[href^="https://dx.doi.org/"]'),
      card.querySelector('.gs_rt a[href], a.gsc_a_at[href]')];
    return anchors.filter(Boolean).map(anchor => core.doiFromUrl(anchor.href, location.href)).find(Boolean) || '';
  }

  // Publisher search results link articles as /doi/10.xxxx/... (sometimes with
  // an abs/full/epdf/reader segment); the DOI is the reliable identity there.
  function linkedDoi(node) {
    const href = node.getAttribute('href') || '';
    const match = href.match(/\/doi\/(?:abs\/|full\/|epdf\/|references\/|reader\/)?(10\.\d{4,9}\/[^?#\s]+)$/i);
    return core.normalizeDoi(match?.[1]);
  }

  function scanMetadata() {
    const heading = core.articleHeading(document);
    if (!heading) return;
    const hint = metadataHint();
    if (hint) void annotate(heading, hint, () => core.articleHeading(document) === heading ? metadataHint() : null);
    else clear(heading);
  }

  function scanCnkiArticle() {
    if (location.hostname !== 'kns.cnki.net' || !/^\/kcms2\/article\/abstract\/?$/i.test(location.pathname)) return false;
    const heading = document.querySelector('.wx-tit > h1');
    if (!heading) return true;
    const readHint = () => {
      if (document.querySelector('.wx-tit > h1') !== heading) return null;
      const resource = document.querySelector('#paramresource')?.value?.trim().toUpperCase();
      if (resource && resource !== 'JOURNAL') return null;
      const source = document.querySelector('.top-tip > span > a:first-child');
      if (!source) return null;
      let url;
      try { url = new URL(source.getAttribute('href'), location.href); } catch { return null; }
      if (!/^https?:$/.test(url.protocol) || url.hostname !== 'navi.cnki.net' || !url.pathname.startsWith('/knavi/')) return null;
      const text = source.textContent.replace(/[《》]/g, '').replace(/\s+/g, ' ').trim();
      const title = text.replace(/\s*[.．。]\s*$/, '').trim();
      return title && title.length <= 120 && !/\.\.\.|…/.test(text) ? { title, issns: [] } : null;
    };
    const hint = readHint();
    if (hint) void annotate(heading, hint, readHint);
    else clear(heading);
    return true;
  }

  function scanIeeePage() {
    if (location.hostname !== 'ieeexplore.ieee.org') return false;
    const article = /^\/document\/\d+\/?$/i.test(location.pathname);
    const journal = /^\/xpl\/RecentIssue\.jsp$/i.test(location.pathname);
    if (!article && !journal) return false;
    const heading = article ? document.querySelector('h1.document-title') : document.querySelector('.title-container h1');
    if (!heading) return true;
    const readHint = () => {
      if (!heading.isConnected || (article ? document.querySelector('h1.document-title') : document.querySelector('.title-container h1')) !== heading) return null;
      const source = article ? document.querySelector('a[data-analytics_identifier="document_abstract_published_in"][href*="/xpl/RecentIssue.jsp"]') : heading;
      const title = source?.textContent.replace(/\s+/g, ' ').trim() || '';
      return title && title.length <= 120 && !/\.\.\.|…/.test(title) ? { title, issns: [] } : null;
    };
    const hint = readHint();
    if (hint) void annotate(heading, hint, readHint);
    else clear(heading);
    return true;
  }

  function journalUrlIssn(value, host) {
    try {
      const url = new URL(value, location.href);
      const researchGateHosts = ['researchgate.net', 'www.researchgate.net'];
      if (url.hostname !== host && !(researchGateHosts.includes(host) && researchGateHosts.includes(url.hostname))) return '';
      const issn = host === 'www.elsevier.com' ? url.pathname.match(/^\/locate\/issn\/+([0-9]{4}-[0-9]{3}[0-9X])\/?$/i)?.[1]
        : url.pathname.match(/^\/journal\/[^/]+-([0-9]{4}-[0-9]{3}[0-9X])\/?$/i)?.[1]
          || url.pathname.match(/^\/journal\/([0-9]{4}-[0-9]{3}[0-9X])_[^/]+\/?$/i)?.[1];
      return core.validIssn(issn) ? issn : '';
    } catch { return ''; }
  }

  function scanJournalFinder() {
    if (location.hostname !== 'journalfinder.elsevier.com') return;
    document.querySelectorAll('article:has(h2[id^="title-"])').forEach(card => {
      const heading = card.querySelector('h2[id^="title-"]');
      const target = heading?.closest('header');
      if (!target) return;
      const readHint = () => {
        if (!card.isConnected || card.querySelector('h2[id^="title-"]') !== heading || heading.closest('header') !== target) return null;
        const title = heading.textContent.replace(/\s+/g, ' ').trim();
        const link = target.querySelector('a[data-aa-name="jf-goto-journal-homepage"]');
        const issn = journalUrlIssn(link?.href, 'www.elsevier.com');
        return title && title.length <= 120 && !/\.\.\.|…/.test(title) ? { title, issns: issn ? [issn] : [] } : null;
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint);
      else clear(target);
    });
  }

  function scanResearchGate() {
    if (location.hostname !== 'www.researchgate.net' && location.hostname !== 'researchgate.net') return false;
    const isHome = location.pathname === '/' || /^\/home(?:\/|$)/i.test(location.pathname);
    if (isHome) {
      document.querySelectorAll('.publication-item-origin-journal').forEach(target => {
        const card = target.closest('.nova-legacy-v-entity-item');
        if (!card) return;
        const readHint = () => {
          if (!target.isConnected || target.closest('.nova-legacy-v-entity-item') !== card) return null;
          const links = [...target.querySelectorAll('a[href]')];
          const journalLinks = links.filter(link => journalUrlIssn(link.href, location.hostname));
          if (journalLinks.length > 1 || (!journalLinks.length && links.length)) return null;
          const titles = target.querySelectorAll('.publication-item-origin-journal__title');
          const source = journalLinks[0] || (titles.length === 1 ? titles[0] : null);
          if (!source) return null;
          const title = source.textContent.replace(/\s+/g, ' ').trim();
          const issn = journalLinks.length ? journalUrlIssn(source.href, location.hostname) : '';
          if (!title || title.length > 120 || /\.\.\.|…/.test(title)) return null;
          return issn ? { title, issns: [issn] } : { title, issns: [], titleVariants: 'and-ampersand' };
        };
        const hint = readHint();
        if (hint) void annotate(target, hint, readHint);
        else clear(target);
      });
    }
    document.querySelectorAll('.nova-legacy-v-publication-item__meta-right a[href]').forEach(source => {
      const readHint = () => {
        if (!source.isConnected || !source.closest('.nova-legacy-v-publication-item__meta-right')) return null;
        const title = source.textContent.replace(/\s+/g, ' ').trim();
        const issn = journalUrlIssn(source.href, location.hostname);
        return title && title.length <= 120 && !/\.\.\.|…/.test(title) && issn ? { title, issns: [issn] } : null;
      };
      const hint = readHint();
      if (hint) void annotate(source, hint, readHint);
      else clear(source);
    });
    if (isHome) return true;
    if (/^\/journal\/[^/]+\/?$/i.test(location.pathname)) {
      const heading = document.querySelector('h1');
      if (!heading) return true;
      // Access-restricted and other error pages keep the journal URL, so the
      // heading must match the journal name encoded in the path before the
      // URL's ISSN may be trusted.
      const slug = location.pathname.replace(/^\/journal\//i, '').replace(/\/+$/, '')
        .replace(/-[0-9]{4}-[0-9]{3}[0-9X]$/i, '').replace(/-/g, ' ');
      const readHint = () => {
        if (document.querySelector('h1') !== heading) return null;
        const title = heading.textContent.replace(/\s+/g, ' ').trim();
        const issn = journalUrlIssn(location.href, location.hostname);
        return title && issn && title.length <= 120 && core.normalizeTitle(title) === core.normalizeTitle(slug)
          ? { title, issns: [issn] } : null;
      };
      const hint = readHint();
      if (hint) void annotate(heading, hint, readHint);
      else clear(heading);
      return true;
    }
    if (/^\/publication\//i.test(location.pathname)) {
      const source = document.querySelector('.research-detail-meta a[href^="journal/"], .research-detail-meta a[href^="/journal/"], .research-detail-meta a[href^="https://www.researchgate.net/journal/"]');
      if (!source) return false;
      const readHint = () => {
        if (!source.isConnected || !source.closest('.research-detail-meta')) return null;
        const title = source.textContent.replace(/\s+/g, ' ').trim();
        const issn = journalUrlIssn(source.href, location.hostname);
        return title && title.length <= 120 && !/\.\.\.|…/.test(title) && issn ? { title, issns: [issn] } : null;
      };
      const hint = readHint();
      if (hint) void annotate(source, hint, readHint);
      else clear(source);
      return true;
    }
    return false;
  }

  function doajIssn(value) {
    try {
      const url = new URL(value, location.href);
      if (!['doaj.org', 'www.doaj.org'].includes(url.hostname) || url.protocol !== 'https:') return '';
      const issn = url.pathname.match(/^\/toc\/([0-9]{4}-[0-9]{3}[0-9X])\/?$/i)?.[1] || '';
      return core.validIssn(issn) ? issn : '';
    } catch { return ''; }
  }

  function scanDoaj() {
    if (!['doaj.org', 'www.doaj.org'].includes(location.hostname)) return false;
    const toc = location.pathname.match(/^\/toc\/([0-9]{4}-[0-9]{3}[0-9X])(?:\/articles)?\/?$/i);
    if (toc) {
      const target = document.querySelector('body.journal-details .page-content > header > h1');
      if (!target) return true;
      const readHint = () => {
        if (!target.isConnected || document.querySelector('body.journal-details .page-content > header > h1') !== target) return null;
        const titleNode = target.querySelector(':scope > span');
        const clone = titleNode?.cloneNode(true);
        clone?.querySelectorAll('[aria-hidden="true"], .journal-details__alt-title').forEach(node => node.remove());
        const title = clone?.textContent.replace(/\s+/g, ' ').trim() || '';
        const current = location.pathname.match(/^\/toc\/([0-9]{4}-[0-9]{3}[0-9X])(?:\/articles)?\/?$/i)?.[1] || '';
        return title && title.length <= 120 && core.validIssn(current) ? { title, issns: [current] } : null;
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint); else clear(target);
      return true;
    }
    document.querySelectorAll('#public-article-search li.search-results__record, #public-journal-search li.search-results__record').forEach(card => {
      const target = card.querySelector('header h3.search-results__heading');
      const source = card.querySelector('header p.label > a[href], header h3.search-results__heading > a[href]');
      if (!target || !source) return;
      const readHint = () => {
        if (!card.isConnected || card.querySelector('header h3.search-results__heading') !== target ||
            card.querySelector('header p.label > a[href], header h3.search-results__heading > a[href]') !== source) return null;
        const issn = doajIssn(source.href);
        const title = source.textContent.replace(/\s*\((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4}\)\s*$/i, '').replace(/\s+/g, ' ').trim();
        return title && title.length <= 120 && issn && !/\.\.\.|…/.test(title) ? { title, issns: [issn] } : null;
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint, card); else { results.track(card, 'unknown'); clear(target); }
    });
    return false;
  }

  function scanAimsJournal() {
    if (!(location.hostname === 'aimspress.com' || location.hostname.endsWith('.aimspress.com')) || !/^\/journal\/[^/]+\/?$/i.test(location.pathname)) return false;
    const target = document.querySelector('.journaldetail a.journal-tit[href]');
    if (!target) return true;
    const readHint = () => {
      if (!target.isConnected || document.querySelector('.journaldetail a.journal-tit[href]') !== target) return null;
      let url;
      try { url = new URL(target.href); } catch { return null; }
      if (url.hostname !== location.hostname || url.pathname.replace(/\/$/, '').toLowerCase() !== location.pathname.replace(/\/$/, '').toLowerCase()) return null;
      const title = target.textContent.replace(/\s+/g, ' ').trim();
      const issns = [...target.closest('.journaldetail').querySelectorAll('.cnissnwrap li')]
        .flatMap(node => node.textContent.match(/\b\d{4}-\d{3}[\dX]\b/gi) || []).filter(core.validIssn);
      return title && title.length <= 120 && issns.length ? { title, issns: [...new Set(issns)] } : null;
    };
    const hint = readHint();
    if (hint) void annotate(target, hint, readHint); else clear(target);
    return true;
  }

  function scanOpenAlex() {
    if (location.hostname !== 'openalex.org') return false;
    const pathname = location.pathname;
    const work = /^\/(?:works\/)?W\d+\/?$/i.test(pathname);
    const sourcePage = /^\/sources\/S\d+\/?$/i.test(pathname);
    if (!work && !sourcePage) return false;
    const page = document.querySelector('main .entity-page');
    const target = page?.querySelector('h1.entity-title');
    if (!target) return true;
    const readHint = () => {
      if (location.pathname !== pathname || !target.isConnected || document.querySelector('main .entity-page h1.entity-title') !== target) return null;
      const row = label => [...page.querySelectorAll('div:has(> span.font-weight-bold)')]
        .find(node => node.querySelector(':scope > span.font-weight-bold')?.textContent.trim() === `${label}:`);
      if (work) {
        if (row('Type')?.textContent.replace(/\s+/g, ' ').trim().toLowerCase() !== 'type: article') return null;
        const links = [...(row('Source')?.querySelectorAll('a[href]') || [])].filter(link => {
          const url = new URL(link.href, location.href);
          return url.hostname === 'openalex.org' && /^\/sources\/S\d+\/?$/i.test(url.pathname);
        });
        if (links.length !== 1) return null;
        const title = links[0].textContent.replace(/\s+/g, ' ').trim();
        return title && title.length <= 120 && !/\.\.\.|…/.test(title) ? { title, issns: [] } : null;
      }
      if (row('Source type')?.textContent.replace(/\s+/g, ' ').trim().toLowerCase() !== 'source type: journal') return null;
      const title = target.textContent.replace(/\s+/g, ' ').trim();
      const issns = (row('ISSN')?.textContent.match(/\b\d{4}-\d{3}[\dX]\b/gi) || []).filter(core.validIssn);
      return title && title.length <= 120 && issns.length ? { title, issns: [...new Set(issns)] } : null;
    };
    const hint = readHint();
    if (hint) void annotate(target, hint, readHint); else clear(target);
    return true;
  }

  function scanPubPeer() {
    if (!(location.hostname === 'pubpeer.com' || location.hostname.endsWith('.pubpeer.com'))) return false;
    if (/^\/publications\/[a-z0-9]+\/?$/i.test(location.pathname)) {
      const pathname = location.pathname;
      const target = document.querySelector('h1');
      const group = target?.parentElement?.parentElement;
      if (!target || !group) return true;
      const readHint = () => {
        if (location.pathname !== pathname || !target.isConnected || document.querySelector('h1') !== target || target.parentElement?.parentElement !== group) return null;
        const link = group.querySelector('p > a[title="View original article"][href^="https://doi.org/"]');
        const journal = link?.parentElement?.querySelector(':scope > span:first-child');
        const title = journal?.textContent.replace(/\s+/g, ' ').trim() || '';
        const doi = core.doiFromUrl(link?.href, location.href);
        return title && title.length <= 120 && doi && !/\.\.\.|…/.test(title)
          ? { title, issns: [], ...(settings.doiLookup ? { doi } : {}) } : null;
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint); else clear(target);
      return true;
    }
    document.querySelectorAll('h3 > a[href^="/publications/"]').forEach(link => {
      const target = link.parentElement;
      const group = target.parentElement;
      const readHint = () => {
        if (!link.isConnected || link.parentElement !== target || target.parentElement !== group || !/^\/publications\/[a-z0-9]+\/?$/i.test(new URL(link.href).pathname)) return null;
        const candidates = [...group.querySelectorAll(':scope > div')].map(node => [...node.querySelectorAll(':scope > span')])
          .filter(spans => spans.length === 3 && /^(?:19|20)\d{2}$/.test(spans[1].textContent.trim()) && core.normalizeDoi(spans[2].textContent));
        if (candidates.length !== 1) return null;
        const title = candidates[0][0].textContent.replace(/\s+/g, ' ').trim();
        const doi = core.normalizeDoi(candidates[0][2].textContent);
        return title && title.length <= 120 && !/\.\.\.|…/.test(title)
          ? { title, issns: [], ...(settings.doiLookup ? { doi } : {}) } : null;
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint); else clear(target);
    });
    return false;
  }

  function scanOrcid() {
    if (location.hostname !== 'orcid.org' || !/^\/\d{4}-\d{4}-\d{4}-[\dX]{4}\/?$/i.test(location.pathname)) return false;
    const pathname = location.pathname;
    document.querySelectorAll('app-work').forEach(work => {
      const target = work.querySelector('app-panel-data .data-content .general-data');
      if (!target) return;
      const readHint = () => {
        if (location.pathname !== pathname || !work.isConnected || work.querySelector('app-panel-data .data-content .general-data') !== target) return null;
        const fields = work.querySelectorAll('app-panel-data .data-content .general-data');
        if (!/\|\s*journal article\s*$/i.test(fields[1]?.textContent.trim() || '')) return null;
        const title = target.textContent.replace(/\s+/g, ' ').trim();
        const doi = core.doiFromUrl(work.querySelector('app-display-external-ids a[href^="https://doi.org/"]')?.href, location.href);
        return title && title.length <= 120 && !/\.\.\.|…/.test(title)
          ? { title, issns: [], ...(settings.doiLookup && doi ? { doi } : {}) } : null;
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint); else clear(target);
    });
    return true;
  }

  function scanMedSci() {
    if (!(location.hostname === 'medsci.cn' || location.hostname.endsWith('.medsci.cn')) || !/^\/sci\/journal\.(?:asp|do)\/?$/i.test(location.pathname)) return false;
    const pathname = location.pathname;
    const target = document.querySelector('.journal-detail .journal-detail-header .content-area > p.eh-title');
    if (!target) return true;
    const readHint = () => {
      if (location.pathname !== pathname || !target.isConnected || document.querySelector('.journal-detail .journal-detail-header .content-area > p.eh-title') !== target) return null;
      const title = target.textContent.replace(/\s+/g, ' ').trim();
      const issn = document.querySelector('#journalIssn')?.closest('.journal-content-column')?.querySelector('.column-content .font-black')?.textContent.trim() || '';
      return title && title.length <= 120 && !/\.\.\.|…/.test(title) && core.validIssn(issn) ? { title, issns: [issn] } : null;
    };
    const hint = readHint();
    if (hint) void annotate(target, hint, readHint); else clear(target);
    return true;
  }

  function scanResearchSquare() {
    if (!(location.hostname === 'researchsquare.com' || location.hostname.endsWith('.researchsquare.com')) || !/^\/article\/rs-\d+(?:\/[^/]*)*\/?$/i.test(location.pathname)) return false;
    const pathname = location.pathname;
    document.querySelectorAll('a[data-track="click_reading_the_published_version"][data-track-category="Published"]').forEach(link => {
      const target = link.closest('p');
      const group = target?.parentElement;
      if (!target || !group) return;
      const readHint = () => {
        if (location.pathname !== pathname || !link.isConnected || link.closest('p') !== target || target.parentElement !== group ||
            link.dataset.track !== 'click_reading_the_published_version' || link.dataset.trackCategory !== 'Published' ||
            ![...group.querySelectorAll('h3')].some(heading => heading.textContent.trim() === 'Journal Publication')) return null;
        let url;
        try { url = new URL(link.href); } catch { return null; }
        if (url.protocol !== 'https:' || url.hostname !== 'doi.org') return null;
        const doi = core.doiFromUrl(url.href, location.href);
        const title = (link.dataset.trackContext || '').replace(/\s+/g, ' ').trim();
        return title && title.length <= 120 && doi && !/\.\.\.|…/.test(title)
          ? { title, issns: [], ...(settings.doiLookup ? { doi } : {}) } : null;
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint); else clear(target);
    });
    return true;
  }

  function scanSciepub() {
    if (location.hostname !== 'pubs.sciepub.com') return false;
    const pathname = location.pathname;
    const slug = pathname.match(/^\/([a-z0-9]+)\/\d+\/\d+\/\d+\/?$/i)?.[1];
    if (!slug) return false;
    const articleTitle = meta('citation_title')[0];
    const headings = [...document.querySelectorAll('h3')].filter(node => articleTitle && core.normalizeTitle(node.textContent) === core.normalizeTitle(articleTitle));
    if (headings.length !== 1) return true;
    const target = headings[0];
    const readHint = () => {
      if (location.pathname !== pathname || !target.isConnected || core.normalizeTitle(target.textContent) !== core.normalizeTitle(meta('citation_title')[0])) return null;
      const hint = metadataHint();
      if (!hint?.title) return null;
      const source = [...document.querySelectorAll('a[href]')].find(link => {
        let url;
        try { url = new URL(link.href); } catch { return false; }
        return url.protocol === 'https:' && url.hostname === 'www.sciepub.com' && url.pathname.toLowerCase() === `/journal/${slug.toLowerCase()}` &&
          core.normalizeTitle(link.textContent) === core.normalizeTitle(hint.title);
      });
      if (!source) return null;
      const issns = [...new Set([...document.querySelectorAll('span')].map(node =>
        node.textContent.trim().match(/^ISSN\s*\((?:Print|Online)\)\s*:\s*(\d{4}-\d{3}[\dX])$/i)?.[1]).filter(core.validIssn))];
      // Do not fall back to a DOI's title-only metadata when the page provides ISSNs:
      // a different journal can have the same name.
      return issns.length && issns.length <= 2 ? { title: hint.title, issns } : null;
    };
    const hint = readHint();
    if (hint) void annotate(target, hint, readHint); else clear(target);
    return true;
  }

  function scanSciOpen() {
    if (location.hostname !== 'www.sciopen.com' && location.hostname !== 'sciopen.com') return false;
    const pathname = location.pathname;
    const issn = pathname.match(/^\/journal\/(\d{4}-\d{3}[\dX])(?:\/.*)?\/?$/i)?.[1];
    if (!issn) return false;
    const target = document.querySelector('#v4-journal-header a.info-name');
    if (!target) return true;
    const readHint = () => {
      if (location.pathname !== pathname || !target.isConnected || document.querySelector('#v4-journal-header a.info-name') !== target) return null;
      const title = target.textContent.replace(/\s+/g, ' ').trim();
      return title && title.length <= 120 && !/\.\.\.|…/.test(title) ? { title, issns: [issn] } : null;
    };
    const hint = readHint();
    if (hint) void annotate(target, hint, readHint); else clear(target);
    return true;
  }

  function scanLetPub() {
    if (!(location.hostname === 'www.letpub.com.cn' || location.hostname === 'letpub.com.cn')) return false;
    if (!/[?&]page=journalapp(?:&|$)/.test(location.search) || !/[?&]view=detail(?:&|$)/.test(location.search)) return false;
    const pathname = location.pathname + location.search;
    // The page also contains a hidden h1 brand heading; only the visible one carries the journal title.
    const heading = [...document.querySelectorAll('h1')].find(node => getComputedStyle(node).display !== 'none');
    if (!heading) return true;
    const readHint = () => {
      if (location.pathname + location.search !== pathname || !heading.isConnected) return null;
      const current = [...document.querySelectorAll('h1')].find(node => getComputedStyle(node).display !== 'none');
      if (current !== heading) return null;
      // The favorite-journal button inside the h1 must not become part of the title.
      const title = [...heading.childNodes].filter(node => node.nodeType === 3).map(node => node.textContent).join(' ')
        .replace(/\s+/g, ' ').trim();
      return title && title.length <= 120 && !/\.\.\.|…/.test(title) ? { title, issns: [] } : null;
    };
    const hint = readHint();
    if (hint) void annotate(heading, hint, readHint); else clear(heading);
    return true;
  }

  function scanIikx() {
    if (location.hostname === 'www.iikx.com' && /^\/sci\/[^/]+\/\d+\.html$/i.test(location.pathname)) {
      const heading = document.querySelector('h1.article-title');
      if (!heading) return true;
      const readHint = () => {
        if (document.querySelector('h1.article-title') !== heading) return null;
        const title = heading.querySelector(':scope > div')?.textContent.replace(/[《》]/g, '').replace(/\s+/g, ' ').trim() || '';
        const link = heading.querySelector('a[href*="/sci/analysts.html?issn="]');
        let url;
        try { url = new URL(link?.href); } catch { return null; }
        const issn = url.hostname === 'www.iikx.com' ? url.searchParams.get('issn') : '';
        return title && title.length <= 120 && !/\.\.\.|…/.test(title) && core.validIssn(issn) ? { title, issns: [issn] } : null;
      };
      const hint = readHint();
      if (hint) void annotate(heading, hint, readHint); else clear(heading);
      return true;
    }
    if (location.hostname === 'i.iikx.com' && /^\/\d+\/\d+\/\d+\.html$/i.test(location.pathname)) {
      const heading = document.querySelector('h1');
      if (!heading) return true;
      const readHint = () => {
        if (!settings.doiLookup || document.querySelector('h1') !== heading) return null;
        const articleTitle = heading.textContent.replace(/\s+/g, ' ').trim();
        const citation = document.querySelector('#app')?.textContent.replace(/\s+/g, ' ') || '';
        return articleTitle && articleTitle.length <= 400 && citation.includes(articleTitle)
          ? { title: '', issns: [], articleTitle } : null;
      };
      const hint = readHint();
      if (hint) void annotate(heading, hint, readHint); else clear(heading);
      return true;
    }
    return false;
  }

  function scanPkulaw() {
    if (!['www.pkulaw.com', 'pkulaw.com'].includes(location.hostname)) return false;
    const pathname = location.pathname;
    const journalId = pathname.match(/^\/singlejournal\/qikan\/(\d+)\/?$/i)?.[1];
    const detailId = pathname.match(/^\/journal\/journaldetail_(\d+)\.html$/i)?.[1];
    const article = /^\/qikan\/[a-z0-9]+\.html$/i.test(pathname);
    if (!journalId && !detailId && !article) return false;
    const target = journalId ? document.querySelector('.j-t h5 a[href^="/journal/journaldetail_"]')
      : detailId ? document.querySelector('.img > p:first-of-type') : document.querySelector('h2.title');
    if (!target) return true;
    const readHint = () => {
      if (!target.isConnected || location.pathname !== pathname) return null;
      let source = target;
      if (journalId && target.getAttribute('href') !== `/journal/journaldetail_${journalId}.html`) return null;
      if (detailId) {
        const image = target.parentElement?.querySelector('img[alt]');
        if (!image || image.alt.trim() !== target.textContent.trim()) return null;
      }
      if (article) {
        const matches = [...document.querySelectorAll('div.box')].filter(box => /^期刊名称\s*[:：]/.test(box.querySelector('strong')?.textContent.trim() || ''))
          .flatMap(box => [...box.querySelectorAll('a[href^="/journal/articlebyclass?"]')]);
        if (matches.length !== 1) return null;
        source = matches[0];
      }
      const title = source.textContent.replace(/[《》]/g, '').replace(/\s+/g, ' ').trim();
      return title && title.length <= 120 && !/\.\.\.|…/.test(title) ? { title, issns: [] } : null;
    };
    const hint = readHint();
    if (hint) void annotate(target, hint, readHint); else clear(target);
    return true;
  }

  function scanPkuJournals() {
    if (!['ccj.pku.edu.cn', 'jypl.pku.edu.cn'].includes(location.hostname) || !/^\/(?:article|journal)\/info\/?$/i.test(location.pathname)) return false;
    const pathname = location.pathname;
    const journal = document.querySelector('#journalTitle');
    const target = /^\/article\//i.test(pathname) ? document.querySelector('.main_content_top_title') : journal;
    if (!journal || !target) return true;
    const readHint = () => {
      if (!target.isConnected || document.querySelector('#journalTitle') !== journal || location.pathname !== pathname) return null;
      const title = journal.textContent.replace(/\s+/g, ' ').trim();
      const breadcrumb = document.querySelector('.main_content_top_div a[href^="/journal/info?jid="]');
      if (breadcrumb && core.normalizeTitle(breadcrumb.textContent) !== core.normalizeTitle(title)) return null;
      return title && title.length <= 120 && !/\.\.\.|…/.test(title) ? { title, issns: [] } : null;
    };
    const hint = readHint();
    if (hint) void annotate(target, hint, readHint); else clear(target);
    return true;
  }

  function scanArxiv() {
    if (location.hostname !== 'arxiv.org' || !/^\/abs\/[a-z0-9.\-/]+$/i.test(location.pathname)) return false;
    const heading = document.querySelector('h1.title');
    if (!heading) return true;
    const readHint = () => {
      if (!settings.doiLookup || document.querySelector('h1.title') !== heading) return null;
      const articleTitle = meta('citation_title')[0] || '';
      const clone = heading.cloneNode(true);
      clone.querySelectorAll('.descriptor').forEach(node => node.remove());
      if (!articleTitle || articleTitle.length > 400 || core.normalizeTitle(clone.textContent) !== core.normalizeTitle(articleTitle)) return null;
      const doi = core.normalizeDoi(document.querySelector('td.doi a[data-doi]')?.getAttribute('data-doi'));
      return { title: '', issns: [], articleTitle, requireArticleTitle: true, ...(doi ? { doi } : {}) };
    };
    const hint = readHint();
    if (hint) void annotate(heading, hint, readHint); else clear(heading);
    return true;
  }

  function scanArxivResults() {
    if (location.hostname !== 'arxiv.org' || !/^\/search\/?$/i.test(location.pathname)) return;
    document.querySelectorAll('li.arxiv-result').forEach(card => {
      const target = card.querySelector(':scope > p.title');
      if (!target) return;
      const readHint = () => {
        if (!settings.doiLookup || !card.isConnected || card.querySelector(':scope > p.title') !== target) return null;
        const articleTitle = target.textContent.replace(/\s+/g, ' ').trim();
        const dois = [...new Set([...card.querySelectorAll(':scope > div.is-marginless a[href^="https://doi.org/"]')]
          .map(link => core.doiFromUrl(link.href, location.href)).filter(doi => doi && !/^10\.48550\/arxiv\./i.test(doi)))];
        return articleTitle && articleTitle.length <= 400 && !/\.\.\.|…/.test(articleTitle) && dois.length === 1
          ? { title: '', issns: [], articleTitle, doi: dois[0], requireArticleTitle: true } : null;
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint, card); else { results.track(card, 'unknown'); clear(target); }
    });
  }

  function scanYiigle() {
    if (location.hostname !== 'rs.yiigle.com' || !/^\/cmaid\/\d+\/?$/i.test(location.pathname)) return false;
    const heading = document.querySelector('.art_title_group > .art_title');
    if (!heading) return true;
    const readHint = () => {
      if (document.querySelector('.art_title_group > .art_title') !== heading) return null;
      const paper = meta('citation_title')[0] || '';
      if (!paper || core.normalizeTitle(paper) !== core.normalizeTitle(heading.textContent)) return null;
      const hint = metadataHint();
      return hint ? { ...hint, allowMissingIssnTitle: true } : null;
    };
    const hint = readHint();
    if (hint) void annotate(heading, hint, readHint); else clear(heading);
    return true;
  }

  function scanAbleSci() {
    if (location.hostname !== 'www.ablesci.com') return false;
    const journal = /^\/journal\/detail\/?$/i.test(location.pathname);
    const article = /^\/scholar\/paper\/?$/i.test(location.pathname);
    if (!journal && !article) return false;
    const heading = document.querySelector('h1');
    if (!heading) return true;
    const readHint = () => {
      if (document.querySelector('h1') !== heading) return null;
      const source = article ? document.querySelector('.paper-journal-content-name > a') : heading;
      const title = source?.textContent.replace(/\s+/g, ' ').trim() || '';
      const row = journal ? [...document.querySelectorAll('tr')].find(node => node.querySelector('td')?.textContent.trim() === '期刊ISSN') : null;
      const issns = [...new Set((row?.querySelectorAll('td')[1]?.textContent.match(/(?<!\d)\d{4}-\d{3}[\dX](?!\d)/gi) || []).filter(core.validIssn))];
      return title && title.length <= 120 && !/\.\.\.|…/.test(title)
        ? { title, issns, ...(journal ? { allowDuplicateDatabaseIssn: true } : {}) } : null;
    };
    const hint = readHint();
    if (hint) void annotate(heading, hint, readHint); else clear(heading);
    return true;
  }

  function scanScholar() {
    const official = location.hostname.startsWith('scholar.google.');
    const searchCards = official ? '.gs_r' : '#gs_bdy #gs_res_ccl_mid .gs_r:has(.gs_rt)';
    const profileCards = official ? '.gsc_a_tr' : '#gsc_a_b .gsc_a_tr:has(a.gsc_a_at)';
    if (!official && !document.querySelector(`${searchCards} .gs_a, ${profileCards} .gsc_a_t`)) return;
    const articleHint = (card, title, source, profile = false) => {
      const doi = cardDoi(card);
      const heading = card?.querySelector(profile ? 'a.gsc_a_at' : '.gs_rt a') || (!profile && card?.querySelector('.gs_rt'));
      const text = heading?.textContent.replace(/^\s*\[(?:PDF|HTML|CITATION|引用)\]\s*/i, '').trim() || '';
      const articleTitle = settings.doiLookup && text.length <= 400 ? text : '';
      const parts = source.split(/\s+[-–—]\s+/);
      const publication = parts.length > 1 ? parts.slice(1).join(' ') : source;
      const articleYear = (profile ? card.querySelector('.gsc_a_y')?.textContent : publication)?.match(/\b(?:19|20)\d{2}\b/)?.[0];
      return title || doi || articleTitle ? { title, issns: [], ...(doi ? { doi } : {}),
        ...(articleTitle ? { articleTitle, ...(articleYear ? { articleYear } : {}) } : {}) } : null;
    };
    const sourceFor = card => {
      const sources = [...card.querySelectorAll('.gs_a')].filter(node => node.closest('.gs_r') === card);
      return sources.find(node => node.classList.contains('gs_fma_p')) || sources[0];
    };
    document.querySelectorAll(searchCards).forEach(card => {
      const target = sourceFor(card);
      if (!target) return;
      const readHint = () => {
        if (!card.matches(searchCards) || sourceFor(card) !== target) return null;
        // Featured Scholar results keep both compact and expanded citations in the DOM.
        const expanded = target.classList.contains('gs_fma_p');
        const source = expanded ? [...target.childNodes].filter(node => !node.classList?.contains('gs_fmaa'))
          .map(node => node.textContent).join(' ').trim() : target.textContent;
        const title = expanded ? core.scholarProfileJournal(source.split(/[•·]/)[0]) : core.scholarJournal(source);
        return articleHint(card, title, source);
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint, card);
      else { results.track(card, 'unknown'); clear(target); }
    });
    document.querySelectorAll(profileCards).forEach(card => {
      const cell = card.querySelector('.gsc_a_t');
      const target = [...(cell?.querySelectorAll(':scope > .gs_gray') || [])].at(-1);
      if (!target) return;
      const readHint = () => card.matches(profileCards) && target.isConnected && target.closest('.gsc_a_tr') === card
        ? articleHint(card, core.scholarProfileJournal(target.textContent), target.textContent, true) : null;
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint, card);
      else { results.track(card, 'unknown'); clear(target); }
    });
  }

  function scanPublisherLists() {
    document.querySelectorAll('article [data-test="journal-title-and-link"], article [itemprop="isPartOf"] [itemprop="name"]').forEach(target => {
      const article = target.closest?.('article');
      const card = (location.hostname === 'nature.com' || location.hostname.endsWith('.nature.com'))
        ? article?.closest('li.app-article-list-row__item') || article : article;
      const readHint = () => {
        const title = target.textContent.trim();
        return title && title.length <= 120 ? { title, issns: [] } : null;
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint, card);
      else { results.track(card, 'unknown'); clear(target); }
    });
  }

  function scanAdaptedLists() {
    const host = location.hostname;
    const adapters = [
      { host: 'kns.cnki.net', selector: 'td.source', card: 'tr',
        target: (node, card) => card.querySelector('td.name a') || node.querySelector('a') || node,
        title: node => node.querySelector('a')?.textContent || [...node.childNodes].filter(child => !child.classList?.contains('scansci-journal-badges')).map(child => child.textContent).join('') },
      { host: 'xueshu.baidu.com', selector: 'div.result div.sc_info span:nth-of-type(2) a', card: 'div.result', title: node => node.getAttribute('title') || node.textContent },
      { host: 'sciencedirect.com', selector: 'li.ResultItem a[data-aa-name*="srp-srctitle-"]', card: 'li.ResultItem' },
      { host: 'link.springer.com', selector: '#results-list > li p.meta span.enumeration > a', card: 'li' },
      { host: 'ieeexplore.ieee.org', selector: 'xpl-results-list div.List-results-items .hide-mobile .result-item-align .description > a[href*="/xpl/RecentIssue.jsp"], xpl-results-list div.List-results-items .hide-desktop .description > div > a[href*="/xpl/RecentIssue.jsp"]', card: 'div.List-results-items' },
      { host: 'dl.acm.org', selector: '.doSearch li.issue-item-container .issue-item__detail > a:first-child', card: 'li.issue-item-container', title: node => (node.getAttribute('title') || node.textContent).replace(/^[^:：]+[:：]\s*/, '') },
      { host: 'dblp.org', selector: '.publ-list li.entry.article span[itemprop="isPartOf"] span[itemprop="name"]', card: 'li.entry' },
      { host: 'dblp.dagstuhl.de', selector: '.publ-list li.entry.article span[itemprop="isPartOf"] span[itemprop="name"]', card: 'li.entry' },
      { host: 'aminer.cn', selector: 'div.paper-item .conf-info-zone > .venue-link > .venue-link:first-child', card: 'div.paper-item', title: node => node.textContent.split(/[（(]/)[0] },
      { host: 'scopus.com', selector: '#srchResultsList tr.searchArea td[data-type="source"] a.ddmDocSource, tr[class^="TableItems"] div[data-component="document-source"] span:first-child', card: 'tr' },
      { host: 'webofscience.com',
        selector: 'app-jcr-sidenav .summary-source-title, app-jcr-sidenav .summary-source-title-link, app-jcr-sidenav span[lang="en"], app-jcr-sidenav a[lang="en"], app-jcr-sidenav a, app-jcr-sidenav [data-ta*="source"], app-jcr-sidenav [data-test*="source"], .source-title-display > a.jcrSideNav-color > span, app-publication-card-content span.journal-name, app-publication-card-content [class*="journal-name"], app-record [data-ta*="source-title"], app-record [data-test*="journal"], app-record [class*="source-title"], app-record [class*="journal-name"], .search-results-item [data-ta*="source-title"], .search-results-item [data-test*="journal"], .search-results-item [class*="source-title"], .search-results-item [class*="journal-name"]',
        card: 'app-record, app-publication-card-content, .search-results-item',
        target: node => node.closest('a.summary-source-title-link, a.jcrSideNav-color') || node,
        title: node => {
          const text = node.cloneNode(true);
          text.querySelectorAll('mat-icon, .mat-icon, [aria-hidden="true"], .scansci-journal-badges, .scansci-title-translation').forEach(child => child.remove());
          return text.textContent;
        } },
      { host: 'semanticscholar.org', selector: '#main-content div.cl-paper-row .cl-paper__bulleted-row__item > a > span', card: 'div.cl-paper-row' },
      { host: 'wanfangdata.com.cn', selector: 'div.normal-list div.author-area span.periodical-title', card: 'div.normal-list',
        target: (node, card) => card.querySelector('div.title-area span.title') || node },
      { host: 'cqvip.com', selector: '.simple-list > dl .from > a', card: 'dl', title: node => node.getAttribute('title') || node.textContent,
        target: (node, card) => card.querySelector('dt') || node },
      { host: 'x-mol.com', selector: 'div[class*="SearchPaperGridCard"] span[class*="gridJournalName"]', card: 'div[class*="SearchPaperGridCard"]',
        target: (node, card) => card.querySelector('h3') || node },
      { host: 'x-mol.com', selector: 'div[class*="SearchResultLayout-module"] div[class*="cardBody"] span[class*="journalLink"], div[class*="ReadResultLayout-module"] div[class*="cardBody"] a[class*="journalLink"]', card: 'div[class*="cardBody"]',
        target: (node, card) => card.querySelector('h3') || node },
      { host: 'readpaper.com', selector: '.paper-item span.block:first-child', card: '.paper-item',
        target: (node, card) => card.querySelector('.title') || node },
      { host: 'pubscholar.cn', selector: '.ContentItem__metaSource:not(.is-en)', card: '.ContentItem',
        target: (node, card) => card.querySelector('.ContentItem__title') || node, filter: false },
      { host: 'airitilibrary.com', selector: '.col_academicPresent .sourceTitleName', card: '.col_academicPresent',
        accept: node => node.closest('.col_academicPresent')?.querySelector('.ustyle_Label_preTag .preTag')?.textContent.replace(/\s+/g, ' ').trim() === '期刊',
        target: (node, card) => card.querySelector('h3.ustyle_heading_H3') || node, filter: false },
      { host: 'opticsjournal.net', selector: '.item-con > .list > .con', card: '.item-con',
        accept: node => /^\/J\//i.test(location.pathname) && /^名称[：:]$/.test(node.previousElementSibling?.textContent.trim() || ''),
        issns: node => {
          const items = [...node.closest('.item-con').querySelectorAll(':scope > .list')];
          const issn = items.find(item => /^ISSN[：:]$/i.test(item.querySelector(':scope > .tit')?.textContent.trim() || ''));
          return [issn?.querySelector(':scope > .con')?.textContent.trim() || ''];
        }, doi: () => '', filter: false },
      ...['ncpssd.cn', 'ncpssd.org'].flatMap(site => [
        { host: site, selector: '.b-content > h1.H2Style', card: '.b-content',
          accept: () => /^\/journal\/(?:secure\/)?details\/?$/i.test(location.pathname),
          issns: node => {
            const item = [...node.closest('.b-content').querySelectorAll('li')].find(li => li.querySelector('strong')?.textContent.trim() === '国际标准刊号');
            return [item?.textContent.match(/\b\d{4}-\d{3}[\dX]\b/i)?.[0] || ''];
          },
          cnNumber: node => {
            const item = [...node.closest('.b-content').querySelectorAll('li')].find(li => li.querySelector('strong')?.textContent.trim() === '国内统一刊号');
            return item?.textContent.match(/\d{2}-\d{4}\/[A-Z0-9]{1,4}/i)?.[0] || '';
          }, doi: () => '', filter: false },
        { host: site, selector: '#p_media > a.chuchu_style[href^="/journal/"]', card: '.b-content',
          accept: () => /^\/Literature\/articleinfo\/?$/i.test(location.pathname),
          target: (node, card) => card.querySelector('#h2_title_c') || node,
          title: node => node.textContent.match(/^\s*《([^》]+)》/)?.[1] || '', doi: () => '', filter: false },
      ]),
      { host: 'scholarmate.com', selector: 'div.flex-1.min-w-0 > p > i:first-child', card: 'div.flex-1.min-w-0',
        accept: node => !!node.parentElement?.querySelector(':scope > i') && /^\s*,\s*(?:19|20)\d{2}(?:\s*,|\s*$)/.test(node.nextSibling?.textContent || ''),
        target: (node, card) => card.querySelector(':scope > h4') || node, filter: false },
      { host: 'yiigle.com', selector: 'div.current_content_article_body p.current_tip', card: 'div.current_content_article_body',
        target: (node, card) => card.querySelector('p.Current_Title > a[href^="https://rs.yiigle.com/cmaid/"]') || node,
        title: node => [...node.childNodes].filter(child => child.nodeType === Node.TEXT_NODE).map(child => child.textContent).join(''), filter: false },
      { host: 'connectedpapers.com', selector: '.abtract-scrollbox .metadata.publication', card: '.abtract-scrollbox',
        title: node => (node.getAttribute('title') || node.textContent).match(/^(?:19|20)\d{2}\s*,\s*(.+)$/)?.[1] || '', filter: false },
      { host: 'pkulaw.com', selector: 'div.col > div.info > a[href^="/singlejournal/qikan/"]', card: 'div.col',
        target: (node, card) => card.querySelector('div.t h4 a[href^="/qikan/"]') || node },
      { host: 'journal-recommender.sagepub.com', selector: '.card-header .card-body > h5', card: '.card',
        accept: node => {
          const code = node.textContent.trim().match(/\(([A-Z0-9]+)\)$/)?.[1];
          const image = node.closest('.card-header')?.querySelector('img[src*="/action/showCoverImage?"]');
          try {
            const url = new URL(image?.src);
            return !!code && url.hostname === 'journals.sagepub.com' && url.pathname === '/action/showCoverImage' && url.searchParams.get('journalCode')?.toUpperCase() === code;
          } catch { return false; }
        },
        title: node => node.textContent.replace(/\s*\([A-Z0-9]+\)\s*$/, '').replace(/,\s+The\s*$/i, ''), filter: false },
      { host: 'scilit.com', selector: 'a[href^="/sources/"]', card: 'li:has(a[href^="/publications/"])' },
      { host: 'scilit.net', selector: 'a[href^="/sources/"]', card: 'li:has(a[href^="/publications/"])' },
      { host: 'journals.aps.org', selector: 'span.article-feature-tag:first-of-type', card: 'div.flex.flex-col.w-full',
        accept: node => /^(?:Physical Review|Reviews of Modern Physics|PRX\b|Physics$)/.test(node.textContent.trim()) },
      { host: 'iopscience.iop.org', selector: 'li.art-list-item h2.art-list-item-title > a[href^="/article/"]', card: 'li.art-list-item',
        title: () => '', issns: node => {
          const issn = node.getAttribute('href').match(/^\/article\/10\.1088\/(\d{4}-\d{3}[\dX])(?:\/|$)/i)?.[1];
          return issn ? [issn] : [];
        } },
      { host: 'mdpi.com', selector: 'article a[href]', card: 'article',
        accept: node => {
          const href = node.getAttribute('href') || '';
          const text = node.textContent.replace(/\s+/g, ' ').trim();
          return /^\/(?:\d{4}-\d{3}[\dX])\/[^/]+\/[^/]+\/[^/]+\/?$/i.test(href) && text.length >= 12 && !/^(?:download|full article|view|pdf)/i.test(text);
        },
        title: () => '',
        issns: node => {
          const issn = node.getAttribute('href').match(/^\/(\d{4}-\d{3}[\dX])\//i)?.[1];
          return issn ? [issn] : [];
        } },
      { host: 'link.springer.com', selector: 'a[href*="utm_source=slink"][href*="journal_finder"]', card: 'div[class*="app-suggester-journal-overview"]' },
      { host: 'erudit.org', selector: 'li.row.result div.row.meta em > a[href]', card: 'li.row.result' },
      { host: 'onlinelibrary.wiley.com', selector: 'a.meta__serial[href^="/journal/"]', card: 'li.search__item',
        issns: node => {
          const digits = node.getAttribute('href').match(/^\/journal\/(\d{7}[\dX])(?:\/|$)/i)?.[1];
          return digits ? [digits.replace(/^(\d{4})(\d{3}[\dX])$/i, '$1-$2')] : [];
        } },
      { host: 'asmedigitalcollection.asme.org', selector: 'div.sri-title h4 > a', card: 'div.sr-list.al-article-box', title: () => '' },
      { host: 'journals.sagepub.com', selector: 'div.issue-item__journal > span > span', card: 'div.issue-item' },
      { host: 'publications.aap.org', selector: 'div.sf-facet-display a[href]', card: 'div.sr-list.al-article-box' },
      { host: 'ascopubs.org', selector: 'h3.card-title a[href*="/doi/"]', card: 'li.issue-item, div.card.issue-item', title: () => '', doi: linkedDoi },
      { host: 'journals.asm.org', selector: '.issue-item__title a[href*="/doi/"]', card: 'li.issue-item', title: () => '', doi: linkedDoi },
      { host: 'pubs.rsna.org', selector: 'h3.card-title a[href*="/doi/"]', card: 'div.card', title: () => '', doi: linkedDoi },
      { host: 'pnas.org', selector: 'h3.article-title a[href*="/doi/"]', card: 'div.card', title: () => '', doi: linkedDoi },
      { host: 'journals.physiology.org', selector: 'a.meta__serial[href^="/journal/"]', card: 'li.search__item' },
      { host: 'pubsonline.informs.org', selector: 'a.meta__serial[href^="/journal/"]', card: 'li.search__item' },
      { host: 'tandfonline.com', selector: 'a.searchResultJournal[href^="/journals/"]', card: 'article.searchResultItem' },
      { host: 'hal.science', selector: 'div.citation-results i', card: 'table.results-table tbody tr' },
      { host: 'ascelibrary.org', selector: 'span.issue-item__details__left', card: 'div.issue-item' },
      { host: 'muse.jhu.edu', selector: 'div.journal span a[href]', card: 'div.result' },
      { host: 'thelancet.com', selector: 'span.publication_meta_journal i', card: 'li.search__item' },
      { host: 'science.org', selector: 'span.card-meta__item.bullet-left:first-of-type', card: 'div.card' },
      { host: 'aacrjournals.org', selector: 'div.sf-facet-display a[href]', card: 'div.sr-list.al-article-box' },
      { host: 'aacrjournals.org', selector: 'div.content-type-journal a[href*="?searchresult=1"]', card: 'div.content-type-journal' },
      { host: 'karger.com', selector: 'div.sf-facet-display a[href]', card: 'div.sr-list.al-article-box' },
      { host: 'karger.com', selector: 'div.content-type-journal a[href*="?searchresult=1"]', card: 'div.content-type-journal' },
      { host: 'rupress.org', selector: 'div.sf-facet-display a[href]', card: 'div.sr-list.al-article-box' },
      { host: 'rupress.org', selector: 'div.content-type-journal a[href*="?searchresult=1"]', card: 'div.content-type-journal' },
      { host: 'pubs.aip.org', selector: 'div.sf-facet-display a[href]', card: 'div.sr-list.al-article-box' },
      { host: 'direct.mit.edu', selector: 'div.sf-facet-display a[href]', card: 'div.sr-list.al-article-box' },
      { host: 'jstor.org', selector: 'search-results-vue-pharos-link[data-qa="search-result-title-link"]', card: 'div.result',
        title: node => {
          const row = node.closest('div.result')?.querySelector('div.break-word.metadata-row');
          const text = row?.textContent.replace(/\s+/g, ' ').trim() || '';
          return text.match(/^(.+?),\s*Vol\./)?.[1]?.trim() || '';
        } },
    ];
    for (const adapter of adapters.filter(item => host === item.host || host.endsWith(`.${item.host}`))) {
      const targets = new Set();
      document.querySelectorAll(adapter.selector).forEach(source => {
        if (source.closest('.scansci-journal-badges, .scansci-title-translation')) return;
        if (adapter.accept && !adapter.accept(source)) return;
        const card = source.closest(adapter.card);
        if (!card) return;
        const target = adapter.target ? adapter.target(source, card) : source;
        if (targets.has(target)) return;
        targets.add(target);
        const readHint = () => {
          if (!source.matches(adapter.selector) || source.closest(adapter.card) !== card || (adapter.accept && !adapter.accept(source)) || (adapter.target && adapter.target(source, card) !== target)) return null;
          const title = String(adapter.title ? adapter.title(source) : source.textContent).replace(/[《》]/g, '').replace(/\s+/g, ' ').trim();
          const usableTitle = title && title.length <= 120 && !/\.\.\.|…/.test(title) ? title : '';
          const issns = adapter.issns ? adapter.issns(source).filter(core.validIssn) : [];
          const cnNumber = adapter.cnNumber ? adapter.cnNumber(source) : '';
          const doi = adapter.doi ? (settings.doiLookup ? adapter.doi(source) : '') : cardDoi(card);
          return usableTitle || issns.length || doi ? { title: usableTitle, issns, ...(cnNumber ? { cnNumber } : {}), ...(doi ? { doi } : {}) } : null;
        };
        const hint = readHint();
        const filterCard = adapter.filter === false ? undefined : card;
        if (hint) void annotate(target, hint, readHint, filterCard);
        else { results.track(filterCard, 'unknown'); clear(target); }
      });
    }
  }

  function pubmedId(card) {
    return String(card.getAttribute('data-article-id') || card.querySelector('.docsum-pmid')?.textContent || '').trim();
  }

  function pmcId(card) {
    const anchor = card.querySelector('a.docsum-title[href]');
    if (!anchor) return '';
    try {
      const url = new URL(anchor.getAttribute('href'), location.href);
      return url.protocol === 'https:' && url.hostname === 'pmc.ncbi.nlm.nih.gov'
        ? url.pathname.match(/^\/articles\/PMC(\d{1,12})\/?$/i)?.[1] || '' : '';
    } catch { return ''; }
  }

  async function scanNcbi() {
    const database = location.hostname === 'pubmed.ncbi.nlm.nih.gov' ? 'pubmed'
      : location.hostname === 'pmc.ncbi.nlm.nih.gov' ? 'pmc' : '';
    if (!database) return;
    const cardSelector = database === 'pmc' ? '.articles > ul > li.article' : 'article.full-docsum, .full-docsum';
    const targetSelector = database === 'pmc' ? 'a.docsum-title[href]' : '.docsum-journal-citation';
    const getId = database === 'pmc' ? pmcId : pubmedId;
    const entries = [];
    for (const card of document.querySelectorAll(cardSelector)) {
      const id = getId(card);
      const target = card.querySelector(targetSelector);
      if (!/^\d{1,12}$/.test(id)) { results.track(card, 'unknown'); clear(target); }
      else {
        const signature = `${database}:${id}`;
        const renewed = results.track(card, signature);
        if (renewed && seen.get(target) === signature) seen.delete(target);
        if (mark(target, signature)) entries.push({ id, target, card });
      }
    }
    if (!entries.length) return;
    const current = generation;
    for (let start = 0; start < entries.length; start += 80) {
      const batch = entries.slice(start, start + 80);
      const response = await send({ type: 'pubmed', database, ids: batch.map(entry => entry.id) });
      if (current !== generation) return;
      if (!response?.ok) {
        for (const entry of entries.slice(start)) retry(entry.target, `${database}:${entry.id}`, current);
        return;
      }
      await Promise.all(batch.map(async entry => {
        const hint = response.data[entry.id];
        const doi = settings.doiLookup ? core.normalizeDoi(hint?.doi) : '';
        if (!hint || (!hint.title && !hint.issns.length && !doi)) return;
        const signature = `${database}:${entry.id}`;
        const isCurrent = () => getId(entry.card) === entry.id && entry.card.querySelector(targetSelector) === entry.target;
        if (!isCurrent()) return;
        const result = await send({ type: 'lookup', title: hint.title, issns: hint.issns, ...(doi ? { doi } : {}), details: settings.ccf || settings.badgeHistory });
        if (result?.ok) show(entry.target, result.data || core.localBusinessJournal(hint), current, signature, isCurrent, entry.card);
        else retry(entry.target, signature, current);
      }));
    }
  }

  async function scanEuropePmc() {
    if (location.hostname !== 'europepmc.org') return;
    const cards = [...document.querySelectorAll('li.separated-list-item')];
    const entries = [];
    for (const card of cards) {
      const link = card.querySelector('a[href^="/article/MED/"]');
      const pmid = link?.getAttribute('href').match(/^\/article\/MED\/(\d{1,12})(?:\/|$)/)?.[1] || '';
      const target = card.querySelector('.citation-title') || link;
      if (!pmid || !target) { results.track(card, 'unknown'); continue; }
      const signature = `pubmed:${pmid}`;
      const renewed = results.track(card, signature);
      if (renewed && seen.get(target) === signature) seen.delete(target);
      if (mark(target, signature)) entries.push({ id: pmid, target, card });
    }
    if (!entries.length) return;
    const current = generation;
    for (let start = 0; start < entries.length; start += 80) {
      const batch = entries.slice(start, start + 80);
      const response = await send({ type: 'pubmed', database: 'pubmed', ids: batch.map(entry => entry.id) });
      if (current !== generation) return;
      if (!response?.ok) {
        for (const entry of entries.slice(start)) retry(entry.target, `pubmed:${entry.id}`, current);
        return;
      }
      await Promise.all(batch.map(async entry => {
        const hint = response.data[entry.id];
        const doi = settings.doiLookup ? core.normalizeDoi(hint?.doi) : '';
        if (!hint || (!hint.title && !hint.issns.length && !doi)) return;
        const signature = `pubmed:${entry.id}`;
        const isCurrent = () => entry.card.isConnected &&
          entry.card.querySelector('a[href^="/article/MED/"]')?.getAttribute('href')?.match(/^\/article\/MED\/(\d{1,12})(?:\/|$)/)?.[1] === entry.id;
        if (!isCurrent()) return;
        const result = await send({ type: 'lookup', title: hint.title, issns: hint.issns, ...(doi ? { doi } : {}), details: settings.ccf || settings.badgeHistory });
        if (result?.ok) show(entry.target, result.data || core.localBusinessJournal(hint), current, signature, isCurrent, entry.card);
        else retry(entry.target, signature, current);
      }));
    }
  }

  function scanWileyFinder() {
    for (const [root, observer] of wileyRoots) {
      if (!root.host.isConnected || location.hostname !== 'www.wiley.com' || !/^\/[a-z]{2}-[a-z]{2}\/journal-finder(?:\/|$)/i.test(location.pathname)) {
        root.querySelectorAll('.scansci-journal-badges').forEach(removeBadge);
        observer.disconnect();
        wileyRoots.delete(root);
      }
    }
    if (location.hostname !== 'www.wiley.com' || !/^\/[a-z]{2}-[a-z]{2}\/journal-finder(?:\/|$)/i.test(location.pathname)) return;
    for (const host of document.querySelectorAll('code-island')) {
      const root = host.shadowRoot;
      if (!root?.querySelector('.jfs-shell')) continue;
      if (!wileyRoots.has(root)) {
        const css = document.createElement('link');
        css.rel = 'stylesheet';
        css.href = api.runtime.getURL(core.extensionPath('content.css', api.runtime));
        root.append(css);
        wileyRoots.set(root, observeChanges(root));
      }
      root.querySelectorAll('.jfs-result-list > li .jfs-card__title').forEach(target => {
        const card = target.closest('.jfs-card');
        if (!card) return;
        const readHint = () => {
          if (!host.isConnected || card.querySelector('.jfs-card__title') !== target) return null;
          const imageLink = card.querySelector('.jfs-card__image-link');
          const journalId = target.getAttribute('data-journal-id');
          if (!journalId || imageLink?.getAttribute('data-journal-id') !== journalId || imageLink.getAttribute('href') !== target.getAttribute('href')) return null;
          const clone = target.cloneNode(true);
          clone.querySelectorAll('[aria-hidden="true"]').forEach(node => node.remove());
          const title = clone.textContent.replace(/\s+/g, ' ').trim();
          const image = card.querySelector('img.jfs-card__image[src]');
          let issn = '';
          try {
            const url = new URL(image?.src);
            const path = decodeURIComponent(url.pathname);
            if (url.hostname === 'onlinelibrary.wiley.com') issn = path.match(/^\/cover\/doi\/10\.1111\/\(ISSN\)(\d{4}-\d{3}[\dX])$/i)?.[1] || '';
          } catch { /* A journal may not have a cover image. */ }
          return title && title.length <= 120 && !/\.\.\.|…/.test(title)
            ? { title, issns: core.validIssn(issn) ? [issn] : [] } : null;
        };
        const hint = readHint();
        if (hint) void annotate(target, hint, readHint); else clear(target);
      });
    }
    if (wileyRoots.size) wileyDiscoveryAttempts = 0;
    else if (!wileyDiscoveryTimer && wileyDiscoveryAttempts < 40) {
      wileyDiscoveryTimer = setTimeout(() => {
        wileyDiscoveryTimer = undefined;
        wileyDiscoveryAttempts += 1;
        if (ready && settings.enabled) scanWileyFinder();
      }, 500);
    }
  }

  function scan() {
    if (!ready || !settings.enabled) return;
    if (!scanCnkiArticle() && !scanIeeePage() && !scanResearchGate() && !scanDoaj() && !scanAimsJournal() && !scanOpenAlex() && !scanPubPeer() && !scanOrcid() && !scanMedSci() && !scanResearchSquare() && !scanSciepub() && !scanSciOpen() && !scanLetPub() && !scanIikx() && !scanPkulaw() && !scanPkuJournals() && !scanArxiv() && !scanYiigle() && !scanAbleSci()) scanMetadata();
    scanJournalFinder();
    scanScholar();
    scanPublisherLists();
    scanAdaptedLists();
    scanArxivResults();
    scanWileyFinder();
    void scanNcbi();
    void scanEuropePmc();
  }

  function rescan(preserveResults = false) {
    generation += 1;
    seen = new WeakMap();
    mounted = new WeakMap();
    retried = new WeakMap();
    clearTimeout(retryTimer);
    retryTimer = undefined;
    retryTargets.clear();
    if (!preserveResults) results.clear();
    badgeNodes('.scansci-journal-badges').forEach(removeBadge);
    scan();
  }

  const hasMaintainerRankings = core.businessRankingCount() > 0;
  let rankingChangedBeforeReady = false;
  api.storage.local.get({ ...core.defaults, badgeStyle: 'a', badgeColors: null, badgeLevelColors: null, badgeVisibility: null, badgeOrder: null, badgeAliases: null, badgeLayout: null, businessRankings: null }, values => {
    if (!hasMaintainerRankings && !rankingChangedBeforeReady && values.businessRankings !== null) {
      try { core.setBusinessRankings(values.businessRankings?.entries); } catch { core.setBusinessRankings(null); }
    }
    settings = { ...core.defaults, ...values };
    badgeStyle = values.badgeStyle;
    badgeColors = values.badgeColors;
    badgeLevelColors = values.badgeLevelColors;
    palette = core.badgePalette(badgeStyle, badgeColors);
    layout = core.badgeLayout(values.badgeLayout);
    ready = true;
    scan();
  });
  api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    let rescanNeeded = false, detailRefreshNeeded = false, repaintNeeded = false;
    if (!hasMaintainerRankings && changes.businessRankings) {
      if (!ready) rankingChangedBeforeReady = true;
      try { core.setBusinessRankings(changes.businessRankings.newValue?.entries ?? null); } catch { core.setBusinessRankings(null); }
      rescanNeeded = true;
    }
    for (const [key, change] of Object.entries(changes)) if (key in core.defaults) {
      const previous = settings[key];
      settings[key] = change.newValue ?? core.defaults[key];
      if (['enabled', 'doiLookup', 'filter'].includes(key)) rescanNeeded = true;
      else if (['ccf', 'badgeHistory'].includes(key) && settings[key] && !previous) detailRefreshNeeded = true;
      else repaintNeeded = true;
    }
    for (const key of ['badgeVisibility', 'badgeOrder', 'badgeAliases']) if (changes[key]) { settings[key] = changes[key].newValue; repaintNeeded = true; }
    if (changes.badgeStyle || changes.badgeColors || changes.badgeLevelColors || changes.badgeLayout) {
      badgeStyle = changes.badgeStyle ? changes.badgeStyle.newValue ?? 'a' : badgeStyle;
      badgeColors = changes.badgeColors ? changes.badgeColors.newValue : badgeColors;
      badgeLevelColors = changes.badgeLevelColors ? changes.badgeLevelColors.newValue : badgeLevelColors;
      palette = core.badgePalette(badgeStyle, badgeColors);
      if (changes.badgeLayout) layout = core.badgeLayout(changes.badgeLayout.newValue);
      badgeNodes('.scansci-journal-badges').forEach(node => paintContainer(node, node.querySelector('.scansci-journal-link')));
      badgeNodes('.scansci-journal-badge').forEach(paintBadge);
    }
    if (rescanNeeded || detailRefreshNeeded) rescan(!rescanNeeded);
    else if (repaintNeeded) badgeNodes('.scansci-journal-badges').forEach(node => {
      if (node.scansciIsCurrent?.()) renderBadges(node, node.scansciRow);
    });
  });
  function handleMutations(records) {
    if (records && !records.some(record => {
      if (record.type !== 'attributes' || record.attributeName !== 'class') return true;
      const externalClasses = value => String(value || '').split(/\s+/).filter(name => name && !name.startsWith('scansci-')).sort().join(' ');
      return externalClasses(record.oldValue) !== externalClasses(record.target.getAttribute('class'));
    })) return;
    results.refresh();
    badgeNodes('.scansci-journal-badges').forEach(node => { if (!node.scansciIsCurrent?.()) removeBadge(node); });
    if (!timer) timer = setTimeout(() => { timer = undefined; scan(); }, 150);
  }

  function observeChanges(node) {
    const observer = new MutationObserver(handleMutations);
    observer.observe(node, { childList: true, characterData: true, attributes: true, attributeOldValue: true, attributeFilter: ['content', 'name', 'value', 'type', 'itemprop', 'data-test', 'data-aa-name', 'data-type', 'data-component', 'data-track', 'data-track-category', 'data-track-context', 'lang', 'id', 'data-article-id', 'title', 'href', 'src', 'class'], subtree: true });
    return observer;
  }
  observeChanges(document.documentElement);
})();
