(() => {
  const api = globalThis.chrome || globalThis.browser;
  const core = globalThis.ScanSciCore;
  const catalog = core.badgeCatalog;
  const byId = new Map(catalog.map(item => [item.id, item]));
  const groups = [...new Set(catalog.map(item => item.group))];
  const paletteKinds = [
    ['impact', '影响因子'], ['jcr', 'JCR 分区'], ['cas', '中科院分区'], ['xinrui', '新锐分区'],
    ['hq', '科协分级'], ['ccf', 'CCF 推荐'], ['ccft', 'CCFT 分级'], ['natureIndex', 'Nature Index'],
    ['chinese', '中文核心'], ['indexing', '收录类型'], ['warning', '期刊预警'],
  ];
  const defaults = { ...core.defaults, ...core.translationDefaults, badgeVisibility: {}, badgeOrder: null, badgeAliases: {}, badgeLayout: null, badgeStyle: 'a', badgeColors: null, savedPapers: [] };
  const status = document.getElementById('saveStatus');
  const metricList = document.getElementById('metricList');
  const metricSearch = document.getElementById('metricSearch');
  let state = { ...defaults };
  let rawTranslationSettings = { ...core.translationDefaults };
  let ready = false, initialChanges = {};
  let storageRevision = 0, refreshSerial = 0;
  let dragged = '';

  function icon(name) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'lucide-icon'); svg.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', `icons.svg#${name}`); svg.append(use);
    return svg;
  }

  function cleanVisibility(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
    return Object.fromEntries(catalog.filter(item => typeof value[item.id] === 'boolean').map(item => [item.id, value[item.id]]));
  }
  function selected(item) {
    return Boolean(state[item.group]) && state.badgeVisibility[item.id] !== false;
  }
  function applyValues(values) {
    state = { ...state, ...values };
    for (const key of Object.keys(core.translationDefaults)) if (Object.hasOwn(values, key)) rawTranslationSettings[key] = values[key];
    state.badgeVisibility = cleanVisibility(state.badgeVisibility);
    state.badgeOrder = core.badgeOrder(state.badgeOrder);
    const aliases = state.badgeAliases && typeof state.badgeAliases === 'object' && !Array.isArray(state.badgeAliases) ? state.badgeAliases : {};
    state.badgeAliases = Object.fromEntries(Object.keys(core.badgePrefixes).filter(key => core.badgeAlias(aliases[key])).map(key => [key, core.badgeAlias(aliases[key])]));
    state.badgeLayout = core.badgeLayout(state.badgeLayout);
    state.badgeStyle = ['a', 'b', 'c', 'custom'].includes(state.badgeStyle) ? state.badgeStyle : 'a';
    Object.assign(state, core.translationSettings(rawTranslationSettings));
  }
  function refreshFromStorage() {
    if (!ready) return;
    const revision = storageRevision, serial = ++refreshSerial;
    api.storage.local.get(defaults, stored => {
      if (revision !== storageRevision || serial !== refreshSerial) return;
      applyValues(stored); render();
    });
  }
  function save(values) {
    applyValues(values);
    render();
    api.storage.local.set(values, () => {
      if (api.runtime.lastError) {
        status.textContent = '保存失败，请重试';
        status.classList.add('error');
        refreshFromStorage();
      } else {
        status.textContent = '已保存到当前浏览器';
        status.classList.remove('error');
      }
    });
  }
  function saveColors(action, values = {}) {
    api.runtime.sendMessage({ type: 'badgeColors', action, ...values }, response => {
      if (api.runtime.lastError || !response?.ok) {
        status.textContent = '保存失败，请重试';
        status.classList.add('error');
        refreshFromStorage();
      } else {
        status.textContent = '已保存到当前浏览器';
        status.classList.remove('error');
      }
    });
  }
  function saveTranslationSetting(action, value) {
    applyValues(action === 'auto'
      ? { translationProvider: state.translationProvider, autoTranslateTitles: value }
      : { translationProvider: value, autoTranslateTitles: state.autoTranslateTitles });
    render();
    api.runtime.sendMessage({ type: 'translationSettings', action, value }, response => {
      if (api.runtime.lastError || !response?.ok) {
        status.textContent = '保存失败，请重试'; status.classList.add('error');
      } else {
        status.textContent = '已保存到当前浏览器'; status.classList.remove('error');
      }
      refreshFromStorage();
    });
  }
  function toggleMetric(id, enabled) {
    const item = byId.get(id);
    if (!item) return;
    const visibility = { ...state.badgeVisibility };
    const peers = catalog.filter(candidate => candidate.group === item.group);
    if (enabled && !state[item.group]) for (const peer of peers) visibility[peer.id] = false;
    visibility[id] = enabled;
    const values = { badgeVisibility: visibility };
    if (enabled) values[item.group] = true;
    else if (peers.every(peer => visibility[peer.id] === false)) values[item.group] = false;
    save(values);
  }
  function moveMetric(id, destination) {
    const order = core.badgeOrder(state.badgeOrder);
    const from = order.indexOf(id);
    if (from < 0 || destination < 0 || destination >= order.length || from === destination) return;
    order.splice(from, 1);
    order.splice(destination, 0, id);
    save({ badgeOrder: order });
  }
  function renderMetrics() {
    const focused = document.activeElement?.dataset?.focusKey || '';
    const query = metricSearch.value.trim().toLowerCase();
    const order = core.badgeOrder(state.badgeOrder);
    document.getElementById('selectedCount').textContent = String(catalog.filter(selected).length);
    metricList.replaceChildren();
    let shown = 0;
    for (const [index, id] of order.entries()) {
      const item = byId.get(id);
      if (!item || (query && ![item.id, item.label, item.description].join(' ').toLowerCase().includes(query))) continue;
      shown += 1;
      const row = document.createElement('li');
      row.className = 'metric-row';
      row.dataset.id = id;
      row.draggable = true;
      const handle = document.createElement('span');
      handle.className = 'drag-handle';
      handle.setAttribute('aria-hidden', 'true');
      handle.append(icon('grip-vertical'));
      const label = document.createElement('label');
      label.className = 'metric-choice';
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.checked = selected(item);
      input.dataset.metric = id;
      input.dataset.focusKey = 'metric-' + id;
      const copy = document.createElement('span');
      const title = document.createElement('strong');
      title.textContent = item.label;
      const description = document.createElement('small');
      description.textContent = item.description;
      copy.append(title, description);
      label.append(input, copy);
      const actions = document.createElement('div');
      actions.className = 'metric-actions';
      for (const direction of [-1, 1]) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'move-button';
        button.dataset.move = String(direction);
        button.dataset.focusKey = 'move-' + id + '-' + direction;
        button.disabled = index + direction < 0 || index + direction >= order.length;
        button.setAttribute('aria-label', (direction < 0 ? '上移' : '下移') + item.label);
        button.append(icon(direction < 0 ? 'arrow-up' : 'arrow-down'));
        actions.append(button);
      }
      row.append(handle, label, actions);
      metricList.append(row);
    }
    document.getElementById('metricEmpty').hidden = shown !== 0;
    if (focused) [...metricList.querySelectorAll('[data-focus-key]')].find(node => node.dataset.focusKey === focused && !node.disabled)?.focus();
  }
  function renderPreview() {
    const preview = document.getElementById('livePreview');
    const palette = core.badgePalette(state.badgeStyle, state.badgeColors);
    const layout = core.badgeLayout(state.badgeLayout);
    preview.replaceChildren();
    preview.style.gap = layout.gap + 'px';
    if (!state.enabled) {
      const hint = document.createElement('span');
      hint.className = 'preview-note';
      hint.textContent = '期刊标签已关闭';
      preview.append(hint);
      return;
    }
    if (layout.showLogo) {
      const logo = document.createElement('img');
      logo.src = 'journal-scout-logo.png';
      logo.alt = '';
      logo.className = 'preview-logo';
      preview.append(logo);
    }
    for (const id of core.badgeOrder(state.badgeOrder)) {
      const item = byId.get(id);
      if (!item || !selected(item)) continue;
      const colors = palette[item.kind];
      const badge = document.createElement('span');
      badge.className = 'preview-badge';
      badge.textContent = core.badgeText(id, item.sample, state.badgeAliases);
      badge.style.color = colors.fg;
      badge.style.backgroundColor = colors.bg;
      badge.style.borderColor = colors.border;
      badge.style.fontSize = layout.fontSize + 'px';
      badge.style.borderRadius = layout.radius + 'px';
      badge.style.padding = layout.paddingY + 'px ' + layout.paddingX + 'px';
      preview.append(badge);
    }
  }
  function renderAppearance() {
    for (const radio of document.querySelectorAll('input[name="badgeStyle"]')) radio.checked = radio.value === state.badgeStyle;
    document.getElementById('customPalette').hidden = state.badgeStyle !== 'custom';
    const palette = core.badgePalette('custom', state.badgeColors);
    for (const input of document.querySelectorAll('[data-color-kind]')) input.value = palette[input.dataset.colorKind][input.dataset.colorPart];
    for (const input of document.querySelectorAll('[data-alias]')) if (input !== document.activeElement) input.value = state.badgeAliases[input.dataset.alias] || '';
    const layout = core.badgeLayout(state.badgeLayout);
    for (const input of document.querySelectorAll('[data-layout]')) {
      input.value = String(layout[input.dataset.layout]);
      document.querySelector('[data-output="' + input.dataset.layout + '"]').textContent = input.value + ' px';
    }
    document.getElementById('showLogo').checked = layout.showLogo;
  }
  function render() {
    for (const input of document.querySelectorAll('[data-setting]')) input.checked = Boolean(state[input.dataset.setting]);
    for (const id of ['translationProvider', 'translationTarget', 'translationKey', 'translationCloseKey', 'translationTitleSize', 'translationTitleColorMode']) document.getElementById(id).value = state[id];
    document.getElementById('translationTitleColor').value = state.translationTitleColor;
    document.getElementById('translationTitleColorRow').hidden = state.translationTitleColorMode !== 'custom';
    document.getElementById('legacyLibrary').hidden = !Array.isArray(state.savedPapers) || state.savedPapers.length === 0;
    renderMetrics();
    renderAppearance();
    renderPreview();
  }
  function paletteCopy(palette) {
    return Object.fromEntries(Object.entries(palette).map(([kind, color]) => [kind, { fg: color.fg, bg: color.bg }]));
  }

  for (const id of ['translationKey', 'translationCloseKey']) {
    const select = document.getElementById(id);
    for (const letter of 'ABCDEFGHIJKLMNOPQRSTUVWXYZ') {
      const option = document.createElement('option'); option.value = letter; option.textContent = letter; select.append(option);
    }
  }
  const paletteRows = document.getElementById('paletteRows');
  for (const [kind, label] of paletteKinds) {
    const row = document.createElement('div');
    row.className = 'palette-row';
    const name = document.createElement('span');
    name.textContent = label;
    row.append(name);
    for (const part of ['fg', 'bg']) {
      const input = document.createElement('input');
      input.type = 'color';
      input.dataset.colorKind = kind;
      input.dataset.colorPart = part;
      input.setAttribute('aria-label', label + (part === 'fg' ? '文字颜色' : '背景颜色'));
      row.append(input);
    }
    paletteRows.append(row);
  }
  const aliasRows = document.getElementById('aliasRows');
  for (const item of catalog.filter(item => core.badgePrefixes[item.id])) {
    const label = document.createElement('label');
    label.className = 'alias-row';
    const name = document.createElement('span');
    name.textContent = item.label;
    const input = document.createElement('input');
    input.type = 'text';
    input.maxLength = 20;
    input.placeholder = core.badgePrefixes[item.id];
    input.dataset.alias = item.id;
    input.setAttribute('aria-label', item.label + '简称');
    label.append(name, input);
    aliasRows.append(label);
  }
  document.addEventListener('change', event => {
    const target = event.target;
    if (target.matches('[data-setting]')) {
      if (target.dataset.setting === 'autoTranslateTitles') saveTranslationSetting('auto', target.checked);
      else save({ [target.dataset.setting]: target.checked });
    }
    if (['translationProvider', 'translationTarget', 'translationKey', 'translationCloseKey', 'translationTitleSize', 'translationTitleColorMode'].includes(target.id)) {
      if ((target.id === 'translationKey' && target.value === state.translationCloseKey) ||
          (target.id === 'translationCloseKey' && target.value === state.translationKey)) {
        target.value = state[target.id]; status.textContent = '翻译键和关闭键需要不同'; status.classList.add('error');
      } else if (target.id === 'translationProvider') saveTranslationSetting('provider', target.value);
      else save({ [target.id]: target.value });
    }
    if (target.id === 'translationTitleColor') save({ translationTitleColor: target.value });
    if (target.matches('[data-metric]')) toggleMetric(target.dataset.metric, target.checked);
    if (target.matches('[data-alias]')) {
      const aliases = { ...state.badgeAliases };
      const value = core.badgeAlias(target.value);
      if (value) aliases[target.dataset.alias] = value;
      else delete aliases[target.dataset.alias];
      save({ badgeAliases: aliases });
    }
    if (target.matches('input[name="badgeStyle"]') && target.checked) {
      if (target.value === 'custom' && !state.badgeColors) {
        const base = ['b', 'c'].includes(state.badgeStyle) ? state.badgeStyle : 'a';
        applyValues({ badgeColors: paletteCopy(core.badgePalette(base)) });
        saveColors('init', { base });
      }
      save({ badgeStyle: target.value });
    }
    if (target.id === 'showLogo') save({ badgeLayout: { ...core.badgeLayout(state.badgeLayout), showLogo: target.checked } });
  });
  document.addEventListener('input', event => {
    const target = event.target;
    if (target === metricSearch) renderMetrics();
    if (target.matches('[data-layout]')) {
      const layout = { ...core.badgeLayout(state.badgeLayout), [target.dataset.layout]: Number(target.value) };
      save({ badgeLayout: core.badgeLayout(layout) });
    }
    if (target.matches('[data-color-kind]')) {
      const colors = paletteCopy(core.badgePalette('custom', state.badgeColors));
      colors[target.dataset.colorKind][target.dataset.colorPart] = target.value;
      applyValues({ badgeColors: colors });
      render();
      saveColors('set', { kind: target.dataset.colorKind, part: target.dataset.colorPart, value: target.value });
    }
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Enter' && event.target.matches('[data-alias]')) event.target.blur();
  });
  metricList.addEventListener('click', event => {
    const button = event.target.closest('[data-move]');
    if (!button) return;
    const id = button.closest('[data-id]').dataset.id;
    moveMetric(id, core.badgeOrder(state.badgeOrder).indexOf(id) + Number(button.dataset.move));
  });
  metricList.addEventListener('dragstart', event => {
    const row = event.target.closest('[data-id]');
    if (!row) return;
    dragged = row.dataset.id;
    row.classList.add('dragging');
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', dragged);
  });
  metricList.addEventListener('dragover', event => {
    const row = event.target.closest('[data-id]');
    if (!dragged || !row || row.dataset.id === dragged) return;
    event.preventDefault();
    for (const node of metricList.querySelectorAll('.drop-target')) node.classList.remove('drop-target');
    row.classList.add('drop-target');
  });
  metricList.addEventListener('drop', event => {
    const row = event.target.closest('[data-id]');
    if (!dragged || !row) return;
    event.preventDefault();
    const order = core.badgeOrder(state.badgeOrder);
    moveMetric(dragged, order.indexOf(row.dataset.id));
    dragged = '';
  });
  metricList.addEventListener('dragend', () => {
    dragged = '';
    for (const node of metricList.querySelectorAll('.dragging, .drop-target')) node.classList.remove('dragging', 'drop-target');
  });
  document.getElementById('selectAll').addEventListener('click', () => {
    save({ ...Object.fromEntries(groups.map(group => [group, true])), badgeVisibility: Object.fromEntries(catalog.map(item => [item.id, true])) });
  });
  document.getElementById('clearAll').addEventListener('click', () => {
    save({ ...Object.fromEntries(groups.map(group => [group, false])), badgeVisibility: Object.fromEntries(catalog.map(item => [item.id, false])) });
  });
  document.getElementById('resetOrder').addEventListener('click', () => save({ badgeOrder: core.badgeOrder() }));
  document.getElementById('resetAliases').addEventListener('click', () => save({ badgeAliases: {} }));
  document.getElementById('resetLayout').addEventListener('click', () => save({ badgeLayout: { ...core.layoutDefaults } }));
  document.getElementById('resetColors').addEventListener('click', () => {
    applyValues({ badgeColors: paletteCopy(core.badgePalette('a')) });
    render();
    saveColors('reset');
  });
  api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const updates = {};
    for (const [key, change] of Object.entries(changes)) if (key in defaults) updates[key] = change.newValue ?? defaults[key];
    if (Object.keys(updates).length) storageRevision += 1;
    if (!ready) { Object.assign(initialChanges, updates); return; }
    if (Object.keys(updates).length) { applyValues(updates); render(); }
  });
  const version = api.runtime.getManifest?.().version;
  if (version) document.getElementById('version').textContent = '版本 ' + version;
  api.storage.local.get(defaults, values => {
    applyValues({ ...values, ...initialChanges }); initialChanges = {}; ready = true; render();
    document.querySelectorAll('#translation input, #translation select').forEach(input => { input.disabled = false; });
  });
})();
