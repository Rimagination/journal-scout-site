(() => {
  if (globalThis.ScanSciContentLoaded) return;
  globalThis.ScanSciContentLoaded = true;
  const api = globalThis.chrome || globalThis.browser;
  const core = globalThis.ScanSciCore;
  const results = globalThis.ScanSciResults || { track() {}, record() {}, clear() {}, refresh() {} };
  let settings = { ...core.defaults };
  let badgeStyle = 'a';
  let badgeColors = null;
  let palette = core.badgePalette(badgeStyle, badgeColors);
  let layout = core.badgeLayout();
  let ready = false;
  let seen = new WeakMap();
  let mounted = new WeakMap();
  let retried = new WeakMap();
  const retryTargets = new Map();
  const schemas = new WeakMap();
  let generation = 0;
  let timer;
  let retryTimer;

  function paintBadge(tag) {
    const colors = palette[tag.scansciBadgeKind];
    if (!colors) return;
    tag.style.setProperty('color', colors.fg, 'important');
    tag.style.setProperty('background-color', colors.bg, 'important');
    tag.style.setProperty('border-color', colors.border, 'important');
    tag.style.setProperty('font-size', `${layout.fontSize}px`, 'important');
    tag.style.setProperty('border-radius', `${layout.radius}px`, 'important');
    tag.style.setProperty('padding', `${layout.paddingY}px ${layout.paddingX}px`, 'important');
  }

  function paintContainer(container, logo) {
    container.style.setProperty('gap', `${layout.gap}px`, 'important');
    if (logo) logo.style.setProperty('display', layout.showLogo && container.scansciBadges?.length ? 'inline-flex' : 'none', 'important');
  }

  function send(message) {
    return new Promise(resolve => {
      try { api.runtime.sendMessage(message, response => {
        if (api.runtime.lastError) { console.warn('ScanSci communication failed:', api.runtime.lastError.message); resolve(null); }
        else resolve(response);
      }); }
      catch { resolve(null); }
    });
  }

  function renderBadges(container, row) {
    for (const tag of container.scansciBadges || []) tag.remove();
    container.scansciBadges = [];
    const values = core.badges(row, settings);
    const nativeVisible = [...container.children].some(isNativeMarker);
    container.hidden = !values.length && !nativeVisible;
    container.style.setProperty('display', container.hidden ? 'none' : 'flex', 'important');
    for (const badge of values) {
      const tag = document.createElement('span');
      tag.className = `scansci-journal-badge scansci-journal-badge--${badge.kind}`;
      tag.scansciBadgeKind = badge.kind;
      tag.textContent = badge.text;
      tag.title = badge.title;
      tag.setAttribute('aria-label', `${badge.text}。${badge.title}`);
      paintBadge(tag);
      container.scansciBadges.push(tag);
      container.append(tag);
    }
    paintContainer(container, container.scansciLogo);
  }

  function isNativeMarker(node) {
    return node.matches?.('b.marktip') && node.textContent.trim() === '网络首发';
  }

  function removeBadge(container) {
    if (!container) return;
    const native = container.scansciNative;
    if (native || (location.hostname === 'kns.cnki.net' && container.parentElement?.matches('td.name'))) {
      const marker = [...container.children].find(isNativeMarker);
      const next = container.nextSibling;
      const placeholder = native?.placeholder || (next?.nodeType === 8 && next.data === 'Journal Scout' ? next : null);
      if (marker && placeholder?.parentNode) placeholder.parentNode.replaceChild(marker, placeholder);
      else if (marker && container.parentNode) container.parentNode.insertBefore(marker, next);
      else placeholder?.remove();
      delete container.scansciNative;
    }
    container.remove();
  }

  function groupNativeMarker(container, target) {
    const cell = target.closest?.('td.name');
    if (location.hostname !== 'kns.cnki.net' || !cell || container.parentElement !== cell) return false;
    const current = [...container.children].find(isNativeMarker);
    if (current) {
      if (container.scansciNative?.marker === current) return false;
      if (container.scansciNative) container.scansciNative.marker = current;
      return true;
    }
    if (container.scansciNative) {
      container.scansciNative.placeholder.remove();
      delete container.scansciNative;
    }
    const marker = [...cell.children].find(isNativeMarker);
    if (!marker) return false;
    const placeholder = document.createComment('Journal Scout');
    marker.before(placeholder);
    container.scansciNative = { marker, placeholder };
    container.insertBefore(marker, container.scansciLogo.nextSibling);
    return true;
  }

  function show(target, row, current, signature, isCurrent, card) {
    if (!row || generation !== current || !settings.enabled || !target.isConnected || seen.get(target) !== signature || !isCurrent()) return;
    const previous = mounted.get(target);
    if (previous && previous === existingBadge(target)) return;
    removeBadge(previous);
    const old = existingBadge(target);
    if (old?.classList.contains('scansci-journal-badges')) removeBadge(old);
    if (settings.filter) results.record(card, signature, row, isCurrent);
    if (!row.ambiguous && (!Number.isSafeInteger(row.id) || row.id <= 0)) return;
    const container = document.createElement('span');
    container.className = 'scansci-journal-badges';
    container.scansciIsCurrent = () => target.isConnected && seen.get(target) === signature && isCurrent();
    container.scansciRow = row;
    container.setAttribute('aria-label', 'Journal Scout 期刊信息');
    const link = document.createElement(row.ambiguous ? 'span' : 'a');
    if (!row.ambiguous) {
      link.href = `https://journal.scansci.com/journal.html?id=${row.id}`;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
    }
    link.className = 'scansci-journal-link';
    link.title = row.ambiguous ? `${row.title} · 存在同名记录，仅展示共同信息` : `${row.title} · 查看 Journal Scout 详情`;
    link.setAttribute('aria-label', link.title);
    const logo = document.createElement('img');
    logo.src = api.runtime.getURL(core.extensionPath('journal-scout-logo.png', api.runtime));
    logo.alt = '';
    link.append(logo);
    container.scansciLogo = link;
    container.append(link);
    if (target.tagName === 'TD' || target.tagName === 'DT') target.append(container);
    else (core.adjacentCompanion(target, 'scansci-title-translation') || target).insertAdjacentElement('afterend', container);
    groupNativeMarker(container, target);
    renderBadges(container, row);
    mounted.set(target, container);
  }

  function existingBadge(target) {
    return target.tagName === 'TD' || target.tagName === 'DT' ? target.querySelector(':scope > .scansci-journal-badges') : core.adjacentCompanion(target, 'scansci-journal-badges');
  }

  function mark(target, signature) {
    if (!target) return false;
    const previous = mounted.get(target);
    if (seen.get(target) === signature && (!previous || previous === existingBadge(target))) {
      if (previous && groupNativeMarker(previous, target)) renderBadges(previous, previous.scansciRow);
      return false;
    }
    removeBadge(previous);
    mounted.delete(target);
    const old = existingBadge(target);
    if (old?.classList.contains('scansci-journal-badges')) removeBadge(old);
    if (retried.get(target) !== signature) retried.delete(target);
    seen.set(target, signature);
    return true;
  }

  function clear(target) {
    if (!target) return;
    removeBadge(mounted.get(target));
    mounted.delete(target);
    const old = existingBadge(target);
    if (old?.classList.contains('scansci-journal-badges')) removeBadge(old);
    seen.delete(target);
    retried.delete(target);
  }

  function retry(target, signature, current) {
    if (current !== generation || seen.get(target) !== signature || retried.get(target) === signature) return;
    retried.set(target, signature);
    retryTargets.set(target, signature);
    if (!retryTimer) retryTimer = setTimeout(() => {
      retryTimer = undefined;
      for (const [node, value] of retryTargets) if (seen.get(node) === value) seen.delete(node);
      retryTargets.clear();
      scan();
    }, 4000);
  }

  async function annotate(target, hint, readHint, card) {
    const signature = JSON.stringify(hint);
    const renewed = results.track(card, signature);
    if (renewed && seen.get(target) === signature) seen.delete(target);
    if (!mark(target, signature)) return;
    const current = generation;
    const response = await send({ type: 'lookup', ...hint, details: settings.ccf || settings.badgeHistory });
    const isCurrent = () => JSON.stringify(readHint()) === signature;
    if (response?.ok) show(target, response.data, current, signature, isCurrent, card);
    else retry(target, signature, current);
  }

  function meta(name) {
    return [...document.querySelectorAll(`meta[name="${name}" i]`)].map(node => node.content.trim()).filter(Boolean);
  }

  function schemaHint(identity) {
    const hints = new Map();
    for (const node of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0, 8)) {
      const text = node.textContent || '';
      if (text.length > 100000) continue;
      let cached = schemas.get(node);
      if (!cached || cached.text !== text) {
        let data = null;
        try { data = JSON.parse(text); } catch { /* Invalid metadata is ignored. */ }
        cached = { text, data };
        schemas.set(node, cached);
      }
      const hint = cached.data && core.schemaJournal(cached.data, identity);
      if (hint?.ambiguous) return null;
      if (hint) hints.set(JSON.stringify([core.normalizeTitle(hint.title), hint.issns.map(core.normalizeIssn).sort()]), hint);
    }
    return hints.size === 1 ? hints.values().next().value : null;
  }

  function metadataHint() {
    const title = meta('citation_journal_title')[0] || meta('prism.publicationname')[0] || meta('dc.source')[0] || '';
    const issns = [...new Set([...meta('citation_issn'), ...meta('citation_eissn'), ...meta('citation_journal_issn'), ...meta('prism.issn'), ...meta('prism.eissn')].filter(core.validIssn))];
    const pageDoi = [meta('citation_doi')[0], ...meta('dc.identifier')].map(core.normalizeDoi).find(Boolean) || '';
    const doi = settings.doiLookup ? pageDoi : '';
    const paperTitle = meta('citation_title')[0] || meta('dc.title')[0];
    if (paperTitle && (title || issns.length)) return { title, issns, ...(doi ? { doi } : {}) };
    const schema = schemaHint({ title: paperTitle || core.articleHeading(document)?.textContent, doi: pageDoi });
    if (schema) return { ...schema, ...(doi ? { doi } : {}) };
    return paperTitle && doi ? { title: '', issns: [], doi } : null;
  }

  function cardDoi(card) {
    if (!settings.doiLookup || !card) return '';
    const anchors = [card.querySelector('a[href^="https://doi.org/"], a[href^="https://dx.doi.org/"]'),
      card.querySelector('.gs_rt a[href], a.gsc_a_at[href]')];
    return anchors.filter(Boolean).map(anchor => core.doiFromUrl(anchor.href, location.href)).find(Boolean) || '';
  }

  function scanMetadata() {
    const heading = core.articleHeading(document);
    if (!heading) return;
    const hint = metadataHint();
    if (hint) void annotate(heading, hint, () => core.articleHeading(document) === heading ? metadataHint() : null);
    else clear(heading);
  }

  function scanScholar() {
    if (!location.hostname.startsWith('scholar.google.')) return;
    const articleHint = (card, title, source, profile = false) => {
      const doi = cardDoi(card);
      const heading = card?.querySelector(profile ? 'a.gsc_a_at' : '.gs_rt a') || (!profile && card?.querySelector('.gs_rt'));
      const text = heading?.textContent.replace(/^\s*\[(?:PDF|HTML|CITATION|引用)\]\s*/i, '').trim() || '';
      const articleTitle = settings.doiLookup && text.length <= 400 ? text : '';
      const parts = source.split(/\s+[-–—]\s+/);
      const publication = parts.length > 1 ? parts.slice(1).join(' ') : source;
      const articleYear = (profile ? card.querySelector('.gsc_a_y')?.textContent : publication)?.match(/\b(?:19|20)\d{2}\b/)?.[0];
      return title || doi || articleTitle ? { title, issns: [], ...(doi ? { doi } : {}),
        ...(articleTitle ? { articleTitle, ...(articleYear ? { articleYear } : {}) } : {}) } : null;
    };
    const sourceFor = card => {
      const sources = [...card.querySelectorAll('.gs_a')].filter(node => node.closest('.gs_r') === card);
      return sources.find(node => node.classList.contains('gs_fma_p')) || sources[0];
    };
    document.querySelectorAll('.gs_r').forEach(card => {
      const target = sourceFor(card);
      if (!target) return;
      const readHint = () => {
        if (sourceFor(card) !== target) return null;
        // Featured Scholar results keep both compact and expanded citations in the DOM.
        const expanded = target.classList.contains('gs_fma_p');
        const source = expanded ? [...target.childNodes].filter(node => !node.classList?.contains('gs_fmaa'))
          .map(node => node.textContent).join(' ').trim() : target.textContent;
        const title = expanded ? core.scholarProfileJournal(source.split(/[•·]/)[0]) : core.scholarJournal(source);
        return articleHint(card, title, source);
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint, card);
      else { results.track(card, 'unknown'); clear(target); }
    });
    document.querySelectorAll('.gsc_a_tr').forEach(card => {
      const cell = card.querySelector('.gsc_a_t');
      const target = [...(cell?.querySelectorAll(':scope > .gs_gray') || [])].at(-1);
      if (!target) return;
      const readHint = () => articleHint(card, core.scholarProfileJournal(target.textContent), target.textContent, true);
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint, card);
      else { results.track(card, 'unknown'); clear(target); }
    });
  }

  function scanPublisherLists() {
    document.querySelectorAll('article [data-test="journal-title-and-link"], article [itemprop="isPartOf"] [itemprop="name"]').forEach(target => {
      const article = target.closest?.('article');
      const card = (location.hostname === 'nature.com' || location.hostname.endsWith('.nature.com'))
        ? article?.closest('li.app-article-list-row__item') || article : article;
      const readHint = () => {
        const title = target.textContent.trim();
        return title && title.length <= 120 ? { title, issns: [] } : null;
      };
      const hint = readHint();
      if (hint) void annotate(target, hint, readHint, card);
      else { results.track(card, 'unknown'); clear(target); }
    });
  }

  function scanAdaptedLists() {
    const host = location.hostname;
    const adapters = [
      { host: 'kns.cnki.net', selector: 'td.source', card: 'tr',
        target: (node, card) => card.querySelector('td.name a') || node.querySelector('a') || node,
        title: node => node.querySelector('a')?.textContent || [...node.childNodes].filter(child => !child.classList?.contains('scansci-journal-badges')).map(child => child.textContent).join('') },
      { host: 'xueshu.baidu.com', selector: 'div.result div.sc_info span:nth-of-type(2) a', card: 'div.result', title: node => node.getAttribute('title') || node.textContent },
      { host: 'sciencedirect.com', selector: 'li.ResultItem a[data-aa-name*="srp-srctitle-"]', card: 'li.ResultItem' },
      { host: 'link.springer.com', selector: '#results-list > li p.meta span.enumeration > a', card: 'li' },
      { host: 'ieeexplore.ieee.org', selector: 'xpl-results-list div.List-results-items div.hide-mobile div.result-item-align div.description a:first-child', card: 'div.List-results-items' },
      { host: 'dl.acm.org', selector: '.doSearch li.issue-item-container .issue-item__detail > a:first-child', card: 'li.issue-item-container', title: node => (node.getAttribute('title') || node.textContent).replace(/^[^:：]+[:：]\s*/, '') },
      { host: 'dblp.org', selector: '.publ-list li.entry.article span[itemprop="isPartOf"] span[itemprop="name"]', card: 'li.entry' },
      { host: 'dblp.dagstuhl.de', selector: '.publ-list li.entry.article span[itemprop="isPartOf"] span[itemprop="name"]', card: 'li.entry' },
      { host: 'aminer.cn', selector: 'div.paper-item .conf-info-zone > .venue-link > .venue-link:first-child', card: 'div.paper-item', title: node => node.textContent.split(/[（(]/)[0] },
      { host: 'scopus.com', selector: '#srchResultsList tr.searchArea td[data-type="source"] a.ddmDocSource, tr[class^="TableItems"] div[data-component="document-source"] span:first-child', card: 'tr' },
      { host: 'webofscience.com',
        selector: 'app-jcr-sidenav .summary-source-title, app-jcr-sidenav .summary-source-title-link, app-jcr-sidenav span[lang="en"], app-jcr-sidenav a[lang="en"], app-jcr-sidenav a, app-jcr-sidenav [data-ta*="source"], app-jcr-sidenav [data-test*="source"], .source-title-display > a.jcrSideNav-color > span, app-publication-card-content span.journal-name, app-publication-card-content [class*="journal-name"], app-record [data-ta*="source-title"], app-record [data-test*="journal"], app-record [class*="source-title"], app-record [class*="journal-name"], .search-results-item [data-ta*="source-title"], .search-results-item [data-test*="journal"], .search-results-item [class*="source-title"], .search-results-item [class*="journal-name"]',
        card: 'app-record, app-publication-card-content, .search-results-item',
        target: node => node.closest('a.summary-source-title-link, a.jcrSideNav-color') || node,
        title: node => {
          const text = node.cloneNode(true);
          text.querySelectorAll('mat-icon, .mat-icon, [aria-hidden="true"], .scansci-journal-badges, .scansci-title-translation').forEach(child => child.remove());
          return text.textContent;
        } },
      { host: 'semanticscholar.org', selector: '#main-content div.cl-paper-row .cl-paper__bulleted-row__item > a > span', card: 'div.cl-paper-row' },
      { host: 'wanfangdata.com.cn', selector: 'div.normal-list div.author-area span.periodical-title', card: 'div.normal-list',
        target: (node, card) => card.querySelector('div.title-area span.title') || node },
      { host: 'cqvip.com', selector: '.simple-list > dl .from > a', card: 'dl', title: node => node.getAttribute('title') || node.textContent,
        target: (node, card) => card.querySelector('dt') || node },
      { host: 'x-mol.com', selector: 'div[class*="SearchPaperGridCard"] span[class*="gridJournalName"]', card: 'div[class*="SearchPaperGridCard"]',
        target: (node, card) => card.querySelector('h3') || node },
      { host: 'x-mol.com', selector: 'div[class*="SearchResultLayout-module"] div[class*="cardBody"] span[class*="journalLink"], div[class*="ReadResultLayout-module"] div[class*="cardBody"] a[class*="journalLink"]', card: 'div[class*="cardBody"]',
        target: (node, card) => card.querySelector('h3') || node },
      { host: 'readpaper.com', selector: '.paper-item span.block:first-child', card: '.paper-item',
        target: (node, card) => card.querySelector('.title') || node },
    ];
    for (const adapter of adapters.filter(item => host === item.host || host.endsWith(`.${item.host}`))) {
      const targets = new Set();
      document.querySelectorAll(adapter.selector).forEach(source => {
        if (source.closest('.scansci-journal-badges, .scansci-title-translation')) return;
        const card = source.closest(adapter.card);
        if (!card) return;
        const target = adapter.target ? adapter.target(source, card) : source;
        if (targets.has(target)) return;
        targets.add(target);
        const readHint = () => {
          if (!source.matches(adapter.selector) || source.closest(adapter.card) !== card || (adapter.target && adapter.target(source, card) !== target)) return null;
          const title = String(adapter.title ? adapter.title(source) : source.textContent).replace(/[《》]/g, '').replace(/\s+/g, ' ').trim();
          const usableTitle = title && title.length <= 120 && !/\.\.\.|…/.test(title) ? title : '';
          const doi = cardDoi(card);
          return usableTitle || doi ? { title: usableTitle, issns: [], ...(doi ? { doi } : {}) } : null;
        };
        const hint = readHint();
        if (hint) void annotate(target, hint, readHint, card);
        else { results.track(card, 'unknown'); clear(target); }
      });
    }
  }

  function pubmedId(card) {
    return String(card.getAttribute('data-article-id') || card.querySelector('.docsum-pmid')?.textContent || '').trim();
  }

  function pmcId(card) {
    const anchor = card.querySelector('a.docsum-title[href]');
    if (!anchor) return '';
    try {
      const url = new URL(anchor.getAttribute('href'), location.href);
      return url.protocol === 'https:' && url.hostname === 'pmc.ncbi.nlm.nih.gov'
        ? url.pathname.match(/^\/articles\/PMC(\d{1,12})\/?$/i)?.[1] || '' : '';
    } catch { return ''; }
  }

  async function scanNcbi() {
    const database = location.hostname === 'pubmed.ncbi.nlm.nih.gov' ? 'pubmed'
      : location.hostname === 'pmc.ncbi.nlm.nih.gov' ? 'pmc' : '';
    if (!database) return;
    const cardSelector = database === 'pmc' ? '.articles > ul > li.article' : 'article.full-docsum, .full-docsum';
    const targetSelector = database === 'pmc' ? 'a.docsum-title[href]' : '.docsum-journal-citation';
    const getId = database === 'pmc' ? pmcId : pubmedId;
    const entries = [];
    for (const card of document.querySelectorAll(cardSelector)) {
      const id = getId(card);
      const target = card.querySelector(targetSelector);
      if (!/^\d{1,12}$/.test(id)) { results.track(card, 'unknown'); clear(target); }
      else {
        const signature = `${database}:${id}`;
        const renewed = results.track(card, signature);
        if (renewed && seen.get(target) === signature) seen.delete(target);
        if (mark(target, signature)) entries.push({ id, target, card });
      }
    }
    if (!entries.length) return;
    const current = generation;
    for (let start = 0; start < entries.length; start += 80) {
      const batch = entries.slice(start, start + 80);
      const response = await send({ type: 'pubmed', database, ids: batch.map(entry => entry.id) });
      if (current !== generation) return;
      if (!response?.ok) {
        for (const entry of entries.slice(start)) retry(entry.target, `${database}:${entry.id}`, current);
        return;
      }
      await Promise.all(batch.map(async entry => {
        const hint = response.data[entry.id];
        const doi = settings.doiLookup ? core.normalizeDoi(hint?.doi) : '';
        if (!hint || (!hint.title && !hint.issns.length && !doi)) return;
        const signature = `${database}:${entry.id}`;
        const isCurrent = () => getId(entry.card) === entry.id && entry.card.querySelector(targetSelector) === entry.target;
        if (!isCurrent()) return;
        const result = await send({ type: 'lookup', title: hint.title, issns: hint.issns, ...(doi ? { doi } : {}), details: settings.ccf || settings.badgeHistory });
        if (result?.ok) show(entry.target, result.data, current, signature, isCurrent, entry.card);
        else retry(entry.target, signature, current);
      }));
    }
  }

  function scan() {
    if (!ready || !settings.enabled) return;
    scanMetadata();
    scanScholar();
    scanPublisherLists();
    scanAdaptedLists();
    void scanNcbi();
  }

  function rescan(preserveResults = false) {
    generation += 1;
    seen = new WeakMap();
    mounted = new WeakMap();
    retried = new WeakMap();
    clearTimeout(retryTimer);
    retryTimer = undefined;
    retryTargets.clear();
    if (!preserveResults) results.clear();
    document.querySelectorAll('.scansci-journal-badges').forEach(removeBadge);
    scan();
  }

  api.storage.local.get({ ...core.defaults, badgeStyle: 'a', badgeColors: null, badgeVisibility: null, badgeOrder: null, badgeAliases: null, badgeLayout: null }, values => {
    settings = { ...core.defaults, ...values };
    badgeStyle = values.badgeStyle;
    badgeColors = values.badgeColors;
    palette = core.badgePalette(badgeStyle, badgeColors);
    layout = core.badgeLayout(values.badgeLayout);
    ready = true;
    scan();
  });
  api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    let rescanNeeded = false, detailRefreshNeeded = false, repaintNeeded = false;
    for (const [key, change] of Object.entries(changes)) if (key in core.defaults) {
      const previous = settings[key];
      settings[key] = change.newValue ?? core.defaults[key];
      if (['enabled', 'doiLookup', 'filter'].includes(key)) rescanNeeded = true;
      else if (['ccf', 'badgeHistory'].includes(key) && settings[key] && !previous) detailRefreshNeeded = true;
      else repaintNeeded = true;
    }
    for (const key of ['badgeVisibility', 'badgeOrder', 'badgeAliases']) if (changes[key]) { settings[key] = changes[key].newValue; repaintNeeded = true; }
    if (changes.badgeStyle || changes.badgeColors || changes.badgeLayout) {
      badgeStyle = changes.badgeStyle ? changes.badgeStyle.newValue ?? 'a' : badgeStyle;
      badgeColors = changes.badgeColors ? changes.badgeColors.newValue : badgeColors;
      palette = core.badgePalette(badgeStyle, badgeColors);
      if (changes.badgeLayout) layout = core.badgeLayout(changes.badgeLayout.newValue);
      document.querySelectorAll('.scansci-journal-badges').forEach(node => paintContainer(node, node.querySelector('.scansci-journal-link')));
      document.querySelectorAll('.scansci-journal-badge').forEach(paintBadge);
    }
    if (rescanNeeded || detailRefreshNeeded) rescan(!rescanNeeded);
    else if (repaintNeeded) document.querySelectorAll('.scansci-journal-badges').forEach(node => {
      if (node.scansciIsCurrent?.()) renderBadges(node, node.scansciRow);
    });
  });
  new MutationObserver(records => {
    if (records && !records.some(record => {
      if (record.type !== 'attributes' || record.attributeName !== 'class') return true;
      const externalClasses = value => String(value || '').split(/\s+/).filter(name => name && !name.startsWith('scansci-')).sort().join(' ');
      return externalClasses(record.oldValue) !== externalClasses(record.target.getAttribute('class'));
    })) return;
    results.refresh();
    document.querySelectorAll('.scansci-journal-badges').forEach(node => { if (!node.scansciIsCurrent?.()) removeBadge(node); });
    if (!timer) timer = setTimeout(() => { timer = undefined; scan(); }, 150);
  }).observe(document.documentElement, { childList: true, characterData: true, attributes: true, attributeOldValue: true, attributeFilter: ['content', 'name', 'type', 'itemprop', 'data-test', 'data-aa-name', 'data-type', 'data-component', 'lang', 'id', 'data-article-id', 'title', 'href', 'class'], subtree: true });
})();
