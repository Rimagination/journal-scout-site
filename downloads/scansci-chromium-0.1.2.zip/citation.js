(() => {
  const api = globalThis.chrome || globalThis.browser;
  const core = globalThis.ScanSciCore;
  const format = globalThis.ScanSciCitation;
  const form = document.getElementById('citation-form');
  const input = document.getElementById('doi');
  const status = document.getElementById('status');
  const result = document.getElementById('citation-result');
  let paper;
  let request = 0;

  input.addEventListener('input', () => {
    request += 1;
    paper = null;
    result.hidden = true;
    status.textContent = '文献元数据来自 Crossref。';
  });

  form.addEventListener('submit', event => {
    event.preventDefault();
    const doi = core.normalizeDoi(input.value);
    const current = ++request;
    paper = null; result.hidden = true;
    if (!doi) { status.textContent = '请输入有效的 DOI 或 DOI 链接。'; return; }
    status.textContent = '正在查询 Crossref…';
    api.runtime.sendMessage({ type: 'citation', doi }, response => {
      if (current !== request) return;
      if (api.runtime.lastError || !response?.ok || !response.data) { status.textContent = '未能获取文献信息，请检查 DOI 或稍后重试。'; return; }
      paper = response.data;
      document.getElementById('citation-title').textContent = paper.title;
      document.getElementById('citation-details').textContent = [paper.authors.join('；'), paper.journal, paper.year, paper.doi].filter(Boolean).join(' · ');
      result.hidden = false;
      status.textContent = '信息来自 Crossref，请核对后导出。';
    });
  });

  for (const [id, extension, mime] of [['ris', 'ris', 'application/x-research-info-systems'], ['bibtex', 'bib', 'application/x-bibtex']]) {
    document.getElementById(id).addEventListener('click', () => {
      if (!paper) return;
      const url = URL.createObjectURL(new Blob([format[id](paper)], { type: `${mime};charset=utf-8` }));
      const link = document.createElement('a'); link.href = url; link.download = `journal-scout-citation.${extension}`; link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  }
})();
