(() => {
  const api = globalThis.chrome || globalThis.browser;
  const core = globalThis.ScanSciCore;
  const defaults = core.defaults;
  const version = api.runtime.getManifest?.().version;
  if (version) document.getElementById('version').textContent = `版本 ${version}`;
  api.storage.local.get(defaults, values => {
    for (const key of Object.keys(defaults)) document.getElementById(key).checked = values[key];
  });
  for (const key of Object.keys(defaults)) {
    document.getElementById(key).addEventListener('change', event => {
      const input = event.target;
      const peers = core.badgeCatalog.filter(item => item.group === key);
      if (!input.checked || !peers.length) { api.storage.local.set({ [key]: input.checked }); return; }
      api.storage.local.get({ badgeVisibility: {} }, values => {
        if (!input.checked) return;
        const visibility = values.badgeVisibility && typeof values.badgeVisibility === 'object' ? values.badgeVisibility : {};
        if (peers.every(item => visibility[item.id] === false)) {
          api.storage.local.set({ [key]: true, badgeVisibility: { ...visibility, ...Object.fromEntries(peers.map(item => [item.id, true])) } });
        } else api.storage.local.set({ [key]: true });
      });
    });
  }
  const styleOptions = [...document.querySelectorAll('input[name="badgeStyle"]')];
  const colorControls = [...document.querySelectorAll('[data-color-kind]')];
  const styleStatus = document.getElementById('styleStatus');
  let badgeStyle = 'a', badgeColors = null;
  const normalizeStyle = value => ['a', 'b', 'custom'].includes(value) ? value : 'a';
  const colorsFrom = palette => Object.fromEntries(Object.entries(palette).map(([kind, color]) => [kind, { fg: color.fg, bg: color.bg }]));
  const paint = (node, color) => {
    if (!color) return;
    node.style.color = color.fg;
    node.style.backgroundColor = color.bg;
    node.style.borderColor = color.border;
  };
  function renderStyle() {
    for (const option of styleOptions) option.checked = option.value === badgeStyle;
    document.getElementById('customColors').hidden = badgeStyle !== 'custom';
    const custom = core.badgePalette('custom', badgeColors);
    for (const node of document.querySelectorAll('[data-style-preview]')) {
      const preview = node.dataset.stylePreview;
      paint(node, (preview === 'custom' ? custom : core.badgePalette(preview))[node.dataset.kind]);
    }
    for (const node of document.querySelectorAll('[data-custom-preview]')) paint(node, custom[node.dataset.customPreview]);
    for (const input of colorControls) input.value = custom[input.dataset.colorKind][input.dataset.colorPart];
  }
  function saveStyle(values) {
    api.storage.local.set(values, () => { styleStatus.textContent = api.runtime.lastError ? '保存失败，请重新设置。' : ''; });
  }
  function saveColors(action, values = {}) {
    api.runtime.sendMessage({ type: 'badgeColors', action, ...values }, response => {
      styleStatus.textContent = api.runtime.lastError || !response?.ok ? '保存失败，请重新设置。' : '';
    });
  }
  styleOptions.forEach(option => { option.disabled = true; });
  api.storage.local.get({ badgeStyle: 'a', badgeColors: null }, values => {
    badgeStyle = normalizeStyle(values.badgeStyle);
    badgeColors = values.badgeColors;
    styleOptions.forEach(option => { option.disabled = false; });
    renderStyle();
  });
  for (const option of styleOptions) option.addEventListener('change', () => {
    if (!option.checked) return;
    const next = normalizeStyle(option.value);
    if (next === 'custom' && !badgeColors) {
      const base = badgeStyle === 'b' ? 'b' : 'a';
      badgeColors = colorsFrom(core.badgePalette(base));
      badgeStyle = next;
      saveColors('init', { base });
      saveStyle({ badgeStyle });
    } else {
      badgeStyle = next;
      saveStyle({ badgeStyle });
    }
    renderStyle();
  });
  const changeColor = event => {
    const input = event.currentTarget;
    const { colorKind: kind, colorPart: part } = input.dataset;
    const custom = core.badgePalette('custom', badgeColors);
    if (!custom[kind] || !['fg', 'bg'].includes(part) || !/^#[0-9a-f]{6}$/i.test(input.value) || custom[kind][part] === input.value.toLowerCase()) return;
    badgeColors = colorsFrom(custom);
    badgeColors[kind][part] = input.value.toLowerCase();
    saveColors('set', { kind, part, value: badgeColors[kind][part] });
    renderStyle();
  };
  for (const input of colorControls) {
    input.addEventListener('input', changeColor);
    input.addEventListener('change', changeColor);
  }
  document.getElementById('resetColors').addEventListener('click', () => {
    badgeColors = colorsFrom(core.badgePalette('a'));
    saveColors('reset');
    renderStyle();
  });
  const library = document.getElementById('legacyLibrary');
  const showLegacyLibrary = papers => { library.hidden = !Array.isArray(papers) || !papers.length; };
  api.storage.local.get({ savedPapers: [] }, values => showLegacyLibrary(values.savedPapers));
  api.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') for (const key of Object.keys(defaults)) {
      if (changes[key]) document.getElementById(key).checked = changes[key].newValue ?? defaults[key];
    }
    if (area === 'local' && changes.savedPapers) showLegacyLibrary(changes.savedPapers.newValue);
    if (area === 'local' && (changes.badgeStyle || changes.badgeColors)) {
      if (changes.badgeStyle) badgeStyle = normalizeStyle(changes.badgeStyle.newValue);
      if (changes.badgeColors) badgeColors = changes.badgeColors.newValue;
      renderStyle();
    }
  });

  const enable = document.getElementById('enableSite');
  const disable = document.getElementById('disableSite');
  const status = document.getElementById('siteStatus');
  let tab, pattern, id;
  const call = (object, method, value) => new Promise((resolve, reject) => object[method](value, result => {
    if (api.runtime.lastError) reject(new Error(api.runtime.lastError.message));
    else resolve(result);
  }));

  async function checkSite() {
    try {
      const registered = await call(api.scripting, 'getRegisteredContentScripts', { ids: [id] });
      disable.hidden = !registered.length;
      enable.disabled = false;
      status.textContent = registered.length ? '已为当前网站开启额外适配。' : '仅在网站提供论文元数据时显示信息。';
    } catch { status.textContent = '无法读取网站授权状态。'; }
  }

  api.tabs.query({ active: true, currentWindow: true }, tabs => {
    tab = tabs?.[0];
    try {
      const url = new URL(tab?.url || '');
      if (url.protocol !== 'https:') throw new Error('unsupported');
      pattern = `https://${url.hostname}/*`;
      id = `scansci_${[...new TextEncoder().encode(url.hostname)].map(value => value.toString(16).padStart(2, '0')).join('')}`;
      void checkSite();
    } catch { status.textContent = '请先打开需要适配的 HTTPS 网站。'; }
  });

  enable.addEventListener('click', () => {
    if (!tab || !pattern || !id) return;
    api.permissions.request({ origins: [pattern] }, granted => {
      if (!granted || api.runtime.lastError) { status.textContent = '未获得此网站的访问授权。'; return; }
      void (async () => {
        try {
          const registered = await call(api.scripting, 'getRegisteredContentScripts', { ids: [id] });
          if (!registered.length) await call(api.scripting, 'registerContentScripts', [{
            id, matches: [pattern], js: ['core.js', 'results.js', 'content.js', 'translate.js'], css: ['content.css'],
            runAt: 'document_end', persistAcrossSessions: true,
          }]);
          disable.hidden = false;
          const current = await call(api.tabs, 'get', tab.id);
          if (new URL(current.url).hostname !== new URL(tab.url).hostname || new URL(current.url).protocol !== 'https:') {
            status.textContent = '已授权原网站，请返回该网站并刷新。'; return;
          }
          await call(api.scripting, 'insertCSS', { target: { tabId: tab.id }, files: ['content.css'] });
          await call(api.scripting, 'executeScript', { target: { tabId: tab.id }, files: ['core.js', 'results.js', 'content.js', 'translate.js'] });
          status.textContent = '已开启。含标准论文元数据的页面会显示信息。';
        } catch { status.textContent = '已尝试授权；请刷新网站，或检查浏览器扩展权限。'; }
      })();
    });
  });

  disable.addEventListener('click', () => {
    if (!pattern || !id) return;
    void (async () => {
      try {
        await call(api.scripting, 'unregisterContentScripts', { ids: [id] });
        await call(api.permissions, 'remove', { origins: [pattern] });
        disable.hidden = true;
        status.textContent = '已停用额外适配；刷新网页后生效。内置网站仍会识别。';
      } catch { status.textContent = '停用失败，请在浏览器扩展权限设置中检查。'; }
    })();
  });
})();
