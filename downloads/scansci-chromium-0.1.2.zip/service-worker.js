// Loads the shared core and background for Chromium.
importScripts('core.js', 'background.js');
