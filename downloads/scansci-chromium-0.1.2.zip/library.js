(() => {
  const api = globalThis.chrome || globalThis.browser;
  const core = globalThis.ScanSciCore;
  const list = document.getElementById('papers');
  const count = document.getElementById('count');
  const exportButton = document.getElementById('export');
  let papers = [];

  function render() {
    list.replaceChildren();
    count.textContent = papers.length ? `共 ${papers.length} 篇` : '暂无已保存文献。';
    exportButton.disabled = !papers.length;
    for (const paper of papers) {
      const doi = core.normalizeDoi(paper.doi);
      if (!doi) continue;
      const item = document.createElement('li');
      const info = document.createElement('div');
      const title = document.createElement('a');
      title.href = `https://doi.org/${doi.split('/').map(encodeURIComponent).join('/')}`;
      title.target = '_blank'; title.rel = 'noopener noreferrer'; title.textContent = paper.title || doi;
      const details = document.createElement('p');
      details.textContent = [paper.journal, paper.year, doi].filter(Boolean).join(' · ');
      const remove = document.createElement('button');
      remove.type = 'button'; remove.textContent = '删除';
      remove.addEventListener('click', () => {
        remove.disabled = true;
        api.runtime.sendMessage({ type: 'paperRemove', doi }, response => {
          if (api.runtime.lastError || !response?.ok) { remove.disabled = false; count.textContent = '删除失败，请重试。'; }
        });
      });
      info.append(title, details); item.append(info, remove); list.append(item);
    }
  }

  const field = value => String(value || '').replace(/[\r\n]+/g, ' ').trim();
  exportButton.addEventListener('click', () => {
    const records = papers.filter(paper => core.normalizeDoi(paper.doi)).map(paper => [
      `TY  - ${paper.type === 'journal' ? 'JOUR' : 'GEN'}`, `TI  - ${field(paper.title)}`, ...((Array.isArray(paper.authors) ? paper.authors : []).map(author => `AU  - ${field(author)}`)),
      ...((paper.type === 'journal' || !paper.type) && paper.journal ? [`JF  - ${field(paper.journal)}`] : []), ...(paper.year ? [`PY  - ${field(paper.year)}`] : []),
      ...(paper.type && paper.type !== 'journal' && paper.journal ? [`N1  - 来源信息：${field(paper.journal)}`] : []),
      `DO  - ${field(paper.doi)}`, 'ER  - ', '',
    ].join('\r\n')).join('\r\n');
    const url = URL.createObjectURL(new Blob([records], { type: 'application/x-research-info-systems;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = 'scansci-papers.ris'; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  api.storage.local.get({ savedPapers: [] }, values => { papers = Array.isArray(values.savedPapers) ? values.savedPapers : []; render(); });
  api.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.savedPapers) { papers = Array.isArray(changes.savedPapers.newValue) ? changes.savedPapers.newValue : []; render(); }
  });
})();
