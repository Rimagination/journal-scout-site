(() => {
  const clean = value => String(value || '').replace(/[\r\n]+/g, ' ').trim();
  function ris(paper) {
    const lines = [`TY  - ${paper.type === 'journal' ? 'JOUR' : 'GEN'}`, `TI  - ${clean(paper.title)}`];
    for (const author of paper.authors || []) lines.push(`AU  - ${clean(author)}`);
    if (paper.journal) lines.push(`${paper.type === 'journal' ? 'JF' : 'T2'}  - ${clean(paper.journal)}`);
    for (const [key, value] of [['PY', paper.year], ['VL', paper.volume], ['IS', paper.issue]]) if (value) lines.push(`${key}  - ${clean(value)}`);
    if (paper.page) {
      const range = clean(paper.page).match(/^([^-]+)-([^-]+)$/);
      lines.push(`SP  - ${range ? range[1] : clean(paper.page)}`);
      if (range) lines.push(`EP  - ${range[2]}`);
    }
    lines.push(`DO  - ${clean(paper.doi)}`, 'ER  - ', '');
    return lines.join('\r\n');
  }
  function bibtex(paper) {
    const replacements = { '\\': '\\textbackslash{}', '{': '\\{', '}': '\\}', '%': '\\%', '$': '\\$', '#': '\\#', '&': '\\&', '_': '\\_', '~': '\\textasciitilde{}', '^': '\\textasciicircum{}' };
    const escape = value => clean(value).replace(/[\\{}%$#&_~^]/g, character => replacements[character]);
    const fields = [['title', paper.title], ['author', (paper.authors || []).join(' and ')],
      [paper.type === 'journal' ? 'journal' : 'note', paper.journal], ['year', paper.year], ['volume', paper.volume],
      ['number', paper.issue], ['pages', paper.page], ['doi', paper.doi]].filter(([, value]) => value);
    const key = `scansci${clean(paper.doi).replace(/[^a-z0-9]/gi, '').slice(0, 45)}`;
    return `@${paper.type === 'journal' ? 'article' : 'misc'}{${key},\n${fields.map(([name, value]) => `  ${name} = {${escape(value)}}`).join(',\n')}\n}\n`;
  }
  globalThis.ScanSciCitation = { ris, bibtex };
})();
